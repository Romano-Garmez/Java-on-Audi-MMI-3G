package com.ibm.oti.io;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2001, 2003  All Rights Reserved
 */

public class CharacterConverter_ASCII extends CharacterConverter {

public int countChars(byte[] value, int offset, int count) {
	return count;
}

public int convert(byte[] value, int offset, char[] chars, int charOffset, int total) {
	for (int i=total; --i >= 0;) {
		char data = (char)value[offset++];
		if (data <= '\u007f')
			chars[charOffset++] = data;
		else
			chars[charOffset++] = 0xfffd;
	}
	return offset;
}

public byte[] convert(char[] value, int offset, int count) {
	int end = offset + count, i = 0;
	byte[] result = new byte[count];
	while (offset < end) {
		int ch = value[offset++];
		if (ch > 0x7f) {
			if (ch >= 0xd800 && ch < 0xdc00 &&
				offset < end &&	value[offset] >= 0xdc00 &&
				value[offset] < 0xe000)
					offset++;
			result[i++] = '?';
		} else result[i++] = (byte)ch;
	}
	if (i < result.length) {
		byte[] newResult = new byte[i];
		System.arraycopy(result, 0, newResult, 0, i);
		return newResult;
	}
	return result;
}

}
