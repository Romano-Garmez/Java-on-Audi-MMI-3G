package com.ibm.oti.io;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2001, 2003  All Rights Reserved
 */

class CharacterConverter_UNICODEBIGUNMARKED extends CharacterConverter_UNICODEBIG {

public CharacterConverter_UNICODEBIGUNMARKED() {
	readTag = false;
	writeTag = false;
}
}
