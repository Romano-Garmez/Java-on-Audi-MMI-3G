package com.ibm.oti.io;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2001, 2003  All Rights Reserved
 */

class CharacterConverter_UNICODELITTLEUNMARKED extends CharacterConverter_UNICODELITTLE {

public CharacterConverter_UNICODELITTLEUNMARKED() {
	readTag = false;
	writeTag = false;
}
}
