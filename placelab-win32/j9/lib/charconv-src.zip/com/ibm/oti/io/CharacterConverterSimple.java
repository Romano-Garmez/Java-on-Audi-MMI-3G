
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1998, 2003  All Rights Reserved
 */

package com.ibm.oti.io;

import com.ibm.oti.util.BinarySearch;

abstract class CharacterConverterSimple extends CharacterConverter {
abstract String byteTable();
abstract String charKeys();
abstract String charValues();

public int convert(byte[] bytes, int offset, char[] chars, int charOffset, int total) {
	String byteTable = byteTable();
	for (int i=total; --i >= 0;) {
		byte value = bytes[offset++];
		// bytes are -128 to 127
		chars[charOffset++] = (char)(value < 0 ? byteTable.charAt(value+128) : value);
	}
	return offset;
}

public byte[] convert(char[] chars, int offset, int length) {
	byte[] bytes = new byte[length];
	int o1 = 0, end = offset+length;
	String charKeys = charKeys();
	String charValues = charValues();
	for (int i=offset; i<end; i++) {
		char ch = chars[i];
		if (ch <= 127) bytes[o1++] = (byte)ch;
		else {
			int result = BinarySearch.binarySearch(charKeys, ch);
			if (result >= 0) bytes[o1++] = (byte)charValues.charAt(result);
			else {
				if (ch >= 0xd800 && ch < 0xdc00 &&
					i + 1 < end && chars[i+1] >= 0xdc00
					&& chars[i+1] < 0xe000)
						i++;
				bytes[o1++] = (byte)'?';
			}
		}
	}
	if (o1 < bytes.length) {
		byte[] newBytes = new byte[o1];
		System.arraycopy(bytes, 0, newBytes, 0, o1);
		return newBytes;
	}
	return bytes;
}
}
