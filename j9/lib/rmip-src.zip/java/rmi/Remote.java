package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This (empty) interface should be super interface of
 * all remote interfaces which specify messages
 * that can be sent remotely.
 *
 * @author		OTI
 * @version		initial
 *
 * @see			java.rmi.server.UnicastRemoteObject
 */
public interface Remote {

}
