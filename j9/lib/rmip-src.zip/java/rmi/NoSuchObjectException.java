package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when a remote call in made to an
 * object that no longer exists.
 *
 * @author		OTI
 * @version		initial
 */
public class NoSuchObjectException extends RemoteException {

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public NoSuchObjectException(String s){
	super(s);
}
}
