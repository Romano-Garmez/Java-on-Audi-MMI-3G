package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when an IOException occurs while serializing
 * the objects to make a remote call.
 *
 * @author		OTI
 * @version		initial
 */
public class MarshalException extends RemoteException {

private static final long serialVersionUID =6223554758134037936L;

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public MarshalException(String s){
	super(s);
}

/**
 * Constructs a new instance of this class with its
 * walkback, message and nested exception filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 * @param		ex Exception
 *					the exception being wrapped by this new instance.
 *
 * @author		OTI
 * @version		initial
 */
public MarshalException(String s, Exception ex){
	super(s, ex);
}
}
