package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when an exception occurs in
 * the server while it is executing a remote call.
 *
 * @author		OTI
 * @version		initial
 */
public class ServerException extends RemoteException {

private static final long serialVersionUID =-4775845313121906682L;

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public ServerException(String s){
	super(s);
}

/**
 * Constructs a new instance of this class with its
 * walkback, message and nested exception filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 * @param		ex Throwable
 *					the exception being wrapped by this new instance.
 *
 * @author		OTI
 * @version		initial
 */
public ServerException(String s, Exception ex){
	super(s, ex);
}

}
