package java.rmi.dgc;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.rmi.server.*;
import com.ibm.oti.rmi.dgc.*;
import com.ibm.oti.rmi.UnicastRef;

/**
 * An instance of this object is a unique identifier to
 * all running java vms in a distributed application.
 *
 * @author		OTI
 * @version		initial
 */
public final class VMID implements java.io.Serializable {

private static final long serialVersionUID =-538642295484486218L;

/*
 * Has the host IP address
 */
byte[] addr;
/*
 * Has a host unique identifier.
 */
UID uid;

private static InetAddress localAddress;

static {
	try {
		localAddress = InetAddress.getLocalHost();
	} catch (UnknownHostException e) {
	}
}

/**
 * Constructs a new instance of VMID which is a unique
 * identifier for a java virtual machine (vm).
 *
 * @author		OTI
 * @version		initial
 */
public VMID() {
	if(localAddress != null)
		addr = localAddress.getAddress();
	uid = new UID();
}

/**
 * Compares the argument to the receiver and answers true
 * if they represent the <em>same</em> object using a class
 * specific comparison. Answers true only if the argument
 * identifies the same vm as the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		o Object
 *					the object to compare with this object.
 * @return		boolean
 *					<code>true</code>
 *						if the object identifies the same vm as the receiver.
 *					<code>false</code>
 *						if it identifies a different vm from this object.
 * @see			hashCode
 */
public boolean equals(Object o) {
	if(!(o instanceof VMID))
		return false;

	VMID id = (VMID)o;
	if((this.uid != null) && (this.uid.equals(id.uid))) {
		if(this.addr != null) {
			if(this.addr.length != id.addr.length)
				return false;
			for(int i=0;i<this.addr.length;i++)
				if(this.addr[i]	!= id.addr[i])
					return false;
		}
		return true;
	}
	return false;
}

/**
 * Answers an integer hash code for the receiver. Any two
 * objects which answer <code>true</code> when passed to
 * <code>.equals</code> must answer the same value for this
 * method.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		int
 *					the receiver's hash.
 *
 * @see			equals
 */
public int hashCode () {
	return uid.hashCode() * addr[addr.length - 1];
}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String toString() {
	if(addr == null)
		return "VMID:[0.0.0.0|" + uid + "]";
	return "VMID:[" + (int)addr[0] + "." + (int)addr[1] + "." + (int)addr[2] + "." + (int)addr[3] +  "||" + uid + "]";
}

}
