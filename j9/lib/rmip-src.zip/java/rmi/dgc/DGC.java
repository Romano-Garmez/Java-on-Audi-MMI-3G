package java.rmi.dgc;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;
import java.rmi.server.*;

/**
 * This interface defines the API for the distributed garbage collector.
 * The distributed garbage collector is a remote object always exported
 * on the server side. It defines two remote methods witch are called
 * by the client every once in a while to keep its references alive.
 *
 * @author		OTI
 * @version		initial
 */
public interface DGC extends Remote {

/**
 * This call is made every time that a remote object is deserialized in
 * the client size. It will answer a Lease object specifying how long
 * the server will keep the object's ids alive.
 * The client needs to re-send this message before the lease time
 * expires otherwise the reference to the remote object will become
 * invalid.
 *
 * @param		ids ObjID[]
 *					the ids of the objects that the client wants to renew
 * 					the lease for.
 * @param		sequenceNum long
 *					it is a way to detect late calls.
 * @param		lease Lease
 *					it specifies how long the client wants to renew the
 *					leases for.
 * @return		Lease
 *					it specifies how long a lease the server granted.
 *
 * @author		OTI
 * @version		initial
 */
public Lease dirty (ObjID[] ids, long sequenceNum, Lease lease) throws java.rmi.RemoteException;

/**
 *
 * This call is made by the client whenever a reference to a
 * remote object is not needed anymore.
 *
 * @param		ids ObjID[]
 *					the ids of the objects that the client does not reference
 * 					anymore.
 * @param		sequenceNum long
 *					it is a way to detect late calls.
 * @param		vmid VMID
 *					the client's VMID.
 * @param		strong boolean
 *					true when the clean call is the result of a failed
 *					dirty call, false otherwise.
 *
 * @author		OTI
 * @version		initial
 */
public void clean (ObjID [] ids, long sequenceNum, VMID vmid, boolean strong) throws java.rmi.RemoteException;

}
