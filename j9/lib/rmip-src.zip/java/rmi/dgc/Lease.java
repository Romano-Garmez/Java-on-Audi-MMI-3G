package java.rmi.dgc;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 *
 * This class is used by the distributed garbage collector
 * as result and as parameter of a dirty call.
 *
 * When the client calls dirty it requests a lease time - how
 * long the server should keep the remote object alive - the server
 * may answer to the client with a lease time shorter than the
 * requested one.
 *
 * @author		OTI
 * @version		initial
 */
public final class Lease implements java.io.Serializable  {

private static final long serialVersionUID =-5713411624328831948L;

long value;
VMID vmid;

/**
 * Constructs a new instance of Lease specifying the lease duration
 * and the client's VMID.
 *
 * @param		id VMID
 *					the VMID of the client that is leasing the object.
 * @param		duration long
 *					the time that the lease is asked or granted for.
 *
 * @author		OTI
 * @version		initial
 */
public Lease(VMID id,long duration) {
	vmid = id;
	value = duration;
}

/**
 *
 * Answers the time that the remote object associated with the
 * receiver was leased for.
 *
 * @return		long
 *					the time that the lease was asked or granted for.
 *
 * @author		OTI
 * @version		initial
 */
public long getValue () {
	return value;
}

/**
 *
 * Answers the VMID of the client that is leasing the object associated
 * with the receiver.
 *
 * @return		VMID
 *					the client's VMID.
 *
 * @author		OTI
 * @version		initial
 */
public VMID getVMID () {
	return vmid;
}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String toString() {
	return "Lease:[" + value + "||" + vmid + "]";
}

}
