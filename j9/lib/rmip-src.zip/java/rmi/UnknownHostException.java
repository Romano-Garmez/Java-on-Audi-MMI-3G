package java.rmi;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when a java.net.UnknownHostException
 * occurs while connected to the remote host
 *
 * @author		OTI
 * @version		initial
 */
public class UnknownHostException extends RemoteException {

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public UnknownHostException(String s){
	super(s);
}

/**
 * Constructs a new instance of this class with its
 * walkback, message and nested exception filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 * @param		ex Exception
 *					the exception being wrapped by this new instance.
 *
 * @author		OTI
 * @version		initial
 */
public UnknownHostException(String s, Exception ex){
	super(s, ex);
}
}
