package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when an attempt to bind and object
 * that is already bound is made.
 *
 * @author		OTI
 * @version		initial
 */
public class AlreadyBoundException extends java.lang.Exception {

/**
 * Constructs a new instance of this class with its
 * walkback filled in.
 *
 * @author		OTI
 * @version		initial
 */
public AlreadyBoundException() {
	super();
}

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public AlreadyBoundException(String s) {
	super(s);
}

}
