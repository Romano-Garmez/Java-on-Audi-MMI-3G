package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This object represents a Unique ID that can be used
 * as an address space.
 *
 * @author		OTI
 * @version		initial
 */
public final class UID implements java.io.Serializable {

private static final long serialVersionUID = 1086053664494604050L;

static short instanceCount = 0;
private static long loadTime = System.currentTimeMillis();
private static Random random;

static {
	try {
		random = new java.security.SecureRandom();
	} catch (RuntimeException ex) {
		random = new Random();
	}
}

short count;
long time;
int unique;

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
public UID() {
	instanceCount++;
	count = instanceCount;
	unique = random.nextInt();
	time = loadTime;
}

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
public UID(short num) {
	count = num;
	time = 0;
	unique = 0;
}

/**
 * Compares the argument to the receiver and answers true
 * if they represent the <em>same</em> object using a class
 * specific comparison. The implementation in Object answers
 * true only if the argument is the exact same object as the
 * receiver (==).
 *
 * @author		OTI
 * @version		initial
 *
 * @param		o Object
 *					the object to compare with this object.
 * @return		boolean
 *					<code>true</code>
 *						if the object is the same as this object
 *					<code>false</code>
 *						if it is different from this object.
 * @see			hashCode
 */
public boolean equals(Object obj) {
	if(obj instanceof UID) {
		UID o = (UID)obj;
		return ((time == o.time) &&
			(count == o.count) &&
			(unique == o.unique));
	}
	return false;
}

/**
 * Answers an integer hash code for the receiver. Any two
 * objects which answer <code>true</code> when passed to
 * <code>.equals</code> must answer the same value for this
 * method.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		int
 *					the receiver's hash.
 *
 * @see			equals
 */
public int hashCode() {
	return count;
}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String toString() {
	return "UID:[" + unique + ":" + time + ":" + count + "]";
}

/**
 * Writes the receiver to <code>out</code>.
 *
 * @param		out DataOutput
 *					the strem where the object should write itself.
 *
 * @author		OTI
 * @version		initial
 */
public void write(DataOutput out) throws IOException {
	out.writeInt(unique);
	out.writeLong(time);
	out.writeShort(count);
}

/**
 * Reads a UID from the stream <code>in</code> and
 * answers a new instance initialized with the data
 * read from the stream.
 *
 * @param		in DataInput
 *					the stream where the new UID should be read from.
 *
 * @author		OTI
 * @version		initial
 */
public static UID read(DataInput in) throws IOException {
	int u = in.readInt();
	long t = in.readLong();
	short c = in.readShort();
	UID uid = new UID(c);
	uid.time = t;
	uid.unique = u;
	return uid;
}
}
