package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import com.ibm.oti.rmi.*;

/**
 * An instance of this class is an identifier to
 * a remote object.
 *
 * @author		OTI
 * @version		initial
 */
public final class ObjID implements java.io.Serializable {

public static final int REGISTRY_ID = 0;
public static final int ACTIVATOR_ID = 1;
public static final int DGC_ID = 2;

private static final long serialVersionUID =-6386392263968365220L;

long objNum;
UID space;

static long instanceCount = 3;

/**
 * Constructs a new instance of this class.
 * Initializes it with its address space (UID)
 * and its object number which is a unique
 * identifier in the defined address space.
 *
 * @author		OTI
 * @version		initial
 */
public ObjID() {
	space = UnicastRef.LocalUID;
/*
 * The first digit is reserved for internal IDs such as REGISTRY_ID, DGC_ID ...
 * The second one is the index of the ObjID in the RMIServerTable.
 */
	objNum = instanceCount * 100;
	objNum += (RMIServerTable.idIndex() * 10);
	instanceCount++;
}

/**
 * Answers a new instance of this class using
 * the specified object number and initializes
 * its address space to 'zero'.
 *
 * @param		num int
 *					the ObjID's number.
 *
 * @author		OTI
 * @version		initial
 */
public ObjID(int num) {
	space = new UID((short)0);
	objNum = num;
}

/**
 * Creates a new instance of this class using the
 * specified address space (UID) and object number.
 *
 * @param		num int
 *					the ObjID's number.
 * @param		s UID
 *					the ObjID's address space.
 *
 * @author		OTI
 * @version		initial
 */
private ObjID(long num,UID s) {
	space = s;
	objNum = num;
}

/**
 * Writes the receiver's properties into an ObjectOutput.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		out ObjectOutput
 *					the stream where the object will be written into.
 *
 */
public void write (ObjectOutput out) throws IOException {
	out.writeLong(objNum);
	space.write(out);
}

/**
 * Reads and answers a new ObjID from an ObjectInput.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		in ObjectInput
 *					the stream where the object will be read from.
 *
 * @return		ObjID
 */
public static ObjID read(ObjectInput in) throws IOException {
	return new ObjID(in.readLong(),UID.read(in));

}

/**
 * Answers an integer hash code for the receiver. Any two
 * objects which answer <code>true</code> when passed to
 * <code>.equals</code> must answer the same value for this
 * method.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		int
 *					the receiver's hash.
 *
 * @see			equals
 */
public int hashCode() {
	return (int)objNum;
}

/**
 * Compares the argument to the receiver, and answers true
 * if they represent the <em>same</em> object using a class
 * specific comparison. The implementation in Object answers
 * true only if the argument is the exact same object as the
 * receiver (==).
 *
 * @author		OTI
 * @version		initial
 *
 * @param		o Object
 *					the object to compare with this object.
 * @return		boolean
 *					<code>true</code>
 *						if the object is the same as this object
 *					<code>false</code>
 *						if it is different from this object.
 * @see			hashCode
 */
public boolean equals(Object obj) {
	if(obj instanceof ObjID) {
		ObjID o = (ObjID)obj;
		return ((objNum == o.objNum) && (space.equals(o.space)));
	}
	return false;

}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String toString() {
	return "ObjID:[" + objNum + "]";
}
}
