package java.rmi.server;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import com.ibm.oti.rmi.*;

/**
 * This class implements a set of static methods that can
 * be used to set/get the socket factory used by the RMI
 * implementation to create servers and clients sockets.
 *
 * @author		OTI
 * @version		initial
 */
public abstract class RMISocketFactory implements RMIClientSocketFactory, RMIServerSocketFactory {

private static final RMISocketFactory defaultSocketFactory = new DefaultSocketFactory();
private static RMISocketFactory socketFactory = null;
private static RMIFailureHandler failureHandler = null;

/**
 * Creates and answers a new java.net.Socket connecting
 * it to the specified host and port.
 *
 * @author		OTI
 * @version		initial
 */
public abstract Socket createSocket(String host, int port) throws IOException;

/**
 * Creates and answers a new java.net.ServerSocket that
 * will be used to accept RMI connections in the specified
 * port.
 *
 * @author		OTI
 * @version		initial
 */
public abstract ServerSocket createServerSocket(int port) throws IOException;

/**
 * Sets the factory that the RMI implementation should use
 * to create sockets.
 *
 * @author		OTI
 * @version		initial
 */
public static void setSocketFactory(RMISocketFactory fac) throws IOException {
	SecurityManager security = System.getSecurityManager();
	if (security != null)
		security.checkSetFactory();
	if(socketFactory != null) {
		throw new IOException(com.ibm.oti.rmi.util.Msg.getString("R0048"));
	}
	socketFactory = fac;
}

/**
 * Answers the factory that the RMI implementation should use
 * to create sockets.
 *
 * @author		OTI
 * @version		initial
 */
public static RMISocketFactory getSocketFactory() {
	return socketFactory;
}

/**
 * Answers the default factory used by RMI to create sockets.
 * @author		OTI
 * @version		initial
 */
public static RMISocketFactory getDefaultSocketFactory() {
	return defaultSocketFactory;
}

/**
 * Sets an RMIFailureHandler which is an object that
 * answers to the failure message which is sent
 * when the socket creation fails inside the server.
 *
 * This method first calls SecurityManager.checkSetFactory before setting the
 * RMIFailureHandler.
 *
 * @author		OTI
 * @version		initial
 */
public static void setFailureHandler (RMIFailureHandler fh) {
	SecurityManager security = System.getSecurityManager();
	if (security != null)
		security.checkSetFactory();
	failureHandler = fh;
}

/**
 * Answers the RMIFailureHandler which is an object that
 * answers to the failure message that is sent
 * when the socket creation fails inside the server.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIFailureHandler getFailureHandler() {
	return failureHandler;
}

}
