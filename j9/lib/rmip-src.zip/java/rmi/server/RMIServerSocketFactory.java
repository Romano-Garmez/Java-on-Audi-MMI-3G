package java.rmi.server;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This interface specifies the API that a socket factory
 * should implement.
 *
 * @author		OTI
 * @version		initial
 */
public interface RMIServerSocketFactory {

/**
 * Creates and answers a new java.net.ServerSocket that
 * will be used to accept RMI connections in the specified
 * port.
 *
 * @author		OTI
 * @version		initial
 */
public java.net.ServerSocket createServerSocket(int port) throws java.io.IOException;
}
