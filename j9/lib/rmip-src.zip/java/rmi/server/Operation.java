package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * Instances of this class were used in the JDK1.1
 * to represent a remote method.
 * It is not used in the Java2 RMI protocol but
 * it is still used in this implementation to
 * be compatible with JDK1.1.x.
 *
 * @author		OTI
 * @version		initial
 *
 * @deprecated
 */
public class Operation {

private String opString;

/**
 * Constructs a new instance of this class.
 * Initializes the new instance with the specified
 * operation string.
 *
 * @param		op String
 *					a variation of the method signature.
 *
 * @author		OTI
 * @version		initial
 */
public Operation(String op) {
	opString = op;
}

/**
 * Answers a string containing a concise, human-readable
 * description of the remote object that the receiver
 * refers to.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation of the receiver.
 */
public String toString() {
	return opString;
}
}
