package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This interface specifies an API that can be implemented
 * by the RMI application and will be called when
 * the server fails to create a new client socket.
 *
 * @author		OTI
 * @version		initial
 */
public interface RMIFailureHandler {

/**
 * Called by the RMI implementation when
 * a socket client creation fails inside the
 * server thread.
 *
 * @author		OTI
 * @version		initial
 */
public boolean failure(Exception ex);
}
