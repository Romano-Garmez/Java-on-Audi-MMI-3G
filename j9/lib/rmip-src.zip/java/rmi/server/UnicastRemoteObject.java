package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;
import java.io.*;
import java.lang.reflect.*;
import com.ibm.oti.rmi.*;
import com.ibm.oti.rmi.wire.*;
import com.ibm.oti.rmi.dgc.*;
import com.ibm.oti.rmi.registry.*;

/**
 * This is a default superclass for all remote objects.
 * The user can opt to subclass any other class but
 * the remote object will not be exported automatically
 * like in the subclasses of UnicastRemoteObject. As well,
 * the user will have to implement <code>hashCode</code>,
 * <code>equals</code>, and <code>toString</code>.
 *
 * @author		OTI
 * @version		initial
 */
public class UnicastRemoteObject extends RemoteServer {

private static final long serialVersionUID = 4974527148936298033L;

RMIClientSocketFactory csf;
int port;
RMIServerSocketFactory ssf;

/**
 * Constructs a new instance of this class. The object will
 * be exported in a free TCP port.
 *
 * @author		OTI
 * @version		initial
 */
protected UnicastRemoteObject() throws RemoteException {
	this(0);
}

/**
 * Constructs a new instance of this class. The object will
 * be exported in the specified port. An exception will be
 * thrown if the port is already in use.
 *
 * @param		portNumber int
 *					the TCP port where the object should be exported on.
 *
 * @author		OTI
 * @version		initial
 */
protected UnicastRemoteObject(int portNumber) throws RemoteException {
	this(portNumber,null,null);
}

/**
 * Constructs a new instance of this class. The object will
 * be exported in the specified port. An exception will be
 * thrown if the port is already in use.
 *
 * @param		portNumber int
 *					the TCP port where the object should be exported on.
 * @param		csf RMIClientSocketFactory
 *					the factory that should be used to create sockets.
 * @param		ssf RMIServerSocketFactory
 *					the factory that should be used to create server sockets.
 *
 * @author		OTI
 * @version		initial
 */
protected UnicastRemoteObject(int portNumber,RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws RemoteException {
	this.port = portNumber;
	this.csf = csf;
	this.ssf = ssf;
	exportObject(this,port,csf,ssf);
}

/**
 * Answers a new instance of the same class as the receiver,
 * whose slots have been filled in with the values in the
 * slots of the receiver.
 * <p>
 * Classes that wish to support cloning must specify that
 * they implement the Cloneable interface, since the native
 * implementation checks for this.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		Object
 *					a shallow copy of this remote object.
 * @exception	CloneNotSupportedException
 *					if a RemoteException occur during cloning.
 */
public Object clone() throws CloneNotSupportedException {
	try {
		UnicastRemoteObject clone = (UnicastRemoteObject)super.clone();
		exportObject(clone,clone.port,clone.csf,clone.ssf);
		return clone;
	} catch (RemoteException ex) {
		throw new ServerCloneException(com.ibm.oti.rmi.util.Msg.getString("R0049"),ex);
	}
}

/**
 * Exports the object <code>obj</code> in the next TCP free port.
 *
 * @param		obj Remote
 *					the object to be exported.
 *
 * @author		OTI
 * @version		initial
 */
public static RemoteStub exportObject(Remote obj) throws java.rmi.RemoteException {
	return (RemoteStub)exportObject(obj,0);
}

/**
 * Exports the object <code>obj</code> in the specified port.
 *
 * @param		obj Remote
 *					the object to be exported.
 * @param		port int
 *					the port where the object should be exported in.
 *
 * @author		OTI
 * @version		initial
 */
public static Remote exportObject(Remote obj,int port) throws java.rmi.RemoteException {
	return exportObject(obj,port,null,null);
}

/**
 * Exports the object <code>obj</code> in the specified port.
 *
 * @param		obj Remote
 *					the object to be exported.
 * @param		port int
 *					the port where the object should be exported in.
 * @param		csf RMIClientSocketFactory
 *					the factory that should be used to create sockets.
 * @param		ssf RMIServerSocketFactory
 *					the factory that should be used to create server sockets.
 *
 * @author		OTI
 * @version		initial
 */
public static Remote exportObject(Remote obj,int port,RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws java.rmi.RemoteException {
	try {
		ObjID id;
		if(!(obj instanceof RegistryImpl))
			DGCImpl.initDGC();
		if(obj instanceof DGCImpl) {
			id = new ObjID(ObjID.DGC_ID);
		} else {
			if(ssf == null)
				ssf = RMISocketFactory.getSocketFactory();
			if(ssf == null)
				ssf = RMISocketFactory.getDefaultSocketFactory();

			RMIServer server = RMIServer.serverFor(port,Protocol.StreamProtocol,ssf);
			port = server.getLocalPort();
			if(obj instanceof RegistryImpl)
				id = new ObjID(ObjID.REGISTRY_ID);
			else
				id = new ObjID();
		}
		if(RMIServerTable.getObj(id) != null) {
			throw new ExportException(com.ibm.oti.rmi.util.Msg.getString("R0050"));
		}

		if (obj instanceof RemoteObject){
			RemoteRef serverRef=null;
			if (csf == null)
				serverRef = new UnicastServerRef(port, id);
			else
				serverRef = new UnicastServerRef2(port, id, csf,ssf);
			((RemoteObject) obj).ref = serverRef;
		}

		RemoteRef ref = null;
		if (csf == null)
			ref = new UnicastRef(port, id);
		else
			ref = new UnicastRef2(port, id, csf);

		if((obj instanceof DGCImpl) || (obj instanceof RegistryImpl))
			((UnicastRef)ref).setDeathTime(Long.MAX_VALUE); //DGC and Registry never die;

		String annotation = RMIClassLoader.getClassAnnotation(obj.getClass());
		Class objClass = obj.getClass();
		Class objStubClass = (objClass == DGCImpl.class) || (objClass == RegistryImpl.class)
			? Class.forName(objClass.getName() + "_Stub") // avoids packageAccessCheck
			: RMIClassLoader.loadClass(annotation, objClass.getName() + "_Stub");
		RemoteStub stub;
		try {
			Constructor c = objStubClass.getConstructor(new Class[]{RemoteRef.class});
			stub = (RemoteStub)c.newInstance(new Object[]{ref});
		} catch (NoSuchMethodException ex) {
//			stub = (RemoteStub)objStubClass.newInstance();
//			RemoteStub.setRef(stub,ref);
			throw new RemoteException(null, ex);
		} catch (InvocationTargetException ex) {
//			stub = (RemoteStub)objStubClass.newInstance();
//			RemoteStub.setRef(stub,ref);
			throw new RemoteException(null, ex);
		} catch (InstantiationException ex) {
//			stub = (RemoteStub)objStubClass.newInstance();
//			RemoteStub.setRef(stub,ref);
			throw new RemoteException(null, ex);
		}
		RMIServerTable.putServer(obj,stub,id);
		return stub;
	} catch (ExportException ex) {
		throw ex;
	} catch (ClassNotFoundException ex) {
		throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0004",obj.getClass().getName() + "_Stub"), ex);
	} catch (IllegalAccessException ex) {
		throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0005",obj.getClass().getName() + "_Stub(RemoteRef r)"), ex);
//	} catch (InstantiationException ex) {
///*[MSG "R0006", "Could not instantiate {0}"]*/
//		throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString(obj.getClass().getName() + "_Stub"), ex);
	} catch (IOException ex) {
		throw new ExportException(com.ibm.oti.rmi.util.Msg.getString("R0051", obj), ex);
	}
}

/**
 * Unexports the object <code>obj</code>.
 *
 * @param		obj Remote
 *					the object to be unexported.
 * @param		force boolean
 *					if false wait until all pending calls are finished otherwise
 *					unexport it without waiting.
 *
 * @author		OTI
 * @version		initial
 */
public static boolean unexportObject(Remote obj,boolean force) throws java.rmi.NoSuchObjectException {
	RemoteStub stub = RMIServerTable.getStub(obj);
	if (stub==null)
		throw new NoSuchObjectException("null");
	if (RMIServerTable.removeServer(obj, force)) {
		UnicastRef ref = (UnicastRef)stub.getRef();
		RMIServer s = RMIServer.serverFor(ref.getPort());
		if(s != null)
			s.decReference();
		return true;
	} else
		return false;
}

}
