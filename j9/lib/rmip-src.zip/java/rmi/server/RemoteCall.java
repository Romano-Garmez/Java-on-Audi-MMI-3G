package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;

/**
 * This interface defines an API to be used from
 * the stubs and skeletons to make the actual remote
 * call.
 *
 * @author		OTI
 * @version		initial
 *
 * @deprecated
 */
public interface RemoteCall {
}
