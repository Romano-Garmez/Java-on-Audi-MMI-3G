package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;
import java.io.*;
import com.ibm.oti.rmi.*;

/**
 * This is the super-class of all remote objects classes.
 *
 * @author		OTI
 * @version		initial
 */
public abstract class RemoteObject implements java.io.Serializable, java.rmi.Remote {

private static final long serialVersionUID =-3215090123894869218L;

/**
 * The remote reference of the object.
 */
protected transient RemoteRef ref;

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
protected RemoteObject() {
}

/**
 * Constructs a new instance of this class.
 * Initializes its reference with r.
 *
 * @param		r RemoteRef
 *
 * @author		OTI
 * @version		initial
 *
 */
protected RemoteObject(RemoteRef r) {
	ref = r;
}

/**
 * Answers the receiver's reference.
 *
 * @return		RemoteRef
 *
 * @author		OTI
 * @version		initial
 */
public RemoteRef getRef() {
	return ref;
}

/**
 * Answers the remote object's stub which is created
 * at exporting time.
 * Fails if the object is not exported yet.
 *
 * @author		OTI
 * @version		initial
 */
public static Remote toStub(Remote obj) throws NoSuchObjectException {
	if (obj==null){
		throw new NoSuchObjectException(com.ibm.oti.rmi.util.Msg.getString("R0044"));
	}

	if(obj instanceof RemoteStub)
		return obj;
	Remote o = RMIServerTable.getStub(obj);
	if(o == null) {
		throw new NoSuchObjectException(com.ibm.oti.rmi.util.Msg.getString("R0044"));
	}
	return o;
}

/**
 * Answers an integer hash code for the receiver. Any two
 * objects which answer <code>true</code> when passed to
 * <code>.equals</code> must answer the same value for this
 * method.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		int
 *					the receiver's hash.
 *
 * @see			equals
 */
public int hashCode() {
	int hash;
	if(ref == null)
		hash = super.hashCode();
	else
		hash = ref.remoteHashCode();
	return hash;
}

/**
 * Compares the argument to the receiver and answers true
 * if they represent the <em>same</em> object using a class
 * specific comparison. The implementation in Object answers
 * true only if the argument is the exact same object as the
 * receiver (==).
 *
 * @author		OTI
 * @version		initial
 *
 * @param		o Object
 *					the object to compare with this object.
 * @return		boolean
 *					<code>true</code>
 *						if the object is the same as this object
 *					<code>false</code>
 *						if it is different from this object.
 * @see			hashCode
 */
public boolean equals(Object obj) {
	if(obj instanceof RemoteObject) {
		RemoteObject o = (RemoteObject)obj;
		if (ref!=null && o.ref !=null)
			return ref.remoteEquals(o.ref);
		else
			return super.equals(obj);
	}
	return false;
}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String toString() {
	if(ref == null)
		return super.toString();
	return this.getClass().getName() + ":[" + ref.remoteToString() + "]";
}

/**
 * Reads a remote reference from an ObjectInputStream
 * and initializes the receiver.
 *
 * @author		OTI
 * @version		initial
 */
private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
	String refClassName = in.readUTF();
	if(refClassName.length() == 0) {
		in.readObject();
	} else {
		try {
			refClassName = RemoteRef.packagePrefix + "." + refClassName;
			//No need to used RMIClassLoader because 'refClassName' must be a system class.
			ref = (RemoteRef)Class.forName(refClassName).newInstance();
			ref.readExternal(in);
		} catch (IllegalAccessException ex) {
			throw new UnmarshalException(refClassName,ex);
		} catch (InstantiationException ex) {
			throw new UnmarshalException(refClassName,ex);
		}
	}
}

/**
 * Writes the receiver's reference into the
 * specified  ObjectOutputStream.
 *
 * @author		OTI
 * @version		initial
 */
private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
	if(ref == null) {
		throw new MarshalException(com.ibm.oti.rmi.util.Msg.getString("R0045"));
	}
	//We guaranty that getRefClass will never return null;

	String refClassName= ref.getRefClass(null);
	out.writeUTF(refClassName);
	if(refClassName.length() == 0)
		out.writeObject(ref);
	else
		ref.writeExternal(out);
}

}
