package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.net.*;
import java.io.*;
import java.util.*;
import com.ibm.oti.rmi.util.RMIUtil;
import java.security.AccessController;
import java.security.PrivilegedAction;

/**
 * This class implements the API that should be used
 * from RMI applications to load classes.
 *
 * @author		OTI
 * @version		initial
 */
public class RMIClassLoader {

private static String codebase;
private static boolean isCodebaseSet = false;

private RMIClassLoader() {}

private static WeakHashMap weakLoaders = new WeakHashMap(20);

/**
 * Answers back the ClassLoader for the given <code>codebase</code>
 * If a classloader for this <code>codebase</code> does not exist,
 * one is created.
 *
 * @author		OTI
 * @version		initial
 */
public static ClassLoader getClassLoader(String codebase)
                                  throws MalformedURLException,
                                         SecurityException {
	//if codebaseStr is null, return the classloader
	//for the codebase specified in the codebase system property
	if (codebase == null) codebase = getCodebase();
	if (codebase == null) codebase = "";

	StringTokenizer tokenizer = new StringTokenizer(codebase," ");
	String annotation="";
	URL urls[] = new URL[tokenizer.countTokens()];
	int i=0;
	while(tokenizer.hasMoreTokens()) {
		URL url = new URL(tokenizer.nextToken());
		checkPermission(url);
		urls[i] = url;
		i++;
		annotation=annotation + " " + url.toExternalForm();
	}
	if (!annotation.equals(""))
		annotation=annotation.trim();

	URLClassLoader cLoader = null;

	ClassLoader parent = com.ibm.oti.vm.VM.getNonBootstrapClassLoader();
	if (parent ==null)
		parent = Thread.currentThread().getContextClassLoader();

	synchronized(weakLoaders) {
		Hashtable loaders = (Hashtable)weakLoaders.get(parent);
		if (loaders == null) {
			loaders = new Hashtable(8);
			weakLoaders.put(parent, loaders);
		} else {
			cLoader = (URLClassLoader)loaders.get(annotation);
		}
		if(cLoader == null) {
			cLoader = URLClassLoader.newInstance(urls, parent);
			loaders.put(annotation, cLoader);
		}
	}
	return cLoader;
}

/**
 * convenience method for checking if the caller
 * has permission to access a url
 * @author		OTI
 * @version		initial
 */
private static void checkPermission(URL url) throws SecurityException {
	SecurityManager security = System.getSecurityManager();
	if (security != null) {
		try {
			security.checkPermission(url.openConnection().getPermission());
		} catch (IOException ex) {
			throw new SecurityException(
				com.ibm.oti.rmi.util.Msg.getString("R0046") + ": " + ex);
		}
	}
}

/**
 * Loads a class specified by <code>clName<code> using
 * the specified codebase to find the class.
 *
 * @author		OTI
 * @version		initial
 */
public static Class loadClass(URL codebase, String clName) throws java.net.MalformedURLException, java.lang.ClassNotFoundException {
	if (codebase == null) return loadClass(getCodebase(), clName);
	return loadClass(codebase.toExternalForm(),clName);
}

/**
 * Loads a class specified by <code>clName<code> using
 * the specified codebase to find the class.
 *
 * @author		OTI
 * @version		initial
 */
public static Class loadClass(String codebase, String clName) throws java.net.MalformedURLException, java.lang.ClassNotFoundException {
	if (codebase == null) codebase = getCodebase();
	ClassLoader cLoader = getClassLoader(codebase);
	return Class.forName(clName, true, cLoader);
}

/**
 * Answers that class's annotation which is a string
 * of codebases delimited by spaces.
 *
 * @author		OTI
 * @version		initial
 */
public static String getClassAnnotation (Class cl) {
	ClassLoader clClassLoader = cl.getClassLoader();
	if (clClassLoader==null)
		return null;

	ClassLoader cloader_nonboot = com.ibm.oti.vm.VM.getNonBootstrapClassLoader();
	ClassLoader	cloader_thread = Thread.currentThread().getContextClassLoader();
	ClassLoader	cloader_system = ClassLoader.getSystemClassLoader();

	if (clClassLoader.equals(cloader_nonboot) || clClassLoader.equals(cloader_thread) || clClassLoader.equals(cloader_system))
		return getCodebase();

	if (clClassLoader instanceof URLClassLoader) {
		URLClassLoader urlClassLoader = (URLClassLoader)clClassLoader;
		URL urls[] = urlClassLoader.getURLs();
		String annotation = "";
		for (int i=0;i<urls.length;i++)
			annotation = annotation + " " + urls[i].toExternalForm();
		if (!annotation.equals(""))
			annotation=annotation.trim();
		return annotation;
	}
	return getCodebase();
}

/**
 * Answers the value of the property "java.rmi.server.codebase";
 *
 * @author		OTI
 * @version		initial
 */
private static String getCodebase() {
	if(isCodebaseSet)
		return codebase;
	codebase = (String)AccessController.doPrivileged(new PrivilegedAction() {
		public Object run() {
			return System.getProperty("java.rmi.server.codebase");
		}});
	isCodebaseSet = true;
	return codebase;
}

}
