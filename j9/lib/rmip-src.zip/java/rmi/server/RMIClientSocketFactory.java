package java.rmi.server;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This interface specifies the API that a socket factory
 * should implement.
 *
 * @author		OTI
 * @version		initial
 */
public interface RMIClientSocketFactory {

/**
 * Creates and answers a new java.net.Socket connecting
 * it to the specified host and port.
 *
 * @author		OTI
 * @version		initial
 */
public java.net.Socket createSocket(String host,int port) throws java.io.IOException;

}
