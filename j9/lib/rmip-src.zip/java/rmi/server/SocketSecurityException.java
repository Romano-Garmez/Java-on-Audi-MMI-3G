package java.rmi.server;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown during an export if permission
 * to create a ServerSocket is not granted.
 *
 * @author		OTI
 * @version		initial
 */
public class SocketSecurityException extends java.rmi.server.ExportException {

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public SocketSecurityException(String s) {
	super(s);
}

/**
 * Constructs a new instance of this class with its
 * walkback, message and nested exception filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 * @param		ex Exception
 *					the exception being wrapped by this new instance.
 *
 * @author		OTI
 * @version		initial
 */
public SocketSecurityException(String s,Exception ex) {
	super(s,ex);
}
}
