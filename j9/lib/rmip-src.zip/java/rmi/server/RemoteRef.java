package java.rmi.server;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.Externalizable;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.rmi.Remote;
import java.rmi.server.*;

/**
 * Instances of this class are opaque references to remote objects.
 *
 * @author		OTI
 * @version		initial
 */
public abstract interface RemoteRef extends Externalizable {

public static final String packagePrefix = "com.ibm.oti.rmi";

public static final long serialVersionUID = 3632638527362204081L;

/**
 * Answers the name of the reference class.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		objout ObjectOutput
 *					The stream that the object will be written on.
 * @return		String
 *					The name of the reference class
 */
public String getRefClass (ObjectOutput objout);

/**
 * Invokes the given method on a remote object with the supplied
 * parameters.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		obj Remote
 *					The remote object to invoke the method on.
 * @param		method Method
 *					The method to invoke.
 * @param		parms Object[]
 *					The parameters to the method.
 * @param		code long
 *					A function code to help in lookup.
 * @return		Object
 *					The result of invoking the method.
 *
 * @exception	Exception
 *					If an exception occurs while invoking the method.
 */
public Object invoke (Remote obj, Method method, Object[] parms, long opnum)
	throws Exception;

/**
 * Answers the hash of the remote object. Note that two
 * RemoteRefs which refer to the same remote object must answer
 * the same remoteHashCode.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		int
 *					The hash of the remote object.
 *
 * @see			remoteEquals
 */
public int remoteHashCode ();

/**
 * Compares the remote object which the argument refers to
 * to the remote object that the receiver refers to, and
 * answers true if they represent the <em>same</em> object
 * using a class specific comparison.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		o RemoteRef
 *					the object to compare with this object.
 * @return		boolean
 *					<code>true</code>
 *						if the remote objects are equal.
 *					<code>false</code>
 *						if they are different.
 *
 * @see			remoteHashCode
 */
public boolean remoteEquals (RemoteRef o);

/**
 * Answers a string containing a concise, human-readable
 * description of the remote object that the receiver
 * refers to.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation of the remote object.
 */
public String remoteToString ();

}
