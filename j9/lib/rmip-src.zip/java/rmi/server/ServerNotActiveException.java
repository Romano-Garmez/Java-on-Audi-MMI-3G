package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when the message getClientHost()
 * is sent to a reference that has no client connected to it.
 *
 * @author		OTI
 * @version		initial
 */
public class ServerNotActiveException extends java.lang.Exception {

/**
 * Constructs a new instance of this class with its
 * walkback filled in.
 *
 * @author		OTI
 * @version		initial
 */
public ServerNotActiveException() {
	super();
}

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public ServerNotActiveException(String s) {
	super(s);
}
}
