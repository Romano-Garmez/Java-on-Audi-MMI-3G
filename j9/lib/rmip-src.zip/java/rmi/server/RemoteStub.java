package java.rmi.server;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This is the super class of all remote object's
 * stub classes.
 * @author		OTI
 * @version		initial
 */
public abstract class RemoteStub extends RemoteObject {

private static final long serialVersionUID = -1585587260594494182L;

/**
 * Constructs a new instance of this class without initializing
 * its reference.
 *
 * @author		OTI
 * @version		initial
 */
protected RemoteStub(){
	super();
}

/**
 * Constructs a new instance of this class initializing
 * its reference.
 *
 * @author		OTI
 * @version		initial
 */
protected RemoteStub(RemoteRef r){
	super(r);
}

}
