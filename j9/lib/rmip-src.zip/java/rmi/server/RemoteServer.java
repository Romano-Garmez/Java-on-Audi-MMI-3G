package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.OutputStream;
import java.io.PrintStream;
import java.security.AccessController;
import java.security.PrivilegedAction;

/**
 * This is the super class of all remote object servers.
 *
 * @author		OTI
 * @version		initial
 */
public abstract class RemoteServer extends RemoteObject {

private static final long serialVersionUID = -4100238210092549637L;

private static PrintStream log ;
private static boolean logCalls = false;

static {
	String logCallsProperty;
	logCallsProperty = (String)AccessController.doPrivileged(new PrivilegedAction() {
		public Object run() {
			return System.getProperty("java.rmi.server.logCalls", "false");
		}});
	logCalls = logCallsProperty.equalsIgnoreCase("true");
}

/**
 * Constructs a new instance of this class without initializing it.
 *
 * @author		OTI
 * @version		initial
 */
protected RemoteServer() {
}

/**
 * Constructs a new instance of this class
 * initializing its remote reference.
 *
 * @author		OTI
 * @version		initial
 */
protected RemoteServer(RemoteRef r) {
	super(r);
}

/**
 * Answers the receiver's client's host name or address.
 * This method can be used from inside a remote method
 * implementation to get the client that is calling it.
 * If used from anywhere else ServerNotActiveException
 * will be thrown.
 *
 * @author		OTI
 * @version		initial
 */
public static String getClientHost() throws ServerNotActiveException {
	String serverThreadPrefix = com.ibm.oti.rmi.wire.StreamProtocolServer.ThreadPrefix;

	String threadName = Thread.currentThread().getName();
	if (threadName == null || !threadName.startsWith(serverThreadPrefix))
		throw new ServerNotActiveException();

	return threadName.substring(serverThreadPrefix.length());
}

/**
 * Log RMI calls to the output stream <code>out</code>.
 * If <code>out</code> is passed as null, call logging will be turned off.
 *
 * @author		OTI
 * @version		initial
 * @param		out The output stream that will be used to log  RMI Calls.
 */
public static void setLog(OutputStream out) {
	//turn the logging off if out is null.
	if (out == null){
		log= null;
		logCalls= false;
	}
	else {
		log= new RMILogStream(out);
		logCalls= true;
	}
}

/**
 * Answers the print stream that has the RMI call log.
 *
 * @author		OTI
 * @version		initial
 *
 */
public static PrintStream getLog() {
	//if the logging has been turned off previously
	if (logCalls && log!=null)
		return new PrintStream(log);
	else
		return null;
}

}
