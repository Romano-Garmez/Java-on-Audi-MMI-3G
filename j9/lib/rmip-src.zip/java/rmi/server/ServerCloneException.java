package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;

/**
 * This exception is thrown when an exception occurs while
 * cloning a remote object.
 *
 * @author		OTI
 * @version		initial
 */
public class ServerCloneException extends java.lang.CloneNotSupportedException {

private static final long serialVersionUID = 6617456357664815945L;

/**
 * The nested exception.
 */
public Exception detail;

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public ServerCloneException(String s){
	super(s);
}

/**
 * Constructs a new instance of this class with its
 * walkback, message and nested exception filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 * @param		ex Exception
 *					the exception being wrapped by this new instance.
 *
 * @author		OTI
 * @version		initial
 */
public ServerCloneException(String s,Exception ex){
	super(s);
	detail = ex;
}

/**
 * Answers the extra information message that was provided
 * when the receiver was created. If no message was provided
 * at creation time then answer null.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		the receiver's message.
 */
public String getMessage () {
	if((detail == null) || (detail.getMessage() == null))
		return super.getMessage();
	if(super.getMessage() == null)
		return detail.getMessage();
	return super.getMessage() + "::" + detail.getMessage();
}

/**
 * Outputs a printable representation of the receiver's
 * walkback and its nested exception on the stream specified
 * by the argument.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		ps PrintStream
 *					the stream to write the walkback on.
 */
public void printStackTrace (PrintStream ps) {
	super.printStackTrace(ps);
	if(detail!=null)
		detail.printStackTrace(ps);
}

/**
 * Outputs a printable representation of the receiver's
 * walkback and its nested exception on System.err.
 *
 * @author		OTI
 * @version		initial
 */
public void printStackTrace() {
	printStackTrace(System.err);
}

/**
 * Outputs a printable representation of the receiver's
 * walkback and its nested exception on the writer specified
 * by the argument.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		pw	PrintWriter
 *					the writer to write the walkback on.
 */
public void printStackTrace(PrintWriter pw) {
	super.printStackTrace(pw);
	if(detail!=null)
		detail.printStackTrace(pw);
}
}
