package java.rmi.server;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This interface may be implemented by any server that
 * wishes to receive a callback when no more clients
 * have a reference the remote object.
 *
 * @author		OTI
 * @version		initial
 */
public interface Unreferenced {

/**
 * This method is sent by the RMI implementation
 * to any remote object that implements this interface
 * when there are no more clients referencing this object.
 *
 * It may be sent more that once.
 *
 * @author		OTI
 * @version		initial
 */
public void unreferenced();
}
