package java.rmi.server;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2002, 2003  All Rights Reserved
 */

import java.io.*;
import java.net.InetAddress;

/**
 * This class is used by <code>RemoteServer</code> to log RMI calls
 * and is for internal use only.
 *
 * @author		OTI
 * @version		initial
 *
 */
class RMILogStream extends java.io.PrintStream {

private StringBuffer sbuf;

protected RMILogStream(OutputStream out) {
	super(out);
}

/**
 * Writes the specified byte <code>oneByte</code> to this PrintStream.  Only
 * the low order byte of <code>oneByte</code> is written.  This implementation
 * writes <code>oneByte</code> to the target OutputStream.  If <code>oneByte</code> is
 * equal to the character <code>'\n'</code> and this PrintSteam is set to autoflush,
 * the target OutputStream is flushed.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		oneByte		the byte to be written
 *
 * @exception 	java.io.IOException	If an error occurs attempting to write to this FilterOutputStream.
 */
public void write(int oneByte) {
	if (out == null) {
		setError();
		return;
	}
	try {
		if (sbuf==null)
			sbuf= new StringBuffer();

		sbuf.append((char)oneByte);

		if ((oneByte & 0xFF) == '\n') {
			String prefix = (new java.util.Date()).toString() + ":RMI:RMI TCP Connection()-" + InetAddress.getLocalHost().getHostAddress() +  ":";
			String message = sbuf.toString();
			out. write((prefix + message).getBytes());
			out.flush();
			sbuf=null;
		}

	} catch (IOException e) {
		setError();
	}
}

/**
 * Writes <code>count</code> <code>bytes</code> from the byte array
 * <code>buffer</code> starting at <code>offset</code> to this
 * PrintStream.  This implementation writes the <code>buffer</code>
 * to the target OutputStream and if this PrintStream is set to
 * autoflush, flushes it. If an error occurs, set an error in this PrintStream
 * to <code>true</code>.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		buffer		the buffer to be written
 * @param		offset		offset in buffer to get bytes
 * @param		count		number of bytes in buffer to write
 *
 * @exception	java.lang.ArrayIndexOutOfBoundsException If offset or count are outside of bounds.
 */
public void write(byte[] buffer, int offset, int count) {
	if (buffer != null) {
		// avoid int overflow
		if (0 <= offset && offset <= buffer.length && 0 <= count && count <= buffer.length - offset) {
			if (out == null) {
				setError();
				return;
			}
			for (int i = offset; i < offset + count; i++)
				write(buffer[i]);
		} else {
			 throw new ArrayIndexOutOfBoundsException(com.ibm.oti.rmi.util.Msg.getString("R0047"));
		}
	} else throw new NullPointerException();
}

}
