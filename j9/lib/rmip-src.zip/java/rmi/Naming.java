
package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.net.*;
import java.rmi.server.*;
import java.rmi.registry.*;

/**
 * This class has the same set of methods as the interface registry.
 * Here methods are defined as static so they can be used without
 * having the reference to the registry.
 *
 * The registry maps a String to an Object. It is the bootstrap for
 * the RMI application. To send a message to a remote object
 * a reference to this object must be obtained by accessing the
 * registry. Once the first object is obtained other objects may be
 * passed as parameters of methods.
 *
 * @author		OTI
 * @version		initial
 */
public final class Naming {

/*
 * Do not allow the user to create instances of this class.
 */
private Naming() {}

/**
 * Answers a reference to a remote object specified by its name and
 * location.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in a URL format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @return		Remote
 *					the reference to the remote object.
 * @exception	MalformedURLException
 *					if a URL can not be instantiated from <code>url</code>.
 * @exception	NotBoundException
 *					if an object with this name/location was not found.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 *
 */
public static Remote lookup(String url) throws RemoteException, MalformedURLException, NotBoundException {
	Name n = new Name(url);
	Registry r = registryStub(n.host,n.port);
	return r.lookup(n.objName);
}

/**
 *
 * Binds the object name specified in <code>url</code> to the remote object
 * <code>obj</code> in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in an URL format
 *					without the protocol (ex "//hostName:portNumber/obName).
 * @param		obj Remote
 *					the remote object that should be bound with <code>url</code>.
 * @exception	MalformedURLException
 *					if a URL can not be instanciated from <code>url</code>.
 * @exception	AlreadyBoundException
 *					if an object with this name was already bound in the registry.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if <code>url</code> does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public static void bind(String url, Remote obj) throws java.rmi.AlreadyBoundException, java.net.MalformedURLException, java.rmi.RemoteException {
	if (obj==null)
		throw new NullPointerException();
	Name n = new Name(url);
	chechAccess(n.host);
	Registry r = registryStub(n.host,n.port);
	r.bind(n.objName,RemoteObject.toStub(obj));
}

/**
 *
 * Unbinds the object name specified in <code>url</code> to the remote object obj
 * in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in an URL format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @exception	MalformedURLException
 *					if a URL can not be instantiated from <code>url</code>
 * @exception	NotBoundException
 *					if an object with this name was not found in the registry.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if <code>url</code> does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public static void unbind(String url) throws java.rmi.RemoteException, java.rmi.NotBoundException, java.net.MalformedURLException {
	Name n = new Name(url);
	chechAccess(n.host);
	Registry r = registryStub(n.host,n.port);
	r.unbind(n.objName);
}

/**
 *
 * Binds the object name specified in <code>url</code> to the remote object obj
 * in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in a URL format
 *					without the protocol (ex "//hostName:portNumber/obName).
 * @exception	MalformedURLException
 *					if a URL can not be instantiated from <code>url</code>.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if <code>url</code> does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public static void rebind (String url,Remote obj) throws java.rmi.RemoteException, java.net.MalformedURLException {
	if (obj==null)
		throw new NullPointerException();
	Name n = new Name(url);
	chechAccess(n.host);
	Registry r = registryStub(n.host,n.port);
	r.rebind(n.objName,RemoteObject.toStub(obj));
}

/**
 * Answers an array of Strings with all the names of the objects
 * bound in the registry specified by host and port in <code>url</code>.
 * The file part of the <code>url</code> is ignored.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the registry location in a URL format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @return		String[]
 *					a list with all the object bound in the registry.
 * @exception	MalformedURLException
 *					if a URL can not be instantiated from <code>url</code>
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 *
 */
public static String[] list(String url) throws java.rmi.RemoteException, java.net.MalformedURLException {
	Name n = new Name(url);
	Registry r = registryStub(n.host,n.port);

	if (!url.endsWith("/"))
		url=url + "/";

	String newList[] = r.list();
	for (int i=0;i<newList.length; i++) {
		newList[i]= url + newList[i];
	}
	return newList;
}

/*
 * Answers the reference to a registry.
 */
private static void chechAccess(String host) throws AccessException, RemoteException {
	if((host.equals("localhost")) || (host.equals("127.0.0.1")))
		return;
	try {
		if(InetAddress.getByName(host).equals(InetAddress.getLocalHost()))
			return;
	} catch (java.net.UnknownHostException e) {
		throw new java.rmi.UnknownHostException(com.ibm.oti.rmi.util.Msg.getString("R0055") + host,e);
	}
	throw new AccessException("A remote object can not be bound in a registry in another host.");
}

/*
 * Answers the reference to a registry.
 */
private static Registry registryStub(String host, int port) throws java.rmi.RemoteException {
	return LocateRegistry.getRegistry(host,port);
}

/*
 * This inner class is responsable for parsing a URL and keeping the
 * host name, port, and object name. URL can not be used directly
 * since the API implemented by the class Naming does not allow the
 * urls to define the protocol.
 */
static class Name {
	String host;
	int port;
	String objName;
	Name(String urlString) throws java.net.MalformedURLException{
		URL url;
		if(urlString.startsWith("rmi:")) {
			urlString = urlString.substring(4);
			urlString = "http:" + urlString;
		} else {
			if (urlString.indexOf(":/") != -1)
				throw new MalformedURLException("No need to specify protocol: " + urlString);
			else if(urlString.startsWith("//"))
				urlString = "http:" + urlString;
			else if(urlString.startsWith("/"))
				urlString = "http://localhost" + urlString;
			else
				urlString = "http://localhost/" + urlString;
		}
		url = new URL(urlString);
		host = url.getHost();
		port = url.getPort();
		objName = url.getFile();
		if(objName.startsWith("/"))
			objName = objName.substring(1,objName.length());
		if((host==null) || (host.length() == 0))
			host = "localhost";
		if(port<0)
			port = Registry.REGISTRY_PORT;
	}
}

}
