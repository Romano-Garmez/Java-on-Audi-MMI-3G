package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.rmi.server.RMIClassLoader;

import com.ibm.oti.rmi.RMIObjectInputStream;
import com.ibm.oti.rmi.RMIObjectOutputStream;

/**
 * An object of this class has a serialized version
 * of the object passed as parameter in the constructor.
 *
 * @author		OTI
 * @version		initial
 *
 * @see			SerializedForm
 */
public final class MarshalledObject implements Serializable {

/*
 * To make it compatible with JDK.
 */
private static final long serialVersionUID = 8988374069173025854L;

/*
 * The hash of the object passed as parameter in the constructor.
 */
int hash;

/*
 * Has the annotations done while serializing the object.
 */
byte[] locBytes;

/*
 * Has the serialized bytes of the object or null if the object was null.
 */
byte[] objBytes;

/**
 * Constructs a new instance of this class and keeps
 * a serialized copy of the parameter <code>o</code>.
 *
 * @param		o		Object
 * 							the object to be serialized
 *
 * @exception	IOException
 *					If an IO exception happened when writing the object.
 *
 * @author		OTI
 * @version		initial
 */
public MarshalledObject(Object o) throws IOException {
	if(o != null) {
		ByteArrayOutputStream ba = new ByteArrayOutputStream();
		RMIMarshalledObjectOutputStream oos = new RMIMarshalledObjectOutputStream(ba);
		oos.writeObject(o);
		oos.close();
		objBytes = ba.toByteArray();
		locBytes = oos.getAnnotations().toByteArray();
		hash = o.hashCode();
	}
}

//inner class #1
class RMIMarshalledObjectInputStream extends RMIObjectInputStream {

	transient ObjectInputStream oisAnnotations;

	protected RMIMarshalledObjectInputStream(InputStream in, ByteArrayInputStream ba) throws StreamCorruptedException, IOException {
		super(in);
		oisAnnotations = new ObjectInputStream(ba);
	}

	/**
	 * Reads the annotations made while objects were written into this stream and,
	 * and resolves the classes using these annotations.
	 *
	 * @author		OTI
	 * @version		initial
	 *
	 */
	protected Class resolveClass(ObjectStreamClass osClass) throws IOException, ClassNotFoundException {
		String annotation = (String) oisAnnotations.readObject();
		return RMIClassLoader.loadClass(annotation,osClass.getName());
	}

}

//inner class #2
class RMIMarshalledObjectOutputStream extends RMIObjectOutputStream {

	transient ObjectOutputStream oosAnnotations;
	transient ByteArrayOutputStream baAnnotations;

	protected RMIMarshalledObjectOutputStream(OutputStream out) throws StreamCorruptedException, IOException {
		super(out);
		baAnnotations = new ByteArrayOutputStream();
		oosAnnotations = new ObjectOutputStream(baAnnotations);
	}

	protected void annotateClass(Class aClass) throws IOException {
		String annotation = RMIClassLoader.getClassAnnotation(aClass);
		oosAnnotations.writeObject(annotation);
	}

	/**
	 * Answers the annotations made while writing objects in the receiver.
	 *
	 * @author		OTI
	 * @version		initial
	 *
	 */
	protected ByteArrayOutputStream getAnnotations() throws IOException {
		oosAnnotations.flush();
		return baAnnotations;
	}
}

/**
 * Deserialize the object represented by the receiver and answer it.
 *
 * @exception	IOException
 *					If an IO exception happened when reading the object.
 *
 * @exception	ClassNotFoundException
 *					If the object's class is not found.
 *
 * @author		OTI
 * @version		initial
 */
public Object get() throws java.io.IOException, java.lang.ClassNotFoundException {
	if(objBytes == null)
		return null;
	ByteArrayInputStream ba = new ByteArrayInputStream(objBytes);
	ByteArrayInputStream ba2 = new ByteArrayInputStream(locBytes);
	RMIMarshalledObjectInputStream ois = new RMIMarshalledObjectInputStream(ba, ba2);
	return ois.readObject();
}

/**
 * Answers an integer hash code for the receiver. Any two
 * objects which answer <code>true</code> when passed to
 * <code>.equals</code> must answer the same value for this
 * method.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		int
 *					the receiver's marshalled object's hash.
 *
 * @see			equals
 */
public int hashCode() {
	return hash;
}

/**
 * Compares the argument to the receiver, and answers true
 * if they represent the <em>same</em> object using a class
 * specific comparison. This implementation answers true
 * if the argument's marshalled objects is equal to the
 * one stored in the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		o Object
 *					the object to compare with this object.
 * @return		boolean
 *					<code>true</code>
 *						if the object is equals to this object
 *					<code>false</code>
 *						if it is different from this object.
 * @see			hashCode
 */
public boolean equals (Object o) {
	if(super.equals(o))
		return true;

	if(!(o instanceof MarshalledObject))
		return false;
	MarshalledObject mo = (MarshalledObject)o;
	if(this.hash != mo.hash)
		return false;
	if((objBytes == null) && (mo.objBytes != null))
		return false;
	if((objBytes != null) && (mo.objBytes == null))
		return false;

	return true;
}
}
