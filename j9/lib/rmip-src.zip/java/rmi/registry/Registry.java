package java.rmi.registry;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;

/**
 * This interface defines the RMI registry API.
 *
 * The registry maps a String to an object. It is the bootstrap for
 * the remote method invocation. To send a message to a remote object
 * a reference to this object must be obtained by accessing the registry.
 *
 * @author		OTI
 * @version		initial
 */
public interface Registry extends java.rmi.Remote {

public static final int REGISTRY_PORT = 1099;

/**
 * Answers a reference to a remote object specified by its name and
 * location.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in a url format
 *					without the protocol (ex "//hostName:portNumber/obName).
 * @return		Remote
 *					the reference to the remote object.
 * @exception	NotBoundException
 *					if an object with this name/location was not found.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 *
 */
public Remote lookup (String name) throws java.rmi.RemoteException, java.rmi.NotBoundException, java.rmi.AccessException;

/**
 *
 * Binds the object name specified in url to the remote object obj
 * in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in a url format
 *					without the protocol (ex "//hostName:portNumber/obName).
 * @exception	AlreadyBoundException
 *					if an object with this name was already bound in the registry.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if the url does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public void bind(String name, Remote o) throws java.rmi.RemoteException, java.rmi.AlreadyBoundException, java.rmi.AccessException;

/**
 *
 * Unbinds the object name specified in url from the remote object obj
 * in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in a url format
 *					without the protocol (ex "//hostName:portNumber/obName).
 * @exception	NotBoundException
 *					if an object with this name was not found in the registry.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if the url does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public void unbind (String name) throws java.rmi.RemoteException, java.rmi.NotBoundException, java.rmi.AccessException;

/**
 *
 * Binds the object name specified in url to the remote object obj
 * in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in a url format
 *					without the protocol (ex "//hostName:portNumber/obName).
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if the url does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public void rebind(String name,Remote o) throws java.rmi.RemoteException, java.rmi.AccessException;

/**
 * Answers an array of Strings with all the names of the objects
 * bound in the registry specified by host and port in url.
 * The file part of the url is ignored.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the registry location in a url format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @return		String[]
 *					a list with all the object bound in the registry.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 *
 */
public String[] list() throws java.rmi.RemoteException, java.rmi.AccessException;
}
