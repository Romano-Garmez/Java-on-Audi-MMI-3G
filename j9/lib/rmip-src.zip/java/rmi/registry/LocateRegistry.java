package java.rmi.registry;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;
import java.rmi.server.*;
import java.lang.reflect.*;
import com.ibm.oti.rmi.*;

/**
 * This class has a set of static methods that can be
 * used to get a reference to a registry.
 *
 * @author		OTI
 * @version		initial
 */
public final class LocateRegistry {

private LocateRegistry() {}

/**
 * Answers a reference to a registry.
 *
 * @return		Registry
 *					the reference to a registry.
 *
 * @author		OTI
 * @version		initial
 */
public static Registry getRegistry() throws java.rmi.RemoteException {
	return getRegistry(Registry.REGISTRY_PORT);
}

/**
 * Answers a reference to a registry.
 *
 * @param		port int
 *					the port where the registry is expected to be exported in.
 *
 * @return		Registry
 *					the reference to a registry.
 *
 * @author		OTI
 * @version		initial
 */
public static Registry getRegistry (int port) throws java.rmi.RemoteException {
	return getRegistry(null,port);
}

/**
 * Answers a reference to a registry.
 *
 * @param		host String
 *					the host where the registry is expected to be exported in.
 *
 * @return		Registry
 *					the reference to a registry.
 *
 * @author		OTI
 * @version		initial
 */
public static Registry getRegistry (String host) throws java.rmi.RemoteException {
	return getRegistry(host,Registry.REGISTRY_PORT);
}

/**
 * Answers a reference to a registry.
 *
 * @param		port int
 *					the port where the registry is expected to be exported in.
 * @param		host String
 *					the host where the registry is expected to be exported in.
 *
 * @return		Registry
 *					the reference to a registry.
 *
 * @author		OTI
 * @version		initial
 */
public static Registry getRegistry (String host,int port) throws java.rmi.RemoteException {
	return getRegistry(host,port,null);
}

/**
 * Answers a reference to a registry.
 *
 * @param		port int
 *					the port where the registry is expected to be exported in.
 * @param		host String
 *					the host where the registry is expected to be exported in.
 * @param		csf RMIClientSocketFactory
 *					the factory that should be used to create the socket needed
 *					to connect to the registry.
 *
 * @return		Registry
 *					the reference to a registry.
 *
 * @author		OTI
 * @version		initial
 */
public static Registry getRegistry (String host,int port,RMIClientSocketFactory csf) throws java.rmi.RemoteException {
	if (host == null)
		host = "localhost";

	ObjID id = new ObjID(ObjID.REGISTRY_ID);
	RemoteRef r;
	if(csf == null)
		r = new UnicastRef(new EndpointID(host,port),id);
	else
		r = new UnicastRef2(new EndpointID(host,port),id,csf);

	try {
		Class c = Class.forName("com.ibm.oti.rmi.registry.RegistryImpl_Stub");
		Constructor constructor = c.getConstructor(new Class[]{RemoteRef.class});
		RemoteStub stub = (RemoteStub)constructor.newInstance(new Object[]{r});
		return (Registry)stub;
		} catch (ClassNotFoundException ex) {
			throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0004","RegistryImpl_Stub"), ex);
		} catch (NoSuchMethodException ex) {
			throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0004","RegistryImpl_Stub(RemoteRef r)"), ex);
		} catch (IllegalAccessException ex) {
			throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0005","RegistryImpl_Stub(RemoteRef r)"), ex);
		} catch (InstantiationException ex) {
			throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0006","RegistryImpl_Stub"), ex);
		} catch (InvocationTargetException ex) {
			throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0006","RegistryImpl_Stub") + ": " + ex.getTargetException());
	}
}

/**
 * Creates a registry and exports it.
 *
 * @param		port int
 *					the port where the server should run.
 * @param		csf RMIClientSocketFactory
 *					the factory that should be used to create the sockets needed
 *					to connect to the registry.
 * @param		ssf RMIServerSocketFactory
 *					the factory that should be used to create the sever sockets
 *					needed for the registry.
 *
 * @return		Registry
 *					the exported registry.
 *
 * @author		OTI
 * @version		initial
 */
public static Registry createRegistry (int port,RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws java.rmi.RemoteException {
	return new com.ibm.oti.rmi.registry.RegistryImpl(port,csf,ssf);
}

/**
 * Creates a registry and exports it.
 *
 * @param		port int
 *					the port where the server should run.
 *
 * @return		Registry
 *					the exported registry.
 *
 * @author		OTI
 * @version		initial
 */
public static Registry createRegistry (int port) throws java.rmi.RemoteException {
	return new com.ibm.oti.rmi.registry.RegistryImpl(port);
}
}
