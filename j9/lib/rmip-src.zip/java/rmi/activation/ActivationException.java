package java.rmi.activation;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2002, 2003  All Rights Reserved
 */

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * This exception is thrown by the Activation interfaces.
 *
 * @author		OTI
 * @version		initial
 */
public class ActivationException extends Exception {

	public java.lang.Throwable detail;

	/*
	 * To make it compatible with JDK.
	 */
	private static final long serialVersionUID = -4320118837291406071L;

	/**
	 * Constructs a new instance of this class with its
	 * walkback filled in.
	 *
	 * @author		OTI
	 * @version		initial
	 */
	public ActivationException() {
		super();
	}

	/**
	 * Constructs a new instance of this class with its
	 * walkback and message filled in.
	 *
	 * @param		s String
	 *					a message describing why the exception was thrown.
	 *
	 * @author		OTI
	 * @version		initial
	 */
	public ActivationException(java.lang.String s) {
		super(s);
	}

	/**
	 * Constructs a new instance of this class with its
	 * walkback, message and exception filled in.
	 *
	 * @param		detailMessage String
	 *					a message describing why the exception was thrown.
	 * @param		exception Throwable
	 *					the nested exception that has occurred.
	 *
	 * @author		OTI
	 * @version		initial
	 */
	public ActivationException(java.lang.String s, java.lang.Throwable ex) {
		super(s);
		detail=ex;
	}

	/**
 * Answers the extra information message that was provided
 * when the receiver was created. If no message was provided
 * at creation time, then answer null.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		the receiver's message.
 */
public String getMessage () {
	if((detail == null) || (detail.getMessage() == null))
		return super.getMessage();
	if(super.getMessage() == null)
		return detail.getMessage();
	return super.getMessage() + "::" + detail;
}

/**
 * Outputs a printable representation of the receiver's
 * walkback and its nested exception on the stream specified
 * by the argument.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		err		the writer to write the walkback on.
 */
public void printStackTrace (PrintStream ps) {
	super.printStackTrace(ps);
	if(detail!=null) {
		ps.println(com.ibm.oti.rmi.util.Msg.getString("R0042"));
		detail.printStackTrace(ps);
	}

}

/**
 * Outputs a printable representation of the receiver's
 * walkback and its nested exception on the writer specified
 * by the argument.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		err		the writer to write the walkback on.
 */
public void printStackTrace(PrintWriter pw) {
	super.printStackTrace(pw);
	if(detail!=null) {
		pw.write(com.ibm.oti.rmi.util.Msg.getString("R0042"));
		detail.printStackTrace(pw);
	}
}

}

