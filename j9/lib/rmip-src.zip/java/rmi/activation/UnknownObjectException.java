package java.rmi.activation;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2002, 2003  All Rights Reserved
 */

/**
 * This exception is thrown if an invalid <code>ActivationID</code> parameter is
 * is passed to a method of one of the activation interfaces or classes.
 * An <code>ActivationID</code> is invalid if it is
 * not currently known by the <code>ActivationSystem.</code>
 *
 * @author		OTI
 * @version		initial
 */
public class UnknownObjectException  extends ActivationException{

	/**
	 * Constructs a new instance of this class with its
	 * walkback and message filled in.
	 *
	 * @param		s String
	 *					a message describing why the exception was thrown.
	 *
	 * @author		OTI
	 * @version		initial
	 */
	public UnknownObjectException(java.lang.String s) {
		super(s);
	}

}

