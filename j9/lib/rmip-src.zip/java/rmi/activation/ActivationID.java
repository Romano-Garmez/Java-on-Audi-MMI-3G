package java.rmi.activation;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2002, 2003  All Rights Reserved
 */

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;

import com.ibm.oti.rmi.activation.RemoteStubFinder;

public class ActivationID implements java.io.Serializable {

	private transient Activator activator;
	private transient UID uid;
	private transient int hash;
	/*
	 * To make it compatible with JDK.
	 */
	private static final long serialVersionUID = -4608673054848209235L;
	private static final String packagePrefix = "com.ibm.oti.rmi";

	/**
	 * Constructs a new instance of this class which is globally unique.
	 * @param		activator Activator
	 * 								a remote reference to the activator that will activate this object.
	 *
	 * @author		OTI
	 * @version		initial
	 *
	 */
	public ActivationID(Activator activator) {
		if (activator!=null) {
			this.activator = activator;
			uid= new UID();
			hash = activator.hashCode() + uid.hashCode();
		}

	}

	public Remote activate(boolean force) throws ActivationException, UnknownObjectException, RemoteException {
		MarshalledObject marshalled = activator.activate(this, force);
		try {
		Remote remote = (Remote)marshalled.get();
		return remote;
		} catch (IOException ioe) {
			throw new ActivationException(com.ibm.oti.rmi.util.Msg.getString("R0043"),ioe);
		} catch (ClassNotFoundException cnfe) {
			throw new ActivationException(com.ibm.oti.rmi.util.Msg.getString("R0043"),cnfe);
		}

	}

	public int hashCode(){
		return hash;
	}

	public boolean equals(java.lang.Object obj) {
		if (!(obj instanceof ActivationID))
			return false;

		return (((ActivationID)obj).getUid().equals(uid) &&
				((ActivationID)obj).getActivator().equals(activator));
	}

	private UID getUid() {
		return uid;
	}
	private Activator getActivator() {
		return activator;
	}
	private void readObject(java.io.ObjectInputStream in) throws
							 java.io.IOException, java.lang.ClassNotFoundException {
		RemoteRef ref=null;
	    uid= (UID)in.readObject();

        String refClassName = in.readUTF();
 		if(refClassName.length() == 0) {
			ref = (RemoteRef) in.readObject();
		} else {
			try {
				refClassName = packagePrefix + "." + refClassName;
				//No need to used RMIClassLoader because 'refClassName' must be a system class.
				ref = (RemoteRef)Class.forName(refClassName).newInstance();
				ref.readExternal(in);
			} catch (IllegalAccessException ex) {
				throw new UnmarshalException(refClassName,ex);
			} catch (InstantiationException ex) {
				throw new UnmarshalException(refClassName,ex);
			}
		}
		Remote a = RemoteStubFinder.getStub(ref);
		activator = (Activator)a;
	}

   private void writeObject(java.io.ObjectOutputStream out)
                  throws java.io.IOException,
                         java.lang.ClassNotFoundException {

	out.writeObject(uid);
	RemoteRef ref =  ((RemoteObject)activator).getRef();
	out.writeUTF(ref.getRefClass(null));
	ref.writeExternal(out);
	}
}
