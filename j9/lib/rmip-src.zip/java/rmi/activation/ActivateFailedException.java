package java.rmi.activation;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2002, 2003  All Rights Reserved
 */

import java.rmi.*;

/**
 * This exception is thrown if activation fails
 * during a remote call to an activatable object.
 *
 * @author		OTI
 * @version		initial
 */
public class ActivateFailedException extends RemoteException {

	private static final long serialVersionUID = 4863550261346652506L;

	/**
	 * Constructs a new instance of this class with its
	 * walkback and message filled in.
	 *
	 * @param		s String
	 *					a message describing why the exception was thrown.
	 *
	 * @author		OTI
	 * @version		initial
	 */
	public ActivateFailedException(java.lang.String s) {
		super(s);
	}

	/**
	 * Constructs a new instance of this class with its
	 * walkback, message and exception filled in.
	 *
	 * @param		detailMessage String
	 *					a message describing why the exception was thrown.
	 * @param		exception Throwable
	 *					the nested exception that has occurred.
	 *
	 * @author		OTI
	 * @version		initial
	 */
	public ActivateFailedException(java.lang.String s, java.lang.Exception ex) {
		super(s,ex);
	}

}

