package java.rmi.activation;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2002, 2003  All Rights Reserved
 */

import java.rmi.MarshalledObject;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Activator extends Remote {
	public MarshalledObject activate(ActivationID id, boolean force) throws
				ActivationException, UnknownObjectException, RemoteException;

}

