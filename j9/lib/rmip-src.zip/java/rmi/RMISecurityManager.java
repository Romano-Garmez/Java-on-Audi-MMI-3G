package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * RMISecurityManager is a class that provides
 * some security verification for a running
 * program.
 *
 * RMIClassLoader does not load any class but the
 * ones in the file system if there is no security
 * manager installed.
 *
 * @author		OTI
 * @version		initial
 */
public class RMISecurityManager extends java.lang.SecurityManager {

/**
 * Constructs a new instance of RMISecurityManager.
 *
 * @author		OTI
 * @version		initial
 */
public RMISecurityManager(){
	super();
}

}
