package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when a lookup or unbind call does not
 * find the object in the registry.
 *
 * @author		OTI
 * @version		initial
 */
public class NotBoundException extends java.lang.Exception {

private static final long serialVersionUID =-1857741824849069317L;

/**
 * Constructs a new instance of this class with its
 * walkback filled in.
 *
 * @author		OTI
 * @version		initial
 */
public NotBoundException(){
	super();
}

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public NotBoundException(String s){
	super(s);
}
}
