package java.rmi;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when an exception that
 * is not declared in the remote method signature
 * occurs while executing it.
 *
 * @author		OTI
 * @version		initial
 */
public class UnexpectedException extends RemoteException {

/**
 * Constructs a new instance of this class with its
 * walkback and message filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 *
 * @author		OTI
 * @version		initial
 */
public UnexpectedException(String s){
	super(s);
}

/**
 * Constructs a new instance of this class with its
 * walkback, message and nested exception filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 * @param		ex Exception
 *					the exception being wrapped by this new instance.
 *
 * @author		OTI
 * @version		initial
 */
public UnexpectedException(String s, Exception ex){
	super(s, ex);
}

}
