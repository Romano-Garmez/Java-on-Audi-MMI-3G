package java.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This exception is thrown when an error occurs in
 * the server while it is executing a remote call.
 *
 * @author		OTI
 * @version		initial
 */
public class ServerError extends RemoteException {

/**
 * Constructs a new instance of this class with its
 * walkback, message and nested Error filled in.
 *
 * @param		s String
 *					a message describing why the exception was thrown.
 * @param		err Error
 *					the error being wrapped by this new instance.
 *
 * @author		OTI
 * @version		initial
 */
public ServerError(String s, Error err){
	super(s, err);
}
}
