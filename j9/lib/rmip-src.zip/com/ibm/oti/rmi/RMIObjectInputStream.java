package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;

/**
 * This class is used by the wire protocol, stubs and
 * skeletons to receive objects . It redefines resolveClass
 * to read the annotation and load the class according to
 * this annotation.
 *
 * @author		OTI
 * @version		initial
 */
public class RMIObjectInputStream extends java.io.ObjectInputStream {

	ClassLoader cloader = null;

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
public RMIObjectInputStream(InputStream in) throws StreamCorruptedException, IOException {
	super(in);
}

/**
 * Loads the Java class corresponding to the class descriptor <code>osClass</code>(ObjectStreamClass)
 * just read from the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		osClass		An ObjectStreamClass read from the receiver.
 *
 * @return		Class		A Class corresponding to the descriptor loaded.
 *
 * @exception		java.io.IOException			If any IO problem occurred when trying to load the class.
 * @exception		java.lang.ClassNotFoundException	If the corresponding class cannot be found.
 */
protected Class resolveClass(ObjectStreamClass osClass) throws IOException, ClassNotFoundException {
	String annotation = (String)readObject();
	String clName = osClass.getName();
	try {
		return Class.forName(osClass.getName(), true, cloader);
	} catch(Exception e) {
		try {
			ClassLoader systemClassLoader = ClassLoader.getSystemClassLoader();
			return Class.forName(osClass.getName(), true, systemClassLoader);
		} catch (Exception ee) {
			return java.rmi.server.RMIClassLoader.loadClass(annotation,clName);
		}
	}
}

public void setCloader(ClassLoader cl){
	cloader = cl;
}

}
