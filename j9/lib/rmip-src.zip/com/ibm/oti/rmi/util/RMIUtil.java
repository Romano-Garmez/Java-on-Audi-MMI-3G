package com.ibm.oti.rmi.util;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.util.*;
import java.lang.reflect.*;
import com.ibm.oti.util.*;
import java.io.*;
import java.rmi.*;

/**
 * This class has a set of methods used by rmi and rmic.
 *
 * @author		OTI
 * @version		initial
 */
public class RMIUtil {
	static final Class objClass = Object.class;
	static final Class remoteClass = Remote.class;

/**
 * Answers an array with all Remote interfaces implemented
 * by <code>c</code>.
 *
 * @author		OTI
 * @version		initial
 */
public static Class[] getAllRemoteInterfaces(Class c) {
	Vector remoteInterfaces = new Vector();
	getAllRemoteInterfaces(c, new Hashtable(16), remoteInterfaces);
	Class r[] = new Class[remoteInterfaces.size()];
	for(int i=0;i<r.length;i++)
		r[i] = (Class)remoteInterfaces.elementAt(i);
	return r;
}

/**
 * Adds all Remote interfaces implemented by <code>c</code> in the
 * specified Hashtable.
 *
 * @author		OTI
 * @version		initial
 */
private static boolean getAllRemoteInterfaces(Class c, Hashtable foundInterfaces, Vector result) {
	if (c == remoteClass) return true;
	boolean remote = false;
	Class supercl = c.getSuperclass();
	if (supercl != null && supercl != objClass)
		remote = getAllRemoteInterfaces(supercl, foundInterfaces, result);
	Class cInterfaces[] = c.getInterfaces();
	for(int i=0;i<cInterfaces.length;i++) {
		Class cInt = cInterfaces[i];
		if (cInt.isAssignableFrom(remoteClass) || foundInterfaces.containsKey(cInt)) {
			remote = true;
			continue;
		}
		if (getAllRemoteInterfaces(cInt, foundInterfaces, result)) {
			remote = true;
			foundInterfaces.put(cInt, cInt);
			result.addElement(cInt);
		}
	}
	return remote;
}

/**
 * Answers a variation of c's signature.
 *
 * @author		OTI
 * @version		initial
 */
public static String descriptorFor(Class c) {
	if(c.isArray())
		return c.getName().replace('.','/');
	if(c.isPrimitive()) {
		if(c == void.class) return "V";
		if(c == boolean.class) return "Z";
		if(c == byte.class) return "B";
		if(c == char.class) return "C";
		if(c == short.class) return "S";
		if(c == int.class) return "I";
		if(c == long.class) return "J";
		if(c == float.class) return "F";
		if(c == double.class) return "D";
		return null;
	}
	return "L" + c.getName().replace('.','/') + ";";
}
/*
 * Answers a variation of m's signature.
 *
 *	Ex: Answer (ILjava/lang/String;D)Ljava/lang/String;
 *			for String foo(int i,String s);
 *
 * @author		OTI
 * @version		initial
 */
private static String descriptorFor (Method m) {
	String r = "(";
	Class[] pTypes = m.getParameterTypes();
	for(int i=0;i<pTypes.length;i++) {
		r = r + descriptorFor(pTypes[i]);
	}
	r = r + ")" + descriptorFor(m.getReturnType());
	return r;
}

/**
 * Answers a little endian long stored in a given position of the buffer.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		buffer		a byte array with the byte representation of the number.
 * @param		position	index where the number starts in the byte array.
 *
 * @return		a long, the number that was stored in little endian format.
 */
public static long littleEndianLongAt (byte[] buffer, int position) {
	long result = 0;
	int startPos = position + 7;
	for (int i = startPos; i >= position; i--) {
		result = (result << 8) + (buffer[i] & 0xff);
	}
	return result;
}

/**
 * Answers the hash for <code>m</code>.
 *
 * @author		OTI
 * @version		initial
 */
public static long hashFor (Method m) throws IOException {
	SHAOutputStream sha = new SHAOutputStream();
	DataOutputStream output = new DataOutputStream(sha);
	output.writeUTF(m.getName() + descriptorFor(m));
	byte[] hash = sha.getHashAsBytes();
	return littleEndianLongAt(hash,0);
}

}
