package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

/**
 * This class implements an endpoint, i.e.
 * a simple host/port pair.
 *
 * @author		OTI
 * @version		initial
 */
public class EndpointID {

	String host;
	int port;

/**
 * Constructs a new instance of this class initializing
 * it's host and port.
 *
 * @author		OTI
 * @version		initial
 */
public EndpointID(String host,int port) {
	this.host = host;
	this.port = port;
}

/**
 * Answer the receiver's host.
 */
public String getHost() {
	return host;
}

/**
 * Answer the receiver's port.
 */
public int getPort() {
	return port;
}

/**
 * Answers an integer hash code for the receiver. Any two
 * objects which answer <code>true</code> when passed to
 * <code>.equals</code> must answer the same value for this
 * method.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		int
 *					the receiver's hash.
 *
 * @see			equals
 */
public int hashCode() {
	return host.hashCode() * port;
}

/**
 * Compares the argument to the receiver, and answers true
 * if they represent the <em>same</em> object using a class
 * specific comparison. The implementation in Object answers
 * true only if the argument is the exact same object as the
 * receiver (==).
 *
 * @author		OTI
 * @version		initial
 *
 * @param		o Object
 *					the object to compare with this object.
 * @return		boolean
 *					<code>true</code>
 *						if the object is the same as this object.
 *					<code>false</code>
 *						if it is different from this object.
 * @see			hashCode
 */
public boolean equals (Object o) {
	if(o instanceof EndpointID) {
		EndpointID ep = (EndpointID)o;
		return ((this.host.equals(ep.host)) && (this.port == ep.port));
	}
	return false;
}

}
