package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.util.*;
import java.rmi.*;
import java.rmi.server.*;
import java.lang.reflect.*;
import java.security.*;
import java.io.*;
import com.ibm.oti.util.*;
import com.ibm.oti.rmi.util.*;
import java.lang.ref.*;

/**
 * This class implements a circular buffer used by the
 * DGCImpl - the server side. It is basically a set of instances
 * of this class managed by some static methods to add, move
 * and remove remote references. The remote references are
 * added to this buffer according to their lease time.
 *
 * The default lease time is 10 minutes. This RMI implementation
 * has one table for each minute. The DGCImpl will be resumed at
 * least every minute to collect object with expired leases.
 *
 * @author		OTI
 * @version		initial
 */
public class RMIServerTable {

public final static int tablesSize = 10;
private final static int timeInterval = 60000; // 1 minute.
private final static RMIServerTable tables[];
private final static ReferenceQueue refQueue;
private static int currentTableIndex;
/*
 * Maps RemoteObject(s) to RemoteStub(s)
 * It is used only in the server side.
 */
private static final Hashtable roToStub;
/*
 * Maps Class(s) to its remote interfaces
 * It is used only in the server side.
 */
private static final Hashtable classToInterfaces;
/*
 * Maps remote interfaces to its remote methods.
 * It is used only in the server side.
 */
private static final Hashtable interfacesToMths;

static {
 	tables = new RMIServerTable[tablesSize];
 	long time = System.currentTimeMillis();
 	int index = 0;
 	for(int i=0;i<tablesSize;i++) {
 		index = (int)((time / timeInterval) % tablesSize);
 		tables[index] = new RMIServerTable(time,index);
 		time = time + timeInterval;
 	}
 	currentTableIndex = (index + 1) % tablesSize;
 	roToStub = new Hashtable();
 	classToInterfaces = new Hashtable();
 	interfacesToMths = new Hashtable();
 	refQueue = new ReferenceQueue();
 	RMIWeakReferenceCollector refGC =
 		new RMIWeakReferenceCollector("RMI-Ref GC");
 	refGC.setDaemon(true);
 	refGC.start();
}

public static RMIServerTable nextTable() {
	synchronized(tables) {
		RMIServerTable objs = tables[currentTableIndex];
		if(System.currentTimeMillis() > objs.deathTime) {
			currentTableIndex++;
			currentTableIndex = currentTableIndex % tablesSize;
			return objs;
		}
		return null;
	}
}

/**
 * Adds a new server to the tables <code>idToRO</code> and <code>roToStub</code>.
 *
 * @author		OTI
 * @version		initial
 */
public static void putServer(Remote ro,RemoteStub stub, ObjID id) throws IOException {
	RMIServerTable t = tableFor(id);
	Hashtable idToRO = t.idToRO;
	RemoteWrapper rw = new RemoteWrapper(ro);
	idToRO.put(id,rw);
	roToStub.put(rw,stub);
	addMethods(ro.getClass());
}

/**
 * Removes a server from the tables <code>idToRO</code> and <code>roToStub</code>.
 *
 * @author		OTI
 * @version		initial
 */
public static boolean removeServer(Remote ro, boolean force) {
	synchronized(roToStub) {
		//A temporary remote wrapper is created inorder to look for the
		//remote object in the roToStub hashtable.
		//This hashtable has remote wrappers as keys.
		RemoteWrapper temp_rw = new RemoteWrapper(ro);
		RemoteStub stub = (RemoteStub)roToStub.get(temp_rw);
		if(stub != null) {
			ObjID id = ((UnicastRef)(stub.getRef())).getID();
			RMIServerTable t = tableFor(id);
			Hashtable idToRO = t.idToRO;
			boolean canremove = true;
			Hashtable idToCount = t.idToMethodCallCount;
			Long callcount = (Long)idToCount.get(id);
			if (callcount!= null)
				if (callcount.longValue()>0)
					canremove=false;

			if (canremove || force){
				RemoteWrapper rw = (RemoteWrapper)idToRO.get(id);
				rw.makeWeak();
				return true;
			} else {
				return false;
			}
		}
		return true;
	}
}

public static void increaseCallCount(ObjID id) {
	RMIServerTable t = tableFor(id);
	Hashtable idToCount = t.idToMethodCallCount;
	Long callcount = (Long)idToCount.get(id);
	if (callcount==null)
		idToCount.put(id,new Long(1));
	else
		idToCount.put(id,new Long(callcount.longValue() + 1));

}

public static void decreaseCallCount(ObjID id) {
	RMIServerTable t = tableFor(id);
	Hashtable idToCount = t.idToMethodCallCount;
	Long callcount = (Long)idToCount.get(id);
	if (callcount!=null)
		idToCount.put(id,new Long(callcount.longValue() - 1));

}

/**
 * Gets a Remote object from <code>idToRO</code>.
 *
 * @author		OTI
 * @version		initial
 */
public static Remote getObj(ObjID id) {
	RMIServerTable t = tableFor(id);
	return t.getRemoteObj(id,false);
}

/**
 * Gets a Remote object from <code>idToRO</code>.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIServerTable tableFor(ObjID id) {
	int i = id.hashCode();
	i = (i / 10) % 10;
	return tables[i];
}

/**
 * Answers an index for a new ObjID.
 *
 * @author		OTI
 * @version		initial
 */
public static int idIndex() {
	return (int)((System.currentTimeMillis() / timeInterval) % tablesSize);
}

/**
 * Gets a RemoteStub from <code>idToRO</code>.
 *
 * @author		OTI
 * @version		initial
 */
public static RemoteStub getStub(Remote ro) {

	if (ro==null) {
		return null;
	}
	RemoteWrapper temp_rw = new RemoteWrapper(ro);
	return (RemoteStub) roToStub.get(temp_rw);
}

/**
 * Makes the object's reference strong, i.e. the object
 * will not be collected even if the last client
 * loses it's reference because the server has references
 * to this object.
 *
 * @author		OTI
 * @version		initial
 */
public static void makeStrong(ObjID id) {
	RMIServerTable t = tableFor(id);
	RemoteWrapper rw = (RemoteWrapper)t.idToRO.get(id);
	if(rw != null)
		rw.makeStrong();
}

/*
 * Adds all remote methods to the RMI method table.
 */
private static void addMethods(Class roClass) throws IOException {
	synchronized(classToInterfaces) {
		if(classToInterfaces.get(roClass) != null)
			return;
		Class[] remoteInterfaces = RMIUtil.getAllRemoteInterfaces(roClass);
		classToInterfaces.put(roClass,remoteInterfaces);

		for(int i = 0, length = remoteInterfaces.length; i < length; i++)
			if(interfacesToMths.get(remoteInterfaces[i]) == null)
				interfacesToMths.put(
					remoteInterfaces[i],
					hashToMthFor(remoteInterfaces[i]));
	}
}

/**
 * Answers a Hashtable mapping hashes to methods.
 *
 * @author		OTI
 * @version		initial
 */
private static Hashtable hashToMthFor(final Class c) throws IOException {
	Hashtable result = new Hashtable();
	Method mths[] = c.getDeclaredMethods();
	for(int i = 0, length = mths.length; i < length; i++)
		result.put(new Long(RMIUtil.hashFor(mths[i])),mths[i]);
	return result;
}

/**
 * Gets a remote method from the RMI method table.
 *
 * @author		OTI
 * @version		initial
 */
public static Method getMethod (Remote ro,long hash) {
	synchronized(classToInterfaces) {
		Class interf[] = (Class[])classToInterfaces.get(ro.getClass());
		if(interf != null) {
			Long h = new Long(hash);
			for(int i = 0, length = interf.length; i < length; i++) {
				Hashtable hashToMth = (Hashtable)interfacesToMths.get(interf[i]);
				Method m = (Method)hashToMth.get(h);
				if(m!=null) return m;
			}
		}
		return null;
	}
}

/*
 * Maps ObjID(s) to RemoteObject(s)
 * It is used only in the server side.
 */
private final Hashtable idToRO;
private long deathTime;
private long nextDeathTime;
public int index;

private final Hashtable idToMethodCallCount;

private RMIServerTable(long deathTime, int index) {
	this.deathTime = deathTime;
	nextDeathTime = deathTime + (timeInterval * tablesSize);
	this.index = index;
	idToRO = new Hashtable();
	idToMethodCallCount = new Hashtable();
}

/**
 * Answers the time when the objects should be collected
 * if the lease were not renewed.
 *
 * @author		OTI
 * @version		initial
 */
public long deathTime() {
	return deathTime;
}

/**
 * Updates the time when the objects should be collected
 * if the lease were not renewed.
 *
 * @author		OTI
 * @version		initial
 */
public void updateDeathTime() {
	deathTime = nextDeathTime;
	nextDeathTime += (timeInterval * tablesSize);
}

/**
 * Answers the next time when the objects should be collected
 * if the lease were not renewed.
 *
 * @author		OTI
 * @version		initial
 */
public long nextDeathTime() {
	return nextDeathTime;
}

/**
 * Gets all exported servers ObjID(s)
 *
 * @author		OTI
 * @version		initial
 */
public Enumeration getExportedObjIDs() {
	return idToRO.keys();
}

/**
 * Gets a Remote object from <code>idToRO</code>
 *
 * @author		OTI
 * @version		initial
 */
public Remote getRemoteObj(ObjID id,boolean makeStrong) {
	synchronized(idToRO) {
		RemoteWrapper rw = (RemoteWrapper)idToRO.get(id);
		if(rw == null)
			return null;
		if(makeStrong)
			rw.makeStrong();
		return (Remote)rw.get();
	}
}

/**
 * Implements a thread that is resumed every time
 * an object is added to the refQueue. Once resumed
 * remove the weakreference from the refQueue and
 * from the RMIServerTable.
 *
 * @author		OTI
 * @version		initial
 */
static class RMIWeakReferenceCollector extends Thread {
	public RMIWeakReferenceCollector(String name) {
		super(name);
	}
	public void run() {
		while(true) {
			try {
				Object ro = refQueue.remove();
		 		synchronized(roToStub) {
					RemoteStub stub = (RemoteStub)roToStub.get(ro);
					if(stub != null) {
						ObjID id = ((UnicastRef)(stub.getRef())).getID();
						RMIServerTable t = tableFor(id);
						Hashtable idToRO = t.idToRO;
						idToRO.remove(id);
						roToStub.remove(ro);
					}
				}
			} catch (InterruptedException ex) {}
		}
	}
}

/**
 * Implements a wrapper to a remote object enabling
 * the object to be collected when the server and
 * clients are not referencing it.
 *
 * @author		OTI
 * @version		initial
 */
public static class RemoteWrapper extends WeakReference {

int hashCode;
Object remote;

public RemoteWrapper(Object o) {
	super(o,refQueue);
	remote = o;
	hashCode = o.hashCode();
}

public boolean equals(Object obj) {
	if (super.equals(obj))
			return true;

	if (obj == null)
		return false;

	if (!(obj instanceof RemoteWrapper))
		return false;

	Object r = get();
	if (r == null)
		return false;
	Object ro = ((RemoteWrapper)obj).get();
	return r.equals(ro);
}

public int hashCode() {
	return hashCode;
}

public String toString() {
	return "RemoteWrapper: [" + get() + "]";
}

public void makeStrong() {
	remote = get();
}

public void makeWeak() {
	remote = null;
	clear();
}
}
}
