package com.ibm.oti.rmi.activation;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2002, 2003  All Rights Reserved
 */

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.rmi.StubNotFoundException;
import java.rmi.server.*;

public class RemoteStubFinder extends RemoteStub {

	public static RemoteStub getStub(RemoteRef ref) throws StubNotFoundException {

	try {
		Class c = Class.forName("com.ibm.oti.rmi.activation.ActivatorImpl_Stub");
		Constructor constructor = c.getConstructor(new Class[]{RemoteRef.class});
		RemoteStub stub = (RemoteStub)constructor.newInstance(new Object[]{ref});
		return stub;
	} catch (ClassNotFoundException ex) {
		throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0004","RemoteStub"),ex);
	} catch (NoSuchMethodException ex) {
		throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0004","RemoteStub(RemoteRef r)"),ex);
	} catch (IllegalAccessException ex) {
		throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0005","RemoteStub(RemoteRef r)"),ex);
	} catch (InstantiationException ex) {
		throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0006","RemoteStub"),ex);
	} catch (InvocationTargetException ex) {
		throw new StubNotFoundException(com.ibm.oti.rmi.util.Msg.getString("R0006","RemoteStub"),ex);
	}

	}

}

