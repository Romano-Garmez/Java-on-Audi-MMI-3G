package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.lang.reflect.*;

public class UnicastServerRef2 extends UnicastServerRef {

private RMIClientSocketFactory csFactory;
private RMIServerSocketFactory ssFactory;

/**
 * Constructs a new instance of this class.
 *
 * This constructor is sent by RemoteObject>>#readObject
 *
 * @author		OTI
 * @version		initial
 */
public UnicastServerRef2() {
}

/**
 * Constructs a new instance of this class and initializes
 * it's endpoint - host and port - and it's id.
 *
 * @author		OTI
 * @version		initial
 */
public UnicastServerRef2(int port, ObjID id,RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws java.net.UnknownHostException {
	super(port, id);
	csFactory = csf;
	ssFactory = ssf;
}

}
