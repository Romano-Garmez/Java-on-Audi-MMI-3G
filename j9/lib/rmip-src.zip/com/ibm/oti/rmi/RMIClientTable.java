package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.util.*;
import java.rmi.*;
import java.rmi.server.*;
import java.lang.reflect.*;
import java.security.*;
import java.io.*;
import com.ibm.oti.util.*;
import com.ibm.oti.rmi.util.*;

/**
 * This class implements a circular buffer used by the
 * DGCClient. It is basically a set of instances of this
 * class managed by some static methods to add, move,
 * and remove remote references. The remote references are
 * added to this buffer according to their lease time.
 *
 * The default lease time is 10 minutes. This RMI implementation
 * has one table for each minute plus one for objects leased for
 * a short period of time. The DGCClient will be resumed at least
 * every minute to renew the leases. If objects are added to the
 * <code>newObjects</code> table the DGCClient will be resumed more
 * frequently.
 *
 * @author		OTI
 * @version		initial
 */
public class RMIClientTable {

/*
 * Tables for the remote objects leased for more then one timeInterval.
 */
private final static RMIClientTable tables[];
private final static int tablesSize;

/*
 * Table for the remote objects leased for less then one timeInterval.
 */
private final static RMIClientTable shortLeaseObjects;

/*
 * Table for unreferenced remote objects.
 */
private final static RMIClientTable unrefObjs;
private final static int timeInterval = 30000; // 1/2 minute.
private final static int maxDelta = 3; // 3 == 1.5 minutes.

private static int currentTableIndex;

static {
	tablesSize = 10;
	currentTableIndex = 0;
 	tables = new RMIClientTable[tablesSize];
 	long time = System.currentTimeMillis();
 	for(int i=0;i<tablesSize;i++) {
 		tables[i] = new RMIClientTable(time,i);
 		time = time + timeInterval;
 	}
	shortLeaseObjects = new RMIClientTable(0,-1);
	unrefObjs = new RMIClientTable(0,-2);
}

/**
 * DGC scans the references every once in a while
 * and renews all leases that are timing out.
 * Objects are added to this table acording to
 * their lease time. This method answers a
 * table with objects to have their leases renewed.
 * If not in time to renew leases answer null.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIClientTable nextTable() {
	synchronized(tables) {
		RMIClientTable objs = tables[currentTableIndex];
		if(System.currentTimeMillis() > objs.deathTime) {
			objs.deathTime += (timeInterval * tablesSize);
			currentTableIndex++;
			currentTableIndex = currentTableIndex % tablesSize;
			return objs;
		}
		return null;
	}
}

/**
 * Answers the table of the objects leased by a short
 * period of time.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIClientTable shortLeaseObjects() {
	return shortLeaseObjects;
}

/**
 * Answers the table of the objects that no longer
 * have any reference in the VM.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIClientTable unrefObjs() {
	return unrefObjs;
}

/**
 * Resets the unreferenced objects table, i.e. the
 * table will be empty after reseting it.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIClientTable resetUnrefObjs() {
	synchronized(unrefObjs) {
		RMIClientTable copy = new RMIClientTable(0,-2,unrefObjs.endpointTo_idToRefInfo);
		unrefObjs.endpointTo_idToRefInfo = new Hashtable();
		return copy;
	}
}

/**
 * Answers a table specified by the index i.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIClientTable tableAt(int i) {
	if(i >= 0)
		return tables[i];
	if(i == -1)
		return shortLeaseObjects;
	if(i == -2)
		return unrefObjs;
	throw new Error(com.ibm.oti.rmi.util.Msg.getString("R0003"));
}

/**
 * Adds a new client to the table according to it's lease
 * time.
 *
 * @author		OTI
 * @version		initial
 */
public static synchronized RefInfo putClient(EndpointID epid, ObjID id, long newDeathTime) {
	for(int i=-2;i<tablesSize;i++) {
		RMIClientTable t = tableAt(i);
		synchronized(t) {
			RefInfo refInfo = t.getRefInfo(epid,id);
			if(refInfo != null) {
				refInfo.incRefCount();
				t.repositionObj(epid,id,newDeathTime);
				return refInfo;
			}
		}
	}
	if(newDeathTime < timeInterval) {
		synchronized(shortLeaseObjects) {
			return shortLeaseObjects.putObjID(epid,id);
		}
	}
	int newIndex = (int)(newDeathTime % (timeInterval * tablesSize * 2)) + currentTableIndex;
	newIndex = (int)(newIndex % tablesSize);

	RMIClientTable t = tableAt(newIndex);
	synchronized(t) {
		return t.putObjID(epid,id);
	}
}

/**
 * Moves the object from one table to another acording to the
 * change made in it's lease time.
 *
 * @author		OTI
 * @version		initial
 */
public static void repositionObj(EndpointID epid, ObjID id, RefInfo refInfo) {
	RMIClientTable objs = tableAt(refInfo.getIndex());
	synchronized(objs) {
		objs.repositionObj(epid,id,RefInfo.CollectObject);
	}
}

/*
 * Maps EndpointID(s) to a table that
 * maps ObjID(s) to RefInfo(s).
 * It is used only in the client side.
 */
private Hashtable endpointTo_idToRefInfo;
private long deathTime;
public int index;

private RMIClientTable(long deathTime, int index) {
	this(deathTime,index,new Hashtable());
}

private RMIClientTable(long deathTime, int index,Hashtable endpointTo_idToRefInfo) {
	this.deathTime = deathTime;
	this.index = index;
	this.endpointTo_idToRefInfo = endpointTo_idToRefInfo;
}

/**
 * Moves the object from one table to another acording to the
 * change made in its lease time.
 *
 * @author		OTI
 * @version		initial
 */
public void repositionObj(EndpointID epid, ObjID id, long newDeathTime) {
	if(newDeathTime == RefInfo.CollectObject) {
		RMIClientTable objs = unrefObjs();
		synchronized(objs) {
			repositionObj(epid,id,objs);
		}
		return;
	}
	if(newDeathTime < timeInterval) {
		synchronized(shortLeaseObjects) {
			repositionObj(epid,id,shortLeaseObjects);
		}
		return;
	}
	int newIndex = (int)(newDeathTime % (timeInterval * tablesSize * 2)) + currentTableIndex;
	newIndex = (int)(newIndex % tablesSize);

	if(this == shortLeaseObjects) {
		newIndex = newIndex == 0 ? tablesSize - 1 : newIndex - 1;
		RMIClientTable t = tableAt(newIndex);
		synchronized(t) {
			repositionObj(epid,id,t);
		}
	} else if(newIndex != index) {
		// If the deathTime did not varied more the 1.5 minutes, refinfo is kept
		// in the same table.
		int delta = newIndex > index ? newIndex - index : index - newIndex;
		delta = tablesSize - delta >= delta ? delta : tablesSize - delta;

		if(delta > maxDelta) {
			RMIClientTable t = tableAt(newIndex);
			synchronized(t) {
				repositionObj(epid,id,t);
			}
		}
	}
}

/**
 * Moves the object from one table to another acording to the
 * change made in its lease time.
 *
 * @author		OTI
 * @version		initial
 */
private void repositionObj(EndpointID epid,ObjID id,RMIClientTable newTable) {
	if(this == newTable)
		return;
	RefInfo refInfo;
	Hashtable oldIdToRefInfo = (Hashtable)endpointTo_idToRefInfo.get(epid);
	Hashtable newIdToRefInfo = (Hashtable)newTable.endpointTo_idToRefInfo.get(epid);
	if(oldIdToRefInfo.size() > 1) {
		refInfo = (RefInfo)oldIdToRefInfo.remove(id);
		if(newIdToRefInfo == null) {
			 newIdToRefInfo = new Hashtable();
			 newTable.endpointTo_idToRefInfo.put(epid,newIdToRefInfo);
		}
		newIdToRefInfo.put(id,refInfo);
	} else {
		if(newIdToRefInfo == null) {
			refInfo = (RefInfo)oldIdToRefInfo.get(id);
			newTable.endpointTo_idToRefInfo.put(epid,oldIdToRefInfo);
		} else {
			refInfo = (RefInfo)oldIdToRefInfo.remove(id);
			newIdToRefInfo.put(id,refInfo);
		}
		endpointTo_idToRefInfo.remove(epid);
	}
	refInfo.setIndex(newTable.index);
}

/**
 * Answers the number of endpoints in the receiver.
 *
 * @author		OTI
 * @version		initial
 */
public int size() {
	return endpointTo_idToRefInfo.size();
}

/**
 * Adds a new entry EndpointID->ObjID->RefInfo to the
 * Hashtable <code>endpointTo_idToRefInfo</code>
 *
 * @author		OTI
 * @version		initial
 */
private RefInfo putObjID(EndpointID epid, ObjID id) {
	RefInfo refInfo = null;
	Hashtable idToRefInfo = (Hashtable)endpointTo_idToRefInfo.get(epid);
	if(idToRefInfo == null) {
		idToRefInfo = new Hashtable();
		endpointTo_idToRefInfo.put(epid,idToRefInfo);
	} else {
		 refInfo = (RefInfo)idToRefInfo.get(id);
	}
	if(refInfo == null) {
		refInfo = new RefInfo();
	}
	refInfo.incRefCount();
	idToRefInfo.put(id,refInfo);
	refInfo.setIndex(this.index);
	return refInfo;
}

/**
 * Gets a RefInfo from the Hashtable <code>endpointTo_idToRefInfo</code>
 *
 * @author		OTI
 * @version		initial
 */
public RefInfo getRefInfo(EndpointID epid, ObjID id) {
	Hashtable idToRefInfo = (Hashtable)endpointTo_idToRefInfo.get(epid);
	if(idToRefInfo == null)
		return null;
	return (RefInfo)idToRefInfo.get(id);
}

/**
 * Gets all pairs ObjID->RefInfo from <code>endpointTo_idToRefInfo</code>
 *
 * @author		OTI
 * @version		initial
 */
public Hashtable getReferencedObjIDs(EndpointID epid) {
	Hashtable idToRefInfo = (Hashtable)endpointTo_idToRefInfo.get(epid);
	if(idToRefInfo == null)
		return new Hashtable();
	return idToRefInfo;
}

/**
 * Gets all keys (EndPointID) from <code>endpointTo_idToRefInfo</code>
 *
 * @author		OTI
 * @version		initial
 */
public Enumeration getEndpoints() {
	return endpointTo_idToRefInfo.keys();
}

}
