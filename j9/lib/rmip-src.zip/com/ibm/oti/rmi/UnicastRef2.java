package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.rmi.*;
import java.rmi.server.*;
import com.ibm.oti.rmi.wire.*;
import com.ibm.oti.rmi.dgc.*;
import java.rmi.dgc.*;
import com.ibm.oti.rmi.util.RMIUtil;

public class UnicastRef2 extends UnicastRef {

private RMIClientSocketFactory csFactory;

/**
 * Constructs a new instance of this class.
 * This constructor is sent by RemoteObject>>#readObject
 *
 * @author		OTI
 * @version		initial
 */
public UnicastRef2() {
}

/**
 * Ensures that a DGC stub was created. If not, create it.
 *
 * @author		OTI
 * @version		initial
 */
protected void ensureDGCStubCreation(EndpointID endpoint) {
	DGCClient.createDGCStubFor(endpoint,csFactory);
}

/**
 * Answers the factory used to create sockets.
 * @author		OTI
 * @version		initial
 */
protected RMIClientSocketFactory getClientSocketFactory() {
	return csFactory;
}

/**
 * Constructs a new instance of this class and initialize
 * its endpoint - host and port - and its id.
 *
 * @author		OTI
 * @version		initial
 */
public UnicastRef2(EndpointID ep,ObjID id,RMIClientSocketFactory csf)  {
	super(ep,id);
	csFactory = csf;
}

/**
 * Constructs a new instance of this class and initializes
 * its endpoint - host and port - and its id.
 *
 * @author		OTI
 * @version		initial
 */
public UnicastRef2(int port, ObjID id,RMIClientSocketFactory csf) throws java.net.UnknownHostException {
	super(port, id);
	csFactory = csf;
}

/**
 * Reads the endpoint format.
 *
 * @author		OTI
 * @version		initial
 */
protected void readEndpointFormat(ObjectInput in) throws IOException, ClassNotFoundException {
	endPointFormat = in.readByte();
}

/**
 * Writes the endpoint format.
 *
 * @author		OTI
 * @version		initial
 */
protected void writeEndpointFormat(ObjectOutput out) throws IOException {
	/* If client socket factory is not null,
		write 1 as endPointFormat, otherwise write 0.
	*/
	if (csFactory!= null) {
		endPointFormat = 0x01;
		out.writeByte(0x01);
	}
	else
		out.writeByte(0x00);
}

/**
 * Reads the socket factory from the stream.
 *
 * @author		OTI
 * @version		initial
 */
protected void readSocketFactory(ObjectInput in) throws IOException, ClassNotFoundException {
	/* If endpoint format number is 1,
	  read the client socket factory from the stream,
	  otherwise, it has not been written to the stream.
	*/
	if (endPointFormat == 1) {
		csFactory = (RMIClientSocketFactory)in.readObject();
	}
}

/**
 * Writes the socket factory to the stream.
 *
 * @author		OTI
 * @version		initial
 */
protected void writeSocketFactory(ObjectOutput out) throws IOException {
	if (csFactory!=null)
		out.writeObject(csFactory);
}
}
