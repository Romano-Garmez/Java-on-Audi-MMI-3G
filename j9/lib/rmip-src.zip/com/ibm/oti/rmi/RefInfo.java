package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.rmi.*;
import java.rmi.server.*;
import com.ibm.oti.rmi.wire.*;
import java.rmi.dgc.*;
import com.ibm.oti.rmi.util.RMIUtil;
import com.ibm.oti.rmi.dgc.*;

/**
 * A remote reference can not be cached by the
 * RMI implementation on the client side because
 * the DGC needs to know when there are no more
 * references to this remote object.
 * So, a UnicastRef was divided into two
 * classes: UnicastRef that implements the finalize
 * method and RefInfo that stores the UnicastRef
 * information that needs to be cached.
 */
public class RefInfo {
private Hashtable referenceSet = new Hashtable();
private long deathTime = System.currentTimeMillis();
private int index = -1;

public static final long CollectObject = -1;

//Used by the client side.
private int referenceCount = 0;

/**
 * Adds a reference to the set of references.
 *
 * @author		OTI
 * @version		initial
 */
public void addReference(VMID vmid) {
	referenceSet.put(vmid,vmid);
}

/**
 * Removes a reference from the set of references.
 *
 * @author		OTI
 * @version		initial
 */
public boolean removeReference(VMID vmid) {
	synchronized(referenceSet) {
		referenceSet.remove(vmid);
		return referenceSet.isEmpty();
	}
}

/**
 * Answers the reciever's index in the RMI reference tables.
 *
 * @author		OTI
 * @version		initial
 */
public int getIndex() {
	return index;
}

/**
 * Sets the receiver's index in the RMI reference tables.
 *
 * @author		OTI
 * @version		initial
 */
public void setIndex(int newIndex) {
	index = newIndex;
}

/**
 * Answers millisecond value when the receiver
 * should be collected if no clients renew
 * it's lease.
 *
 * @author		OTI
 * @version		initial
 */
public long getDeathTime() {
	return deathTime;
}

/**
 * Sets millisecond value of when the receiver
 * should be collected if no clients renew
 * it's lease.
 *
 * @author		OTI
 * @version		initial
 */
public void setDeathTime(long time) {
	if(deathTime != CollectObject) //Too late... The object is already GCed or in process of.
		if((time > deathTime) || (time == CollectObject))
			deathTime = time;
}

/**
 * Increments the reference count, i.e. the number of
 * clients referencing the receiver.
 *
 * @author		OTI
 * @version		initial
 */
public void incRefCount() {
	referenceCount++;
}

/**
 * Decrements the reference count, i.e. the number of
 * clients referencing the receiver.
 *
 * @author		OTI
 * @version		initial
 */
public void decRefCount() {
	referenceCount--;
}

/**
 * Answers the reference count, i.e. the number of
 * clients referencing the receiver.
 *
 * @author		OTI
 * @version		initial
 */
public int referenceCount() {
	return referenceCount;
}
}
