package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.lang.reflect.*;

public class UnicastServerRef extends UnicastRef{

/**
 * Constructs a new instance of this class.
 *
 * This constructor is sent by RemoteObject>>#readObject
 *
 * @author		OTI
 * @version		initial
 */
public UnicastServerRef() {
}

/**
 * Constructs a new instance of this class and initializes
 * its endpoint - host and port - and its id.
 *
 * @author		OTI
 * @version		initial
 */
public UnicastServerRef(int port,ObjID id) throws java.net.UnknownHostException {
	super(port,id);
}

/**
 * Writes the receiver to the ObjectOutput <code>output</code>.
 * But no data is written for <code>UnicastServerRef</code> and <code>UnicastServerRef2</code>.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		output		An ObjectOutput where to write the object
 *
 * @exception 	java.io.IOException	If an error occurs attempting to write to the ObjectOutput.
 */
public void writeExternal(ObjectOutput out) throws IOException {
}

/**
 * Reads the next object from the ObjectInput <code>input</code>.
 * But no data is read for <code>UnicastServerRef</code> and <code>UnicastServerRef2</code>.
 *
 * @author		OTI
 * @version		initial
 *
 * @exception 	java.io.IOException		If an error occurs attempting to read from this ObjectInput.
 * @exception 	java.lang.ClassNotFoundException	If the class of the instance being loaded cannot be found.
 */
public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
}
}
