package com.ibm.oti.rmi.registry;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

/**
 * This class implements the RMI Registry which
 * is basically a hashtable with all the bound
 * remote objects.
 *
 * @author		OTI
 * @version		initial
 */
public class RegistryImpl extends java.rmi.server.UnicastRemoteObject implements java.rmi.registry.Registry {

private Hashtable table = new Hashtable();

/**
 * Constructs a new instance of this class.
 * The new RegistryImpl will be exported in the
 * default port <code>REGISTRY_PORT</code>
 *
 * @author		OTI
 * @version		initial
 */
public RegistryImpl() throws RemoteException {
	this(REGISTRY_PORT);
}

/**
 * Constructs a new instance of this class.
 * The new RegistryImpl will be exported in the
 * port <code>port</code>.
 *
 * @author		OTI
 * @version		initial
 */
public RegistryImpl(int port) throws RemoteException {
	this(port,null,null);
}

/**
 * Constructs a new instance of this class.
 * The new RegistryImpl will be exported in the
 * port <code>port</code> and the Registry sockets
 * will be created using the specified factories.
 *
 * @author		OTI
 * @version		initial
 */
public RegistryImpl(int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws RemoteException {
	super(port, csf, ssf);
}

/**
 * Answers a reference to a remote object specified by its name and
 * location.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in an url format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @return		Remote
 *					the reference to the remote object.
 * @exception	NotBoundException
 *					if an object with this name/location was not found
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 *
 */
public Remote lookup(String name) throws NotBoundException, AccessException {
	Object o = table.get(name);
	if(o==null)
		throw new NotBoundException(name);
	return (Remote)o;
}

/**
 *
 * Binds the object name specified in url to the remote object obj
 * in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in an url format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @exception	AlreadyBoundException
 *					if an object with this name was already bound in the registry.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if the url does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public void bind(String name, Remote stub) throws AlreadyBoundException {
	Object o = table.get(name);
	if(o!=null)
		throw new AlreadyBoundException();
	table.put(name,stub);
}

/**
 *
 * Unbinds the object name specified in url to the remote object obj
 * in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in a url format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @exception	NotBoundException
 *					if an object with this name was not found in the registry.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if the url does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public void unbind(String name) throws NotBoundException, AccessException {
	Object o = table.remove(name);
	if(o==null)
		throw new NotBoundException(name);
}

/**
 *
 * Binds the object name specified in url to the remote object obj
 * in the registry specified by host and port.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the remote object location and name in a url format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 * @exception	AccessException
 *					if the url does not point to the localhost either by
 *					using an empty host name string, "localhost" or the host name.
 */
public synchronized void rebind(String name, Remote stub) throws AccessException {
	table.put(name,stub);
}

/**
 * Answers an array of strings with all the names of the objects
 * bound in the registry specified by host and port in url.
 * The file part of the url in ignored.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		url String
 *					the registry location in a url format
 *					without the protocol (ex "//hostName:portNumber/obName)
 * @return		String[]
 *					a list with all the objects bound in the registry.
 * @exception	RemoteException
 *					if an exception occurs while communicating with the registry.
 *
 */
public synchronized String[] list() throws AccessException {
	Enumeration e = table.keys();
	String r[] = new String[table.size()];
	for(int i=0;i<table.size();i++) {
		r[i] = (String)e.nextElement();
	}
	return r;
}

}
