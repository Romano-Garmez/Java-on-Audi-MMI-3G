package com.ibm.oti.rmi.registry;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

public class Main {

/**
 * Starts the application.
 * @param args String[]
 *				null or a string specifying the port.
 */
public static void main(java.lang.String[] args) {
	try {
		if (null == System.getSecurityManager())
			System.setSecurityManager(new java.rmi.RMISecurityManager());
		int port = java.rmi.registry.Registry.REGISTRY_PORT;
		if((args != null) && (args.length > 0)) {
			port = Integer.parseInt(args[0]);
		}
		java.rmi.registry.LocateRegistry.createRegistry(port);
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	Object o = new Object();
	synchronized(o) {
		try {o.wait();} catch (Exception e){};
	}
}

}
