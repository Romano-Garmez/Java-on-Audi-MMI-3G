package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.rmi.*;
import java.rmi.server.*;
import com.ibm.oti.rmi.wire.*;
import com.ibm.oti.rmi.dgc.*;
import java.rmi.dgc.*;
import com.ibm.oti.rmi.util.RMIUtil;

/**
 * This class implements a reference to a remote object.
 *
 * @author		OTI
 * @version		initial
 */
public class UnicastRef implements RemoteRef {

protected EndpointID endpoint;
protected transient byte endPointFormat;
protected ObjID id;
protected transient RefInfo refInfo;

public static final UID LocalUID = new UID();

/**
 * Constructs a new instance of this class.
 *
 * This constructor is sent by RemoteObject>>#readObject
 *
 * @author		OTI
 * @version		initial
 */
public UnicastRef() {
	super();
}

/**
 * Constructs a new instance of this class and initializes
 * it's endpoint - host and port - and it's id.
 *
 * @author		OTI
 * @version		initial
 */
public UnicastRef(EndpointID ep,ObjID id) {
	endpoint = ep;
	this.id = id;
	//DGC will collect this object if no one makes
	//reference to it before deathTime;
	refInfo = new RefInfo();
	RMIServerTable t = RMIServerTable.tableFor(id);
	setDeathTime(t.nextDeathTime());
}

/**
 * Constructs a new instance of this class and initialize
 * its endpoint - host and port - and id.
 *
 * @author		OTI
 * @version		initial
 */
public UnicastRef(int port,ObjID id) throws java.net.UnknownHostException {
	this(new EndpointID(java.net.InetAddress.getLocalHost().getHostAddress(),port),id);
}

/**
 * Answers the receiver's TCP port.
 *
 * @author		OTI
 * @version		initial
 */
public int getPort() {
	return endpoint.getPort();
}

/**
 * Answers the receiver's host.
 *
 * @author		OTI
 * @version		initial
 */
public String getHost() {
	return endpoint.getHost();
}

/**
 * Answers the receiver's host/port.
 *
 * @author		OTI
 * @version		initial
 */
public EndpointID getEndpoint() {
	return endpoint;
}

/**
 * Answers the receiver's id.
 *
 * @author		OTI
 * @version		initial
 */
public ObjID getID() {
	return id;
}

/**
 * Answers the receiver's class name.
 *
 * @author		OTI
 * @version		initial
 */
private String getRefClass() {
	String clName = this.getClass().getName();
	return clName.substring(clName.lastIndexOf('.') + 1);
}

/**
 * Writes the receiver's class name in the output stream
 * and answers it.
 *
 * @author		OTI
 * @version		initial
 */
public String getRefClass(ObjectOutput out) {
	return getRefClass();
}

/**
 * Sends the specified message <code>mth</code> to the
 * specified receiver.
 *
 * @author		OTI
 * @version		initial
 */
public Object invoke(Remote receiver, Method mth, Object[] params, long opHash) throws Exception {
	ProtocolClient pc = ProtocolClient.clientFor(endpoint,Protocol.StreamProtocol,getClientSocketFactory());
		pc.sendMessageCallHeader();
		ObjectOutput oos = pc.createObjectOutput();
		pc.sendMessageReceiver(oos,id,-1,opHash);

		Class paramTypes[] = mth.getParameterTypes();
		if(params != null) {
			if(paramTypes.length != params.length) {
				throw new RuntimeException(mth + " is inconsistent with " + params);
			}
			try{
				for(int i=0;i<params.length;i++)
					pc.writeObject(paramTypes[i],params[i],oos);
			} catch (IOException e) {
				pc.markInvalid();
				throw new MarshalException(com.ibm.oti.rmi.util.Msg.getString("R0010"),e);
			}
		}
		oos.flush();
		//Receive the result.
		pc.waitReturnHeader();
		ObjectInput ois = pc.createObjectInput();
		pc.waitReturnValueHeader(ois);

		Class returnType = mth.getReturnType();
		if(returnType != void.class) {
			try {
				Object result = pc.readObject(returnType,ois);
				pc.release();
				return result;
			} catch (Exception e) {
				pc.markInvalid();
				throw new UnmarshalException(com.ibm.oti.rmi.util.Msg.getString("R0012"),e);
			}
		}
		pc.release();
		return null;
}

/**
 * Answers the factory that should be used to create sockets.
 *
 * @author		OTI
 * @version		initial
 */
protected RMIClientSocketFactory getClientSocketFactory() {
	if(RMISocketFactory.getSocketFactory() != null)
		return RMISocketFactory.getSocketFactory();
	return RMISocketFactory.getDefaultSocketFactory();
}

/**
 * Answers a hash code to the remote object.
 *
 * @author		OTI
 * @version		initial
 */
public int remoteHashCode(){
	return id.hashCode();
}

/**
 * Answers true if the two references point to
 * the same object otherwise answer false.
 *
 * @author		OTI
 * @version		initial
 */
public boolean remoteEquals(RemoteRef obj) {
	if(obj instanceof UnicastRef) {
		UnicastRef o = (UnicastRef)obj;
		return ((endpoint.equals(o.endpoint)) && (id.equals(o.id)));
	}
	return false;
}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String remoteToString(){
	return this.getClass().getName() + ":[" + getHost() + ":" + getPort() + "||" + id + "]";
}

/**
 * Writes the receiver to the ObjectOutput <code>output</code>.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		output		An ObjectOutput where to write the object
 *
 * @exception 	java.io.IOException	If an error occurs attempting to write to the ObjectOutput.
 */
public void writeExternal(ObjectOutput out) throws IOException {
	writeEndpointFormat(out);
	out.writeUTF(getHost());
	out.writeInt(getPort());
	writeSocketFactory(out);
	id.write(out);
	//Did not find any place in the spec specifying
	//this boolean. I am writing it just to be
	//compatible with JDK. Must check it better.
	//What does this boolean mean.

	out.writeBoolean(false);
}

/**
 * Reads the next object from the ObjectInput <code>input</code>.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		the next object read from the ObjectInput
 *
 * @exception 	java.io.IOException		If an error occurs attempting to read from this ObjectInput.
 * @exception 	java.lang.ClassNotFoundException	If the class of the instance being loaded cannot be found.
 */
public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
	readEndpointFormat(in);
	String hostname = in.readUTF();
	endpoint = new EndpointID(hostname,in.readInt());
	readSocketFactory(in);
	id = ObjID.read(in);
	ensureDGCStubCreation(endpoint);
	//Must send dirty right away because it must renew the
	//lease before giving the change to the server to loose the
	//reference. So this call can not be async.
	refInfo = DGCClient.sendDirty(endpoint,id);
	//Did not find any place in the spec specifying
	//this boolean. I am reading it just to be
	//compatible with JDK. Must check it better.
	//What does this boolean mean.
	in.readBoolean();
}

/**
 * Ensures that a DGC stub was created. If not, create it.
 *
 * @author		OTI
 * @version		initial
 */
protected void ensureDGCStubCreation(EndpointID endpoint) {
	DGCClient.createDGCStubFor(endpoint,null);
}

/**
 * Reads the endpoint format. Re-implemented by the supclasses.
 *
 * @author		OTI
 * @version		initial
 */
protected void readEndpointFormat(ObjectInput in) throws IOException, ClassNotFoundException {
}

/**
 * Writes the endpoint format. Re-implemented by the supclasses.
 *
 * @author		OTI
 * @version		initial
 */
protected void writeEndpointFormat(ObjectOutput out) throws IOException {
}

/**
 * Reads the socket factory from the stream. Re-implemented by the supclasses.
 *
 * @author		OTI
 * @version		initial
 */
protected void readSocketFactory(ObjectInput in) throws IOException, ClassNotFoundException {
}

/**
 * Writes the socket factory from the stream. Re-implemented by the supclasses.
 *
 * @author		OTI
 * @version		initial
 */
protected void writeSocketFactory(ObjectOutput out) throws IOException {
}

/**
 * Adds a vmid to the references set.
 *
 * @author		OTI
 * @version		initial
 */
public void addReference(VMID vmid) {
	refInfo.addReference(vmid);
}

/**
 * Removes a vmid from the references set.
 *
 * @author		OTI
 * @version		initial
 */
public boolean removeReference(VMID vmid) {
	return refInfo.removeReference(vmid);
}

/**
 * Answers the time when the object should be collected.
 * Used in the server side.
 *
 * @author		OTI
 * @version		initial
 */
public long getDeathTime() {
	return refInfo.getDeathTime();
}

/**
 * Sets the time when the object should be collected.
 * Used in the server side.
 *
 * @author		OTI
 * @version		initial
 */
public void setDeathTime(long time) {
	refInfo.setDeathTime(time);
}

/**
 * Removes the receiver from it's current table and
 * adds it to the unreferenced objects table.
 *
 * Used in the client side.
 *
 * @author		OTI
 * @version		initial
 */
protected void finalize () throws Throwable {
	try {
		refInfo.decRefCount();
		if(refInfo.referenceCount() == 0) {
			RMIClientTable.repositionObj(endpoint,id,refInfo);
		}
	} catch (Exception ex) {
	}
}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String toString () {
	return getRefClass() + "[" + id.toString() + "]::" + super.toString();
}

}
