package com.ibm.oti.rmi;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;

public class DefaultSocketFactory extends java.rmi.server.RMISocketFactory {

/**
 * Creates and answers a new java.net.Socket connecting
 * it to the specified host and port.
 *
 * @author		OTI
 * @version		initial
 */
public Socket createSocket(String host, int port) throws IOException {
	return new Socket(host,port);
}

/**
 * Creates and answers a new java.net.ServerSocket that
 * will be used to accept RMI connections in the specified
 * port.
 *
 * @author		OTI
 * @version		initial
 */
public ServerSocket createServerSocket(int port) throws IOException {
	return new ServerSocket(port);
}

}
