package com.ibm.oti.rmi.dgc;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.*;
import java.rmi.dgc.*;
import java.rmi.server.*;
import java.util.*;
import com.ibm.oti.rmi.*;
import com.ibm.oti.rmi.util.RMIUtil;
import java.security.AccessController;
import java.security.PrivilegedAction;

/**
 * This class implements the server side of the
 * distributed garbage collector. As a remote
 * object it implements the interface DGC.
 * It implements a Runnable which runs for
 * the entire life of the program removing
 * remote objects from the RMI cache freeing and
 * them to be collected by the system GC.
 *
 * @author		OTI
 * @version		initial
 */
public class DGCImpl extends java.rmi.server.UnicastRemoteObject implements DGC, Runnable {

private static long leaseValue = -1;

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
public DGCImpl() throws RemoteException {
	super();
}

/**
 * Renews the lease time of remote objects.
 * It is a remote message sent by the client
 * side while a remote ref is kept.
 *
 * @author		OTI
 * @version		initial
 */
public Lease dirty(ObjID[] ids, long count, Lease lease){
	VMID vmid = lease.getVMID();
	if(vmid == null) {
		vmid = new VMID();
	}
	long value = Long.MAX_VALUE;
	for(int i=0;i<ids.length;i++) {
		RMIServerTable t = RMIServerTable.tableFor(ids[i]);
		Remote ro = t.getRemoteObj(ids[i],true);
		if(ro != null) {
			UnicastRef r = (UnicastRef)RMIServerTable.getStub(ro).getRef();
			r.addReference(vmid);
			r.setDeathTime(t.nextDeathTime());
			value = value < t.nextDeathTime() ? value : t.nextDeathTime();
		}
	}
	value = value - System.currentTimeMillis();
	value = value < lease.getValue() ? value : lease.getValue();
	Lease l = new Lease(vmid,value);
	return l;
//	return lease;
}

/**
 * Removes remote references from the RMI cache.
 * It is a remote message sent by the client
 * side when remote references are collected
 * by the system gc.
 *
 * @author		OTI
 * @version		initial
 */
public void clean(ObjID[] ids, long p2, VMID vmid, boolean strong) {

	for(int i=0;i<ids.length;i++) {
		Remote ro = RMIServerTable.getObj(ids[i]);
		if(ro != null) {
			UnicastRef r = (UnicastRef)RMIServerTable.getStub(ro).getRef();
			if(r.removeReference(vmid)) {
				try {
					UnicastRemoteObject.unexportObject(ro,true);
					if(ro instanceof Unreferenced)  {
						unrefSender().add(ro);
					}
				} catch (NoSuchObjectException ex) {}
			}
		}
	}
}

/**
 * Runs during the entire life of the program
 * removing unreferenced remote objects from
 * the RMI cache.
 *
 * @author		OTI
 * @version		initial
 */
public void run() {
	long sleepTime = getLeaseValue() / RMIServerTable.tablesSize;
	while(true) {
		RMIServerTable t = RMIServerTable.nextTable();
		try {
			if(t== null) {
				synchronized(this) {
					Thread.sleep(sleepTime);
					for(;t == null;t = RMIServerTable.nextTable())
						Thread.sleep(sleepTime / 10);
				}
			}
		} catch (InterruptedException ex){};

		Enumeration ids = t.getExportedObjIDs();
		while(ids.hasMoreElements()) {
			ObjID id = (ObjID)ids.nextElement();
			//Remote ro = RMIServerTable.getObj(id);
			Remote ro = t.getRemoteObj(id, false);
			RemoteStub rs = RMIServerTable.getStub(ro);
			if (rs!=null) {
				UnicastRef r = (UnicastRef)rs.getRef();
				if(r.getDeathTime() <= t.deathTime())
					try {
					UnicastRemoteObject.unexportObject(ro,true);
					if(ro instanceof Unreferenced)  {
						unrefSender().add(ro);
					}
				} catch (NoSuchObjectException ex) {}
			}
		}
		t.updateDeathTime();
	}
}

private static boolean initialized = false;

/**
 * Initializes the Distributed Garbage Collector.
 *
 * @author		OTI
 * @version		initial
 */
public static synchronized void initDGC() {
	if(!initialized) {
		try {
			initialized = true;
			Thread t = new Thread(new DGCImpl(),"RMI-DGC");
			t.setPriority(Thread.MAX_PRIORITY - 1);
			t.start();
		} catch (RemoteException e) {
		}
	}
}

/**
 * Implements a Thread that sends the message unreferenced
 * to the remote objects that implement the interface Unreferenced.
 *
 * @author		OTI
 * @version		initial
 */
static AsyncUnrefSender unrefSender = null;

static AsyncUnrefSender unrefSender() {
	if(unrefSender == null) {
		unrefSender = new AsyncUnrefSender("RMI-Unreferenced sender");
		unrefSender.start();
	}
	return unrefSender;
}

static class AsyncUnrefSender extends Thread {

	Vector queue = new Vector();
	Object sync = new Object();

	public AsyncUnrefSender(String name) {
		super(name);
	}
	public void run() {
		while(true) {
			Unreferenced unref;
			synchronized(sync) {
				while(queue.size() == 0) {
					try{sync.wait();} catch(InterruptedException ex){}
				}
				unref = (Unreferenced)queue.remove(0);
			}
			unref.unreferenced();
		}
	}

	public void add(Object ro) {
		synchronized(sync) {
			queue.add(ro);
			sync.notify();
		}
	}
}

/**
 * Answers the value of the property "java.rmi.dgc.leaseValue";
 *
 * @author		OTI
 * @version		initial
 */
static long getLeaseValue() {
	if(leaseValue == -1) {
		String value = (String)AccessController.doPrivileged(new PrivilegedAction() {
			public Object run() {
				return System.getProperty("java.rmi.dgc.leaseValue","600000");
			}});
		try {
			leaseValue = Integer.parseInt(value);
		} catch (NumberFormatException e) {
			leaseValue = 600000;
		}
	}
	return leaseValue;
}

}
