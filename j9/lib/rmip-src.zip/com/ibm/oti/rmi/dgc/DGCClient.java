package com.ibm.oti.rmi.dgc;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import com.ibm.oti.rmi.util.RMIUtil;
import com.ibm.oti.rmi.*;
import java.util.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.dgc.*;
import java.lang.reflect.*;

/**
 * This class implements the client side of the distributed
 * garbage collector (DGC). It is basicaly a leaser thread
 * which keeps sending the message <code>dirty()</code> to
 * the server when the lease time is finishing and the message
 * <code>clean()</code> when the client does not have references
 * to the remote object anymore.
 *
 * @author		OTI
 * @version		initial
 */
public class DGCClient extends Thread {

static VMID localHostVMID;
static Lease dirtyLease;
static DGCClient defaultDGCClient;
static long sequenceNumber;

/*
 *	This RMI implementation does not support leases shorter
 * than 10 seconds. Default time is specified as 10 minutes.
 */
static final long defaultSleepTime = 10000;

long sleepTime;

static {
	sequenceNumber = 0;
	localHostVMID = new VMID();
	dirtyLease = new Lease(localHostVMID,DGCImpl.getLeaseValue());
	defaultDGCClient = new DGCClient("RMI-Leaser");
	defaultDGCClient.setDaemon(true);
	defaultDGCClient.setPriority(Thread.MAX_PRIORITY - 1);
	defaultDGCClient.start();
}

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
private DGCClient (String threadName) {
	super(threadName);
	sleepTime = defaultSleepTime;
}

/**
 * Runs during the whole life of the program leasing
 * referenced and cleaning unreferenced remote objects.
 *
 * @author		OTI
 * @version		initial
 */
public void run() {
	while(Thread.currentThread() == defaultDGCClient) {
		RMIClientTable objs = RMIClientTable.resetUnrefObjs();
		handleObjects(false,objs);
		handleObjects(true,RMIClientTable.shortLeaseObjects());
		objs = RMIClientTable.nextTable();
		if(objs != null) {
			handleObjects(true,objs);
		}
		try {
			sleep(sleepTime);
		} catch (InterruptedException ex) {}
	}
}

/**
 * If <code>sendDirty</code> is true renew the leases
 * of all objects in the table <code>objs</code> otherwise
 * send clean clearing the references on the server side.
 */
private void handleObjects(boolean sendDirty,RMIClientTable objs) {
	if(objs.size() == 0)
		return;
	synchronized(objs) {
		if(objs.size() == 0)
			return;

		Enumeration endpoints = objs.getEndpoints();
		while(endpoints.hasMoreElements()) {
			EndpointID epid = (EndpointID)endpoints.nextElement();
			Hashtable objIDsTable = objs.getReferencedObjIDs(epid);
			if(objIDsTable.size() > 0) {
				Enumeration objIDs = objIDsTable.keys();
				ObjID[] ids = new ObjID[objIDsTable.size()];
				for(int i=0;i<ids.length;i++) {
					ids[i] = (ObjID)objIDs.nextElement();
				}
				if(sendDirty) {
					sendDirty(epid,ids,objs);
				} else {
					sendClean(epid,ids);
				}
			}
		}
	}
}

/*
 * Sends the message dirty() to the DGC server.
 */
private void sendDirty(EndpointID epid,ObjID[] ids,RMIClientTable objs) {
	if(ids.length == 0)
		return;
	try {
		DGC dgc = dgcStubFor(epid);
		Lease l = dgc.dirty(ids,sequenceNumber,dirtyLease);
		if(localHostVMID == null) {
			localHostVMID = l.getVMID();
			dirtyLease = new Lease(localHostVMID,DGCImpl.getLeaseValue());
		}
		synchronized (objs) {
			for(int i=0;i<ids.length;i++) {
				objs.repositionObj(epid,ids[i],l.getValue());
			}
		}
	} catch (RemoteException e) {
		try {
			DGC dgc = dgcStubFor(epid);
			dgc.clean(ids,sequenceNumber,localHostVMID,true);
		} catch (ConnectIOException ex) {
		} catch (ConnectException ex) {
		} catch (RemoteException ex) {
		}
	}
}

/*
 * Sends the message dirty() to the DGC server.
 */
private RefInfo sendDirty0(EndpointID epid,ObjID id) {
	try {
		DGC dgc = dgcStubFor(epid);
		Lease l = dgc.dirty(new ObjID[]{id},sequenceNumber,dirtyLease);
		if(localHostVMID == null) {
			localHostVMID = l.getVMID();
			dirtyLease = new Lease(localHostVMID,DGCImpl.getLeaseValue());
		}
		return RMIClientTable.putClient(epid,id,l.getValue());
	} catch (RemoteException e) {
		try {
			DGC dgc = dgcStubFor(epid);
			Lease l = dgc.dirty(new ObjID[]{id},sequenceNumber,dirtyLease);
			if(localHostVMID == null) {
				localHostVMID = l.getVMID();
				dirtyLease = new Lease(localHostVMID,DGCImpl.getLeaseValue());
			}
			return RMIClientTable.putClient(epid,id,l.getValue());
		} catch (ConnectIOException ex) {
		} catch (ConnectException ex) {
		} catch (RemoteException ex) {
		}
		return null;
	}
}

/*
 * Sends the message dirty() to the DGC server.
 */
public static RefInfo sendDirty(EndpointID epid,ObjID id) {
	return defaultDGCClient.sendDirty0(epid,id);
}

/*
 * Sends the message clean() to the DGC server.
 */
private void sendClean(EndpointID epid,ObjID[] ids) {
	if(ids.length == 0)
		return;
	try {
		DGC dgc = dgcStubFor(epid);
		dgc.clean(ids,sequenceNumber,localHostVMID,false);
	} catch (ConnectIOException ex) {
	} catch (ConnectException ex) {
	} catch (RemoteException ex) {
	}
}

/*
 * Maps endpoints - host/port - to DGCStubs.
 */
private static Hashtable dgcStubs = new Hashtable();

/*
 * Creats a new DGCStub if one is not already created
 * and adds it to dgcStubs.
 */
public static DGC createDGCStubFor (EndpointID epid, RMIClientSocketFactory csf) {
	synchronized(dgcStubs) {
		DGC stub = dgcStubFor(epid);
		if(stub != null) return stub;

		ObjID id = new ObjID(ObjID.DGC_ID);
		RemoteRef r;
		if(csf == null)
			r = new UnicastRef(epid,id);
		else
			r = new UnicastRef2(epid,id,csf);

		try {
			Class c = Class.forName("com.ibm.oti.rmi.dgc.DGCImpl_Stub");
			Constructor constructor = c.getConstructor(new Class[]{RemoteRef.class});
			stub = (DGC)constructor.newInstance(new Object[]{r});
			dgcStubs.put(epid,stub);
			return stub;
		} catch (ClassNotFoundException ex) {
			throw new InternalError(com.ibm.oti.rmi.util.Msg.getString("R0004","DGCImpl_Stub") + ": " + ex);
		} catch (NoSuchMethodException ex) {
			throw new InternalError(com.ibm.oti.rmi.util.Msg.getString("R0004","DGCImpl_Stub(RemoteRef r)") + ": " + ex);
		} catch (IllegalAccessException ex) {
			throw new InternalError(com.ibm.oti.rmi.util.Msg.getString("R0005","DGCImpl_Stub(RemoteRef r)") + ": " + ex);
		} catch (InstantiationException ex) {
			throw new InternalError(com.ibm.oti.rmi.util.Msg.getString("R0006","DGCImpl_Stub") + ": " + ex);
		} catch (InvocationTargetException ex) {
			throw new InternalError(com.ibm.oti.rmi.util.Msg.getString("R0006","DGCImpl_Stub") + ": " + ex.getTargetException());
		}
	}
}

/*
 * Answers a DGCStub if there is one in the cache and
 * otherwise answers null.
 */
private static DGC dgcStubFor (EndpointID epid) {
	synchronized(dgcStubs) {
		DGC stub;
		stub = (DGC)dgcStubs.get(epid);
		if(stub != null)
			return stub;
		return null;
	}
}

}
