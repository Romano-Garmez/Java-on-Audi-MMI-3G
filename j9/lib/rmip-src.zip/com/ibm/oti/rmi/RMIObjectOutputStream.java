package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.security.AccessController;
import java.security.PrivilegedAction;

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
public class RMIObjectOutputStream extends java.io.ObjectOutputStream {

/**
 * Constructs a new RMIObjectOutputStream on the OutputStream <code>output</code>.  All
 * writes are now filtered through this stream.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		output		The non-null OutputStream to filter writes on.
 *
 * @exception		IOException		If an IO exception happened when writing the object stream header
 */
public RMIObjectOutputStream(OutputStream output) throws IOException {
	super(output);
	AccessController.doPrivileged(new PrivilegedAction() {
		public Object run() {
			return enable();
		}});
}

private Object enable() {
	enableReplaceObject(true);
	return null;
}

/**
 * Writes urls codebase for class <code>aClass</code> into the stream represented
 * by the receiver. This urls is read when deserializing the class
 * descriptor (ObjectStreamClass) for this class from the input stream.
 *
 * @author		OTI
 * @version		initial
 *
 * @param 		aClass	The class to annotate
 *
 * @exception	IOException		If an IO exception happened when annotating the class.
 *
 * @see			ObjectInputStream.resolveClass()
 */
protected void annotateClass(Class aClass) throws IOException {
	String urls = RMIClassLoader.getClassAnnotation(aClass);
	writeObject(urls);
}

/**
 * Computes the replacement object for the original object
 * <code>object</code> and answers the replacement.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		object		Original object for which a replacement may be defined.
 *
 * @return		Object		A possibly new replacement object for <code>object</code>
 *
 * @exception		java.io.IOException		If any IO problem occurred when trying to resolve the object.
 *
 * @see			enableReplaceObject()
 * @see			ObjectInputStream.enableResolveObject()
 * @see			ObjectInputStream.resolveObject()
 */
protected Object replaceObject(Object object) throws IOException {
	if(object instanceof Remote)
		return RemoteObject.toStub((Remote)object);
	return object;
}
}
