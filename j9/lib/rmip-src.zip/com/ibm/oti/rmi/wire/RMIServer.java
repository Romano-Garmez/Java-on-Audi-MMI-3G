package com.ibm.oti.rmi.wire;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.rmi.server.*;
import java.security.*;
import java.util.*;

/**
 * This class implements a thread that keeps accepting
 * connections and starting a ProtocolServer.
 *
 * @author		OTI
 * @version		initial
 */
public class RMIServer extends java.lang.Thread {
static int socketReadTimeOutValue = -1;

private ServerSocket ss;
private byte protocol;
private int references=0;

static RMIServer defaultServer;
static Hashtable servers = new Hashtable();

/**
 * Constructs a new instance of this class and initializes
 * it's name.
 *
 * @author		OTI
 * @version		initial
 */
private RMIServer(String name) {
	super(name);
}

/**
 * Answers a server that accepts a connection in the specified port.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIServer serverFor(int port,byte protocol, RMIServerSocketFactory ssf) throws IOException {
	if(port == 0) {
		synchronized(servers) {
			if(defaultServer != null)
				return defaultServer;
			defaultServer = startServer(port,protocol,ssf);
			defaultServer.references = 1;
			return defaultServer;
		}
	} else {
		synchronized(servers) {
			RMIServer s = (RMIServer)servers.get(new Integer(port));
			if(s == null)
				s = startServer(port,protocol,ssf);
			s.references++;
			servers.put(new Integer(port),s);
			return s;
		}
	}
}

/**
 * Answers a server for the specified port.
 * Gets it from the cache if there is one otherwise
 * creates a new one.
 *
 * @author		OTI
 * @version		initial
 */
public static RMIServer serverFor(int port) {
	if(port == 0)
		return defaultServer;
	else
		return (RMIServer)servers.get(new Integer(port));
}

/**
 * Creates a new server to accept a connection in the
 * specified port.
 *
 * @author		OTI
 * @version		initial
 */
private static ProtocolServer newServer(Socket s,byte protocol) throws IOException {
	if(protocol == Protocol.StreamProtocol)
		return new StreamProtocolServer(s);
	return null;
}

/**
 * Starts a new RMIServer.
 *
 * @author		OTI
 * @version		initial
 */
private static RMIServer startServer(int port, final byte protocol, RMIServerSocketFactory ssf) throws IOException {
	ServerSocket ss = ssf.createServerSocket(port);
	RMIServer s = new RMIServer("RMI-Accept:" + ss.getLocalPort());
	s.ss = ss;
	s.protocol = protocol;
	s.setDaemon(true);
	s.start();
	return s;
}

/**
 * This thread keeps accepting connections and starting protocol
 * servers.
 *
 * @author		OTI
 * @version		initial
 */
public void run() {
	if(this != defaultServer){
		try { ss.setSoTimeout(60000); } catch (SocketException e) {};
	}
	while(true) {
		try {
			Socket s = ss.accept();
			s.setSoTimeout(getSocketReadTimeOutValue());
			newServer(s,protocol);
		} catch (InterruptedIOException ex) {
			if(references <= 0) {
				synchronized(servers) {
					if(references <= 0) {
						try { ss.close(); } catch (IOException e) {}
						if (servers.get(new Integer(ss.getLocalPort()))==this){
							servers.remove(new Integer(ss.getLocalPort()));
						}
						return;
					}
				}
			}
		} catch (IOException ex) {
			RMIFailureHandler fh = RMISocketFactory.getFailureHandler();
			if(fh != null)
				if(!fh.failure(ex))
					return;
		}
	}
}

/**
 * Answers the value of the property "com.ibm.oti.rmi.readTimeout";
 *
 * @author		OTI
 * @version		initial
 */
static int getSocketReadTimeOutValue() {
	if(socketReadTimeOutValue == -1) {
		final String defaultValue= (new Integer(2 * 3600 * 1000)).toString();  // 2 hours
		String value = (String)AccessController.doPrivileged(new PrivilegedAction() {
			public Object run() {
				return System.getProperty("com.ibm.oti.rmi.readTimeout",defaultValue);
			}});
		try {
			socketReadTimeOutValue = Integer.parseInt(value);
		} catch (NumberFormatException e) {
			socketReadTimeOutValue = 2 * 3600 * 1000;
		}
	}
	return socketReadTimeOutValue;
}

/**
 * Answers the port where the receiver is accepting connections.
 *
 * @author		OTI
 * @version		initial
 */
public int getLocalPort() {
	return ss.getLocalPort();
}

/**
 * Decrements the number of references to the receiver, i.e. the
 * number of remote objects using the receiver.
 *
 * @author		OTI
 * @version		initial
 */
public void decReference() {
	if(this != defaultServer)
		references--;
}

}
