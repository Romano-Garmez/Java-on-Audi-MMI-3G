package com.ibm.oti.rmi.wire;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.lang.reflect.*;

import java.security.AccessController;
import java.security.PrivilegedAction;

import com.ibm.oti.rmi.*;

/**
 * This is the superclass of all RMI protocols on the client side.
 *
 * @author		OTI
 * @version		initial
 */
public abstract class ProtocolClient extends Protocol {

private static final byte Locked = -1;
private static final byte Invalid = -2;
private static final byte GCPasses = 3;
private static final byte GCCollect = 0;

private byte status = GCPasses;

static Hashtable connections;
static {
	 connections = new Hashtable();
	 Thread t = new ConnectionGC("RMI-ConnectionGC");
	 t.setDaemon(true);
	 t.start();
}

protected abstract void sendHeader() throws IOException, MarshalException;
public abstract void sendMessageCallHeader() throws IOException;
public abstract void sendMessageReceiver(ObjectOutput oos, ObjID id,int operation,long hash) throws IOException;
public abstract void waitReturnHeader() throws IOException;
public abstract void waitReturnValueHeader(ObjectInput ois) throws Exception;
public abstract ObjectOutput createObjectOutput() throws IOException;
public abstract ObjectInput createObjectInput() throws IOException;
public abstract void close();

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
ProtocolClient() throws IOException {
	super();
}

/**
 * Constructs a new instance of this class and initializes the socket
 * and connection.
 *
 * @author		OTI
 * @version		initial
 */
ProtocolClient(Socket s) throws IOException {
	super(s);
}

/**
 * Answers a ProtocolClient connected to the specified endpoint.
 * Gets one from the connections cache if there is a free connection
 * otherwise creates a new one.
 *
 * @author		OTI
 * @version		initial
 */
public static ProtocolClient clientFor(EndpointID epid,byte protocol,RMIClientSocketFactory csf) throws IOException  {
	synchronized(connections) {
		Vector pcs = (Vector)connections.get(epid);
		if(pcs == null) {
			pcs = new Vector();
			ProtocolClient pc = newClient(epid,protocol,csf);
			pcs.add(pc);
			connections.put(epid,pcs);
			pc.lock();
			return pc;
		}
		while(true) {
			ProtocolClient pc = null;
			try {
				for(int i=0;i<pcs.size();i++) {
					pc = (ProtocolClient)pcs.elementAt(i);
					if(pc.isFree()) {
						pc.lock();
						//Must check if the connection is still valid.
						pc.conn.getInputStream().available();
						return pc;
					}
				}
				break;
			} catch (IOException ex) {
				//The connection is invalid. Try to find another one.
				if(pc != null) pc.markInvalid();
			}
		}
		//There is no free ProtocolClient, create one.
		ProtocolClient pc = newClient(epid,protocol,csf);
		pcs.add(pc);
		pc.lock();
		return pc;
	}
}

/*
 * Creates a new protocol client and connects it to the specified endpoint.
 *
 * @author		OTI
 * @version		initial
 */
private static ProtocolClient newClient(EndpointID epid,int protocol,RMIClientSocketFactory csf) throws IOException {
	if(protocol == Protocol.StreamProtocol)
		return new StreamProtocolClient(epid,csf);
	return null;
}

/**
 * Sets the status of the connection to be <code>Locked</code>, i.e.
 * the connection will be in use by some remote call. It can not be
 * collected or used by any other process.
 *
 * @author		OTI
 * @version		initial
 */
protected void lock() {
	status = Locked;
}

/**
 * Releases the connection, i.e. it is free to be used by any remote
 * call or it will be collected if not used for a while.
 *
 * @author		OTI
 * @version		initial
 */
public void release() {
	synchronized(connections) {
		status = GCPasses;
	}
}

/**
 * Marks the connection as invalid, i.e. it is not free to be used by any remote
 * call and will be collected by the garbage collector.
 *
 * @author		OTI
 * @version		initial
 */
public void markInvalid() {
	synchronized(connections) {
		status = Invalid;
	}
}

/**
 * Answers true if the connection is free to be used by a remote call
 * otherwise answers false.
 *
 * @author		OTI
 * @version		initial
 */
protected boolean isFree() {
	return status > 0;
}

/**
 * This inner class implements a thread that runs
 * during the whole life of the program checking if
 * there are connections not having been used for a while.
 * If so, close the connection and remove it from
 * the cache.
 *
 * @author		OTI
 * @version		initial
 */
static class ConnectionGC extends Thread {
static int socketConnectionTimeOutValue = -1;

protected ConnectionGC(String name) {
	super(name);
}

public void run() {
	while(true) {
		try {
			// sleep(5000);
			sleep(getConnectionTimeOutValue()/GCPasses);
		} catch (InterruptedException ex) {}
		synchronized(connections) {
			Enumeration endpoints = connections.keys();
			while(endpoints.hasMoreElements()) {
				EndpointID epid = (EndpointID)endpoints.nextElement();
				Vector pcs = (Vector)connections.get(epid);
				ProtocolClient[] pcsArray = new ProtocolClient[pcs.size()];
				pcs.toArray(pcsArray);
				for(int i=0;i<pcsArray.length;i++) {
					ProtocolClient pc = (ProtocolClient)pcsArray[i];
					if (pc.status == Invalid) {
							pcs.remove(pc);
							pc.close();
					}
					if (pc.isFree()) {
						pc.status--;
						if (pc.status == GCCollect) {
							pcs.remove(pc);
							pc.close();
						}
					}
				}
				if(pcs.size() == 0)
					connections.remove(epid);
			}
		}
	}
}

/**
 * Answers the value of the property "com.ibm.oti.rmi.connectionTimeout";
 *
 * @author		OTI
 * @version		initial
 */
static int getConnectionTimeOutValue() {
	if(socketConnectionTimeOutValue == -1) {
		final String defaultValue= (new Integer(15000)).toString();  // 15 secs
		String value = (String)AccessController.doPrivileged(new PrivilegedAction() {
			public Object run() {
				return System.getProperty("com.ibm.oti.rmi.connectionTimeout",defaultValue);
			}});
		try {
			socketConnectionTimeOutValue = Integer.parseInt(value);
		} catch (NumberFormatException e) {
			socketConnectionTimeOutValue = 15000; //15 secs
		}
	}
	return socketConnectionTimeOutValue;
}

}

}
