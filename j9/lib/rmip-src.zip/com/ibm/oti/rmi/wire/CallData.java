package com.ibm.oti.rmi.wire;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.rmi.server.*;

/**
 * An instance of this class holds the information needed to
 * dispatch a remote method. It has the id of the method's receiver,
 * and the method's hash, number, and arguments.
 *
 * @author		OTI
 * @version		initial
 */
public class CallData {

private ObjID id;
private int opNumber;
private long hash;
private Object[] opArgs;

/**
 * Constructs a new instance of this class and initializes the
 * receiver's id, the method's hash, number and arguments.
 *
 * @author		OTI
 * @version		initial
 */
public CallData(ObjID id,int opNumber,long hash,Object[] opArgs) {
	this.id = id;
	this.opNumber = opNumber;
	this.hash = hash;
	this.opArgs = opArgs;
}

/**
 * Answers the receiver's remote object's id.
 *
 * @author		OTI
 * @version		initial
 */
public ObjID id(){
	return id;
}

/**
 * Answers the receiver's method's index.
 *
 * @author		OTI
 * @version		initial
 */
public int opNumber() {
	return opNumber;
}

/**
 * Answers the reciever's method's hash.
 *
 * @author		OTI
 * @version		initial
 */
public long hash() {
	return hash;
}

/**
 * Answers the receiver's method's arguments.
 *
 * @author		OTI
 * @version		initial
 */
public Object[] opArgs() {
	return opArgs;
}

}
