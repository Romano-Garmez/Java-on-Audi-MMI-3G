package com.ibm.oti.rmi.wire;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.lang.reflect.*;
import com.ibm.oti.rmi.*;

/**
 * This is the superclass of all RMI protocols.
 *
 * @author		OTI
 * @version		initial
 */
public abstract class Protocol {

public static final short Version = 0x0002;
public static final byte StreamProtocol = 0x4b;
public static final byte SingleOpProtocol = 0x4c;
public static final byte MultiplexProtocol = 0x4d;
public static final int HeaderPrefix = 0x4a524d49;

public static final byte CallPrefix = 0x50;
public static final byte Ping = 0x52;
public static final byte DgcAckPrefix = 0x54;

public static final byte ProtocolAck = 0x4e;
public static final byte ProtocolNotSupported = 0x4f;

public static final byte ReturnDataPrefix = 0x51;
public static final byte PingAck = 0x53;

public static final byte ReturnValuePrefix = 0x01;
public static final byte ReturnExceptionPrefix = 0x02;

Socket conn;
DataInputStream dis;
DataOutputStream dos;

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
Protocol() throws IOException {
}

/**
 * Constructs a new instance of this class and initializes
 * the TCP connection or starts the server depending on
 * the subclass.
 *
 * @author		OTI
 * @version		initial
 */
Protocol(Socket s) throws IOException {
	init(s);
}

/**
 * Initializes the receiver's socket, output and input streams.
 *
 * @author		OTI
 * @version		initial
 */
void init(Socket s) throws IOException {
	conn = s;
	dos = new DataOutputStream(new BufferedOutputStream(conn.getOutputStream()));
	dis = new DataInputStream(new BufferedInputStream(conn.getInputStream()));
}

/**
 * Flushes the receiver's output stream.
 *
 * @author		OTI
 * @version		initial
 */
public void flushOutputStream () throws IOException {
	dos.flush();
}

/**
 * Answers the receiver's stream used to read the information
 * needed to dispath a remote call, i.e. to read the receiver,
 * method and argument on the server side and the
 * result on the client side.
 *
 * @author		OTI
 * @version		initial
 */
public InputStream getInputStream() {
 return dis;
}

/**
 * Answers the stream used to send the information
 * needed to dispath a remote call, i.e. send the receiver,
 * method, and arguments on the client side and the
 * result on the server side.
 *
 * @author		OTI
 * @version		initial
 */
public OutputStream getOutputStream() {
 return dos;
}

/**
 * Reads an object or a primitive type from the specified stream
 * acording to the specified class.
 *
 * @author		OTI
 * @version		initial
 */
public Object readObject(Class c,ObjectInput ois) throws IOException, ClassNotFoundException {
	if(c.isPrimitive()) {
		if(c == boolean.class)
			return new Boolean(ois.readBoolean());
		if(c == byte.class)
			return new Byte(ois.readByte());
		if(c == char.class)
			return new Character(ois.readChar());
		if(c == short.class)
			return new Short(ois.readShort());
		if(c == int.class)
			return new Integer(ois.readInt());
		if(c == long.class)
			return new Long(ois.readLong());
		if(c == float.class)
			return new Float(ois.readFloat());
		if(c == double.class)
			return new Double(ois.readDouble());
		return null;
	} else {
		//if non remote class
		if (!java.rmi.Remote.class.isAssignableFrom(c)){
			if(!c.getName().startsWith("java.rmi") && !c.getName().startsWith("java.lang") && !c.getName().startsWith("[Ljava.rmi"))
				((RMIObjectInputStream)ois).setCloader(c.getClassLoader());
		}
		return ois.readObject();
	}
}

/**
 * Writes an object or a primitive type to the specified stream
 * acording to the specified class.
 *
 * @author		OTI
 * @version		initial
 */
public void writeObject(Class c, Object result, ObjectOutput oos) throws IOException {
	if(c.isPrimitive()) {
		if(c == void.class)
			return;
		if(c == boolean.class) {
			oos.writeBoolean(((Boolean)result).booleanValue());
			return;
		}
		if(c == byte.class) {
			oos.writeByte(((Byte)result).byteValue());
			return;
		}
		if(c == char.class) {
			oos.writeChar(((Character)result).charValue());
			return;
		}
		if(c == short.class) {
			oos.writeShort(((Short)result).shortValue());
			return;
		}
		if(c == int.class) {
			oos.writeInt(((Integer)result).intValue());
			return;
		}
		if(c == long.class) {
			oos.writeLong(((Long)result).longValue());
			return;
		}
		if(c == float.class) {
			oos.writeFloat(((Float)result).floatValue());
			return;
		}
		if(c == double.class) {
			oos.writeDouble(((Double)result).doubleValue());
			return;
		}
	} else {
		oos.writeObject(result);
	}
}

}
