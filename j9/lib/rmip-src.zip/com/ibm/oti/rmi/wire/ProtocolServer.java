package com.ibm.oti.rmi.wire;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.lang.reflect.*;
import com.ibm.oti.rmi.*;

/**
 * This is the superclass of all RMI protocols in the server side.
 *
 * @author		OTI
 * @version		initial
 */
public abstract class ProtocolServer extends Protocol {

public abstract void waitHeader() throws IOException;
public abstract void waitMessageCallHeader() throws IOException;
public abstract CallData waitMessageReceiver(ObjectInput ois) throws IOException;
public abstract void sendReturnHeader() throws IOException;
public abstract void sendReturnValueHeader (boolean success,ObjectOutput oos) throws IOException;

/**
 * Constructs a new instance of this class.
 *
 * @author		OTI
 * @version		initial
 */
ProtocolServer() throws IOException {
	super();
}

/**
 * Constructs a new instance of this class and initializes a
 * thread to handle accepted connections.
 *
 * @author		OTI
 * @version		initial
 */
ProtocolServer(Socket s) throws IOException {
	super(s);
}

}
