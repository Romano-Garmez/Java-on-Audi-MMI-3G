package com.ibm.oti.rmi.wire;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.lang.reflect.*;
import com.ibm.oti.rmi.*;

/**
 * This class implements the server side of the StreamProtocol.
 *
 * @author		OTI
 * @version		initial
 */
public class StreamProtocolServer extends ProtocolServer implements Runnable {

public static final String ThreadPrefix = "RMI-ServerConnection:";

/**
 * Constructs a new instance of this class and
 * instantiates a thread to handle an accepted connection.
 *
 * @author		OTI
 * @version		initial
 */
StreamProtocolServer(Socket s) throws IOException {
	startServer(s);
}

/**
 * This is the run method of the thread that handles the
 * connection.
 *
 * @author		OTI
 * @version		initial
 */
public void run() {
	try {
		waitHeader();
	} catch (IOException ex) {
		return;
	}
	while(true) {
		try {
			waitMessageCallHeader();
		} catch(InterruptedIOException e) {
			//there was a read time out in the socket
			try { conn.close(); } catch(IOException ee){}
			return;
		} catch (IOException e) {
			//Connection was closed;
			//break;
			try { conn.close(); } catch(IOException ee){}
			return;
		}
		ObjectInput ois;
		CallData data;
		try {
			ois = new RMIObjectInputStream(dis);
			data = waitMessageReceiver(ois);
		} catch (IOException ex) {
			sendException(new UnmarshalException(com.ibm.oti.rmi.util.Msg.getString("R0038", ""),ex));
			return;
		}

		if (!dispatch(data,ois)){
			try { conn.close(); } catch(IOException ee){}
			return;
		}
	}
}

/*
 * Starts a server if there are none started otherwise answers the one already started.
 * Answers the port where the server was started.
 */
private void startServer(Socket s) throws IOException {
	init(s);
	Thread serv = new Thread(null,this, ThreadPrefix + s.getInetAddress().getHostAddress());
	serv.start();
}

/**
 * Waits for the StreamProtocol header.
 *
 * @author		OTI
 * @version		initial
 */
public void waitHeader() throws IOException {
	try {
		int header = dis.readInt();
		short version = dis.readShort();
		byte protocol = dis.readByte();
		if((header != HeaderPrefix) || (protocol != StreamProtocol)) {
			dos.write(ProtocolNotSupported);
			conn.close();
			return;
		}
		dos.write(ProtocolAck);
		// Send EndpointIdentifier -
		dos.writeUTF(conn.getInetAddress().getHostAddress());
		dos.writeInt(conn.getPort());
		dos.flush();
		// Receive the EndpointIdentifier
		dis.readUTF();
		dis.readInt();
	} catch (IOException ex) {
		try { conn.close(); } catch(IOException e) {}
		throw ex;
	}
}

/**
 * Waits for a remote call header.
 *
 * @author		OTI
 * @version		initial
 */
public void waitMessageCallHeader() throws IOException {
	while(true) {
		int read = dis.read();
		if(read==-1) {
			throw new IOException(com.ibm.oti.rmi.util.Msg.getString("R0039"));
		}
		if(read == Ping) {
			dos.writeByte(PingAck);
			dos.flush();
		} else if(read == CallPrefix) {
			return;
		} else if(read == DgcAckPrefix) {
			UID uid = UID.read(dis);
		} else {
			return;
		}
	}
}

/**
 * Waits for the remote call's receiver.
 *
 * @author		OTI
 * @version		initial
 */
public CallData waitMessageReceiver(ObjectInput ois) throws IOException {
	ObjID receiver = ObjID.read(ois);
	int operation = ois.readInt();
	long hash = ois.readLong();
	return new CallData(receiver,operation,hash,null);
}

/**
 * Sends the exception that was thrown during the method invocation.
 *
 * @author		OTI
 * @version		initial
 */
private void sendException(Throwable ex) {
	try {
		sendReturnHeader();
		ObjectOutput oos = new RMIObjectOutputStream(dos);
		sendReturnValueHeader(false,oos);
		oos.writeObject(ex);
		oos.flush();
		logException(ex);
	} catch (IOException e) {
		try {conn.close(); } catch (IOException ee) {}
	}
}

private void logException(Throwable ex) {
	try {
		// Log this exception
		PrintStream logger = RemoteServer.getLog();
		if (logger != null) {
			//tbd: check if this value is correct
			String clientAddress =
				conn.getInetAddress().getLocalHost().getHostAddress();
			logger.print("[" + clientAddress + "] ");
			ex.printStackTrace(logger);
		}
	} catch (Exception e) {}
}

private void logMethodCall(Remote obj, String methodString) {
	try {
		// Log this method call
		PrintStream logger = RemoteServer.getLog();
		if (logger != null) {
			//tbd: double check if these are the correct values.
			String clientAddress =
				conn.getInetAddress().getLocalHost().getHostAddress();
			logger.println( "[" + clientAddress + ": " + obj.getClass().getName() +"[" + obj.hashCode() + "]" +": " + methodString + "]") ;
		}
	} catch(Exception e) {}
}

/**
 * Sends the remote message to the receiver and sends
 * the result to the client.
 *
 * @author		OTI
 * @version		initial
 */
private boolean dispatch(CallData data, ObjectInput ois) {
	Remote obj = RMIServerTable.getObj(data.id());
	if(obj==null) {
		sendException(new NoSuchObjectException(com.ibm.oti.rmi.util.Msg.getString("R0058")+ data.id()));
		return false;
	}
	RMIServerTable.increaseCallCount(data.id());
	try {
	if(data.opNumber() == -1) {
		//Java 2 - RMI spec. There is no _Skel.
		Object result;
		Method m = RMIServerTable.getMethod(obj,data.hash());
		if(m == null) {
			sendException(new java.rmi.UnmarshalException(
				com.ibm.oti.rmi.util.Msg.getString("R0040",obj.getClass(),new Long(data.hash()))));
				return false;
		}
		Object args[] = new Object[m.getParameterTypes().length];
		try {
			for(int i=0;i<args.length;i++) {
				args[i] = readObject(m.getParameterTypes()[i],ois);
			}
		} catch (Exception ex) {
			sendException(new ServerException(com.ibm.oti.rmi.util.Msg.getString("R0059"), new UnmarshalException(com.ibm.oti.rmi.util.Msg.getString("R0007"),ex)));
			return false;
		}

		logMethodCall(obj, m.toString());

		try {
			result = m.invoke(obj,args);
		} catch (InvocationTargetException ex) {
			Throwable t= ex.getTargetException();
			handleInvocationTargetException(m, t);
			return false;
		} catch (Exception ex) {
			sendException(ex);
			return false;
		}
		try {
			sendReturnHeader();
			ObjectOutput oos = new RMIObjectOutputStream(dos);
			sendReturnValueHeader(true,oos);
			writeObject(m.getReturnType(),result,oos);
			oos.flush();
		} catch (Exception ex) {
			// We can not send the exception to the server
			// anymore because it is not expecting one.
			// Let's close the connection;
			return false;
		}
	}
	} finally {
		RMIServerTable.decreaseCallCount(data.id());
	}
	return true;
}

private void handleInvocationTargetException(Method m, Throwable t) {
	if (RemoteException.class.isAssignableFrom(t.getClass())) {
		sendException(new ServerException(com.ibm.oti.rmi.util.Msg.getString("R0059"),(RemoteException)t));
		return;
	}

	if (Error.class.isAssignableFrom(t.getClass())) {
		sendException(new ServerError(com.ibm.oti.rmi.util.Msg.getString("R0060"),(Error)t));
		return;
	}

	if (RuntimeException.class.isAssignableFrom(t.getClass())) {
		sendException((RuntimeException) t);
		return;
	}

	//check if exception is declared.
	boolean exceptionIsDeclared = false;
	Class[] exceptions = m.getExceptionTypes();
	for (int i = 0; i < exceptions.length; i++) {
		if (exceptions[i].isAssignableFrom(t.getClass())) {
			exceptionIsDeclared = true;
			break;
		}
	}
	//if this is a declared checked exception, send it directly.
	if (exceptionIsDeclared) {
		sendException(t);
		return;
	} else {
		//if this is an undeclared checked exception, send Unexpectedexception.
		sendException(new UnexpectedException(null, (Exception)t));
		return;
	}

}

/**
 * Sends the remote call answer header to the client.
 *
 * @author		OTI
 * @version		initial
 */
public void sendReturnHeader() throws IOException {
 	dos.writeByte(ReturnDataPrefix);
}

/**
 * Sends the result of the remote call to the client.
 * @author		OTI
 * @version		initial
 */
public void sendReturnValueHeader (boolean success,ObjectOutput oos) throws IOException {
	if(success)
		oos.writeByte(ReturnValuePrefix);
	else
		oos.writeByte(ReturnExceptionPrefix);
	oos.flush();
	UnicastRef.LocalUID.write(oos);
	oos.flush();
}
}
