package com.ibm.oti.rmi.wire;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import java.security.*;

import com.ibm.oti.rmi.*;

/**
 * This class implements the StreamProtocol.
 *
 * @author		OTI
 * @version		initial
 */
public class StreamProtocolClient extends ProtocolClient {

static int handshakeTimeoutValue = -1;

/**
 * Constructs a new instance of this class and opens a
 * connection to the specified endpoint.
 *
 * @author		OTI
 * @version		initial
 */
StreamProtocolClient(EndpointID epid,RMIClientSocketFactory csf) throws IOException {
	super();
	startClient(epid,csf);
}

/**
 * Creates a sockect using the specified factory and opens
 * a connection with the server.
 *
 * @author		OTI
 * @version		initial
 */
void startClient(EndpointID epid,final RMIClientSocketFactory csf) throws IOException {
	String epidString = epid.getHost() + ":" + epid.getPort();
	try {
		Socket s = csf.createSocket(epid.getHost(),epid.getPort());
		init(s);
	}catch (java.net.UnknownHostException e) {
		throw new java.rmi.UnknownHostException(com.ibm.oti.rmi.util.Msg.getString("R0055") + epidString,e);
	}catch (java.net.ConnectException e) {
		throw new java.rmi.ConnectException(com.ibm.oti.rmi.util.Msg.getString("R0056") + epidString,e);
	}catch (IOException e) {
		throw new java.rmi.ConnectIOException(com.ibm.oti.rmi.util.Msg.getString("R0057") + epidString,e);
	}
	sendHeader();
}

public void close() {
	try {conn.close();} catch (IOException e) {}
}

/**
 * Sends the protocol header and waits for the answer from the
 * server.
 *
 * @author		OTI
 * @version		initial
 */
protected void sendHeader () throws IOException, MarshalException {
	dos.writeInt(HeaderPrefix);
	dos.writeShort(Version);
	dos.writeByte(StreamProtocol);
	dos.flush();
	int protocolAck = dis.readByte();
	if(protocolAck != ProtocolAck) {
		try {conn.close();} catch (IOException ee) {}
		throw new MarshalException(com.ibm.oti.rmi.util.Msg.getString("R0037"));
	}

	// Receive the EndpointIdentifier
	dis.readUTF();
	dis.readInt();
	// Send EndpointIdentifier.
	dos.writeUTF(conn.getInetAddress().getHostAddress());
	dos.writeInt(conn.getPort());
	dos.flush();
}

/**
 * Answers the value of the property "com.ibm.oti.rmi.handshakeTimeout";
 *
 * @author		OTI
 * @version		initial
 */
static int gethandshakeTimeoutValue() {
	if(handshakeTimeoutValue == -1) {
		final String defaultValue= (new Integer(60000)).toString();  // 1 minute
		String value = (String)AccessController.doPrivileged(new PrivilegedAction() {
			public Object run() {
				return System.getProperty("com.ibm.oti.rmi.handshakeTimeout",defaultValue);
			}});
		try {
			handshakeTimeoutValue = Integer.parseInt(value);
		} catch (NumberFormatException e) {
			handshakeTimeoutValue = 60000; //1 minute
		}
	}
	return handshakeTimeoutValue;
}

/**
 * Sends a remote call header to the server.
 *
 * @author		OTI
 * @version		initial
 */
public void sendMessageCallHeader() throws IOException {
	//Must syncronize in the port been used.
	dos.writeByte(CallPrefix);
}

/**
 * Sends a remote call receiver to the server.
 *
 * @author		OTI
 * @version		initial
 */
public void sendMessageReceiver(ObjectOutput oos, ObjID id,int operation,long hash) throws IOException {
	id.write(oos);
	oos.writeInt(operation);
	oos.writeLong(hash);
	oos.flush();
}

/**
 * Waits for the protocol to answer the header from the server.
 *
 * @author		OTI
 * @version		initial
 */
public void waitReturnHeader() throws IOException {
	byte prefix = dis.readByte();
}

/**
 * Waits for the remote class to answer the header from the server.
 * @author		OTI
 * @version		initial
 */
public void waitReturnValueHeader (ObjectInput ois) throws Exception {
	//Read ReturnValuePrefix || ReturnExceptionPrefix
	byte prefix = ois.readByte();
	UID.read(ois);
	if(prefix == ReturnExceptionPrefix) {
		Exception ex;
		try {
			ex = (Exception)ois.readObject();
		} catch (Exception e) {
			markInvalid();
			throw new java.rmi.RemoteException(com.ibm.oti.rmi.util.Msg.getString("R0052"),e);
		}
		markInvalid();
		throw ex;
	}
}

/**
 * Creates an ObjectOutputStream from the receiver's OutputStream.
 *
 * @author		OTI
 * @version		initial
 */
public ObjectOutput createObjectOutput() throws IOException {
	return new RMIObjectOutputStream(dos);
}

/**
 * Creates an ObjectInputStream from the receiver's InputStream.
 *
 * @author		OTI
 * @version		initial
 */
public ObjectInput createObjectInput() throws IOException {
	return new RMIObjectInputStream(dis);
}

}
