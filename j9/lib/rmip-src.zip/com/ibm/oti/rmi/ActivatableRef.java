package com.ibm.oti.rmi;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2002, 2003  All Rights Reserved
 */

import java.io.*;
import java.lang.reflect.Method;
import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.activation.ActivationException;
import java.rmi.activation.ActivationID;
import java.rmi.server.*;

/**
 * This class implements a reference to an activatable remote object.
 *
 * @author		OTI
 * @version		initial
 */
public class ActivatableRef implements RemoteRef {

transient boolean force;

protected RemoteRef ref;
protected ActivationID id;

/**
 * Constructs a new instance of this class.
 *
 * This constructor is sent by RemoteObject>>#readObject
 *
 * @author		OTI
 * @version		initial
 */
public ActivatableRef() {
	super();
}

/**
 * Constructs a new instance of this class and initializes
 * its Activation Id and Remote reference.
 *
 * @author		OTI
 * @version		initial
 */
public ActivatableRef(ActivationID id, RemoteRef ref) {
	this.ref = ref;
	this.id = id;
}

private RemoteRef activate(boolean force) throws RemoteException {
	/* tbd: */
	/* the implementation of this class is not complete yet,
	for now we will set the force value to true each time there is a method call.*/
	force = true;
	try {
		Remote remote = id.activate(force);
		return ((RemoteObject)remote).getRef();
	} catch (ActivationException ae) {
		throw new RemoteException(com.ibm.oti.rmi.util.Msg.getString("R0001"), ae);
	}
}

private RemoteRef getRef() throws java.rmi.RemoteException{
	if  (ref == null)
			ref = activate(force);
	return ref;
}

/**
 * Answers the receiver's class name.
 *
 * @author		OTI
 * @version		initial
 */
private String getRefClass() {
	String clName = this.getClass().getName();
	return clName.substring(clName.lastIndexOf('.') + 1);
}

/**
 * Writes the receiver's class name in the output stream
 * and answers it.
 *
 * @author		OTI
 * @version		initial
 */
public String getRefClass(ObjectOutput out) {
	return getRefClass();
}

/**
 * Sends the specified message <code>mth</code> to the
 * specified receiver.
 *
 * @author		OTI
 * @version		initial
 */
public Object invoke(Remote receiver, Method mth, Object[] params, long opHash) throws Exception {
	try {
		return getRef().invoke(receiver, mth, params,opHash);
	} catch (NoSuchObjectException e) {
		ref =null;
		return getRef().invoke(receiver, mth, params,opHash);
	}
}

/**
 * Answers a hash code to the remote object.
 *
 * @author		OTI
 * @version		initial
 */
public int remoteHashCode(){
	return id.hashCode();
}

/**
 * Answers true if the two references point to
 * the same object otherwise answer false.
 *
 * @author		OTI
 * @version		initial
 */
public boolean remoteEquals(RemoteRef obj) {
	if(obj instanceof ActivatableRef) {
		ActivatableRef o = (ActivatableRef)obj;
		return ((id.equals(o.id)) && (ref.equals(o.ref)));
	}
	return false;
}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String remoteToString(){
//	return this.getClass().getName() + ":[" + getHost() + ":" + getPort() + "||" + id + "]";
	return this.getClass().getName() + ":[" + id + "]";
}

/**
 * Writes the receiver to the ObjectOutput <code>output</code>.
 *
 * @author		OTI
 * @version		initial
 *
 * @param		output		An ObjectOutput where to write the object
 *
 * @exception 	java.io.IOException	If an error occurs attempting to write to the ObjectOutput.
 */
public void writeExternal(ObjectOutput out) throws IOException {
	out.writeObject(id);
	if (ref == null) {
		out.writeUTF("");
	} else {
		out.writeUTF(ref.getRefClass(null));
		ref.writeExternal(out);
	}
}

/**
 * Reads the next object from the ObjectInput <code>input</code>.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		the next object read from the ObjectInput
 *
 * @exception 	java.io.IOException		If an error occurs attempting to read from this ObjectInput.
 * @exception 	java.lang.ClassNotFoundException	If the class of the instance being loaded cannot be found.
 */
public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
	id = (ActivationID)in.readObject();
	String refClassName = in.readUTF();
	if(refClassName.length()!= 0) {
		try {
			refClassName = packagePrefix + "." + refClassName;
			//No need to used RMIClassLoader because 'refClassName' must be a system class.
			ref = (RemoteRef)Class.forName(refClassName).newInstance();
			ref.readExternal(in);
		} catch (IllegalAccessException ex) {
			throw new IOException(com.ibm.oti.rmi.util.Msg.getString("R0002", refClassName));
		} catch (InstantiationException ex) {
			throw new IOException(com.ibm.oti.rmi.util.Msg.getString("R0002", refClassName));
		}
	}
}

/**
 * Answers a string containing a concise, human-readable
 * description of the receiver.
 *
 * @author		OTI
 * @version		initial
 *
 * @return		String
 *					a printable representation for the receiver.
 */
public String toString () {
	return getRefClass() + "[" + id.toString() + "]::" + super.toString();
}

}
