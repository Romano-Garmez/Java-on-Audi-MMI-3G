package com.ibm.oti.rmi.rmic;
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import java.net.*;
import java.util.*;
import com.ibm.oti.rmi.util.*;

public class Main {
	static boolean xdebug = false;

/**
 * Prints how the method main shoud be used.
 *
 * @author		OTI
 * @version		initial
 */
public static void usage() {
	System.err.println();
	System.err.println(com.ibm.oti.rmi.util.Msg.getString("R0013"));
	System.err.println();
	System.err.println(com.ibm.oti.rmi.util.Msg.getString("R0014"));
	System.err.println("\t-ver:<version>\t "+com.ibm.oti.rmi.util.Msg.getString("R0015"));
	System.err.println("\t\t<version> = [1.1 | 1.2 | Compat]");
	System.err.println("\t-cp:<path>\t "+com.ibm.oti.rmi.util.Msg.getString("R0016"));
	System.err.println("\t-d:<destDir>\t "+com.ibm.oti.rmi.util.Msg.getString("R0017"));
	System.err.println("\t-keep\t\t "+com.ibm.oti.rmi.util.Msg.getString("R0018"));
	System.err.println("\t-nocompile\t "+com.ibm.oti.rmi.util.Msg.getString("R0019"));
	System.err.println("\t-g\t\t "+com.ibm.oti.rmi.util.Msg.getString("R0020"));
	System.err.println("\t-verbose\t "+com.ibm.oti.rmi.util.Msg.getString("R0021"));
	System.err.println("\t-nowarn\t\t "+com.ibm.oti.rmi.util.Msg.getString("R0022"));
}

/**
 * Starts the application.
 */
public static void main(java.lang.String[] args) {
	try {
		if((args == null) || (args.length == 0)) {
			usage();
			return;
		}

		int version = -1;
		String classpath = null, bootpath = null, jcl = null;
		File dest = null;
		boolean cDebug = false, cVerbose = false, keep = false;
		boolean compile = true, nowarn = true;
		for(int i=0;i<args.length - 1;i++) {
			if(args[i].startsWith("-ver:")) {
				String ver = args[i].substring(5);
				if(ver.equals("1.1"))
					version = StubGenerator.V11;
				else if(ver.equals("1.2"))
					version = StubGenerator.V12;
				else if(ver.equalsIgnoreCase("Compat"))
					version = StubGenerator.VComp;
				else {
					System.err.println(com.ibm.oti.rmi.util.Msg.getString("R0023",ver));
					usage();
					System.exit(1);
				}
			} else if(args[i].startsWith("-cp:")) {
				classpath = args[i].substring(4);
			} else if(args[i].startsWith("-d:")) {
				dest = new File(args[i].substring(3));
			} else if(args[i].startsWith("-keep")) {
				keep = true;
			} else if(args[i].equals("-nocompile")) {
				compile = false;
				keep = true;
			} else if(args[i].equals("-g")) {
				cDebug = true;
			} else if(args[i].equals("-verbose")) {
				cVerbose = true;
			} else if(args[i].equals("-nowarn")) {
				nowarn = true;
			} else if(args[i].startsWith("-jcl:")) {
				jcl = args[i].substring(5);
			} else if(args[i].startsWith("-bp:")) {
				bootpath = args[i].substring(4);
			} else if(args[i].equals("-Xdebug")) {
				xdebug = true;
			} else if (args[i].startsWith("-")) {
				System.err.println(com.ibm.oti.rmi.util.Msg.getString("R0024",args[i]));
				System.exit(1);
			}
		}
		if(version == -1)
			version = StubGenerator.VComp;

		ClassLoader cLoader;
		String cPath = null;
		if(classpath == null) classpath = ".";
		Vector cp = new Vector();
		int start = 0;
		while (start < classpath.length()) {
			int end = classpath.indexOf(File.pathSeparatorChar,start);
			if (end == -1)
				end = classpath.length();
			File f = new File(classpath.substring(start,end));
			String fName = f.getCanonicalPath();
			if (cPath == null) cPath = fName;
			else cPath = cPath + File.pathSeparator + fName;
			fName = fName.replace('\\','/');
			if(f.isDirectory()) {
				if(!(fName.endsWith("/")))
					fName = fName + "/";
			}
			cp.add(new URL("file","", fName));
			start = end + 1;
		}
		URL[] urls = new URL[cp.size()];
		cp.toArray(urls);
		// Cannot have the system class loader as the parent since
		// classes found by the system class loader may reference
		// classes not on the system class loader class path.
		cLoader = new URLClassLoader(urls, null);
		if (xdebug) {
			for(int i=0;i<urls.length;i++)
				System.out.println("URL[" + i + "] " + urls[i]);
		}

		if(dest == null) dest = new File(".");
		Vector cArgs = new Vector();
		if (compile) {
			String destPath = dest.getAbsolutePath();
			if (bootpath == null) {
				File rmiFile = new File(System.getProperty("java.home"), "lib/rmi.zip");
				if (rmiFile.exists())
					cPath = rmiFile.getAbsolutePath() + File.pathSeparator + cPath;
			}
			cArgs.add(System.getProperty("com.ibm.oti.vm.bootstrap.library.path") + "j9c");
			if (jcl != null) cArgs.add("-jcl:" + jcl);
			if (bootpath != null) {
				cArgs.add("-bootclasspath");
				cArgs.add(bootpath);
			}
			cArgs.add("-classpath");
			cArgs.add(cPath);
			cArgs.add("-d");
			cArgs.add(destPath);
			cArgs.add(cDebug ? "-g" : "-g:lines");
			if (cVerbose) cArgs.add("-verbose");
			if (nowarn) cArgs.add("-nowarn");
		}

		int rc = 0;
		int fIndex = cArgs.size();
		for (int i=0; i<args.length; i++) {
			if (!args[i].startsWith("-")) {
				if (generate(args[i],dest,version,cLoader)) {
					if (compile) {
						String file = new File(dest, args[i].replace('.', File.separatorChar)).getAbsolutePath();
						cArgs.add(file + "_Stub.java");
						if (version != StubGenerator.V12)
							cArgs.add(file + "_Skel.java");
					}
				} else rc = 1;
			}
		}
		if (cArgs.size() > fIndex)
			rc |= execJ9c(cArgs);
		if (!keep) {
			for (int i=fIndex; i<cArgs.size(); i++) {
				if (xdebug) System.out.println("removing: " + cArgs.elementAt(i));
				new File((String)cArgs.elementAt(i)).delete();
			}
		}
		System.exit(rc);
	} catch (Exception ex) {
		ex.printStackTrace();
	}
}

private static int execJ9c(Vector vargs) {
	String[] args = new String[vargs.size()];
	vargs.copyInto(args);
	if (xdebug) {
		for (int i=0; i<args.length; i++)
			System.out.println(i + ") " + args[i]);
	}
	Process process;
	try {
		process = Runtime.getRuntime().exec(args);
	} catch (IOException e) {
		System.err.println(com.ibm.oti.rmi.util.Msg.getString("R0025",args[0]) + ": " + e);
		return 1;
	}
	new Thread(readInput(process.getInputStream())).start();
	readInput(process.getErrorStream()).run();
	while (true) {
		try {
			return process.waitFor();
		} catch (InterruptedException e) {}
	}
}

private static Runnable readInput(final InputStream in) {
	return new Runnable() {
		public void run() {
			int read;
			byte[] buf = new byte[256];
			try {
				while ((read = in.read(buf)) != -1)
					System.out.write(buf, 0, read);
			} catch (IOException e) {}
		}};
}

private static boolean generate(String classNameStr, File dest, int version, ClassLoader cLoader) throws Exception {
	Class remoteClass;
	try {
		remoteClass = cLoader.loadClass(classNameStr);
	} catch (ClassNotFoundException ex) {
		System.err.println(com.ibm.oti.rmi.util.Msg.getString("R0026",classNameStr));
		return false;
	} catch (NoClassDefFoundError ex) {
		System.err.println(com.ibm.oti.rmi.util.Msg.getString("R0027",classNameStr) + ": " + ex.getMessage());
		return false;
	}

	Class[] intf = RMIUtil.getAllRemoteInterfaces(remoteClass);
	if (intf.length == 0) {
		System.err.println(com.ibm.oti.rmi.util.Msg.getString("R0028",classNameStr));
		return false;
	}

	String className = remoteClass.getName();
	if(className.lastIndexOf('.') > 0) {
		className = className.substring(0,className.lastIndexOf('.'));
		className = className.replace('.',File.separatorChar);
		dest = new File(dest,className);
	}
	dest.mkdirs();

	className = remoteClass.getName();
	className = className.substring(className.lastIndexOf('.') + 1);

	if((version == StubGenerator.VComp) || (version == StubGenerator.V11)) {
		FileOutputStream f = new FileOutputStream(new File(dest,className + "_Skel.java"));
		PrintStream p = new PrintStream(f);
		StubGenerator.genSkel(version,remoteClass,p);
		p.close();
		f.close();
	}
	FileOutputStream f = new FileOutputStream(new File(dest,className + "_Stub.java"));
	PrintStream p = new PrintStream(f);
	StubGenerator.genStub(version,remoteClass,p);
	p.close();
	f.close();
	return true;
}

}
