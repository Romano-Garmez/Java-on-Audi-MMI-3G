package com.ibm.oti.rmi.rmic;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp 1998, 2003
 */

import java.io.*;
import com.ibm.oti.rmi.util.*;
import java.util.*;
import java.lang.reflect.*;
import com.ibm.oti.util.SHAOutputStream;

/**
 * This class implements a stub generator, i.e.
 * the stub generation part of the RMIC.
 * It does not compile the genarated source yet.
 *
 * It has two public methods genStub and genSkel
 * which generate source for the proxy in a
 * specified output.
 *
 * @author		OTI
 * @version		initial
 */
public class StubGenerator {

	public static final int V11 = 0;
	public static final int V12 = 1;
	public static final int VComp = 2;

	/*
	 * RMI implementation classes that use this generator and require special handling.
	 */
	protected static final Class[] rmiImplClasses = new Class[] {
		/*com.ibm.oti.rmi.activation.ActivatorImpl,*/
		com.ibm.oti.rmi.registry.RegistryImpl.class,
		com.ibm.oti.rmi.dgc.DGCImpl.class };

	protected boolean v11;
	protected boolean v12;
	protected boolean vComp;

	protected Class remoteClass;
	protected PrintStream out;
	protected long proxyHash = 0;

	protected Method[] methods;
	protected Class[] interfaces;

/*
 * Generates the RMI Stub source for the given remoteClass in the
 * given PrintStream.
 * version = V11 or V12 or VComp
 */
public static void genStub(int version,Class remoteClass,PrintStream out) throws IOException {
	new StubGenerator(version,remoteClass,out).genStub();
}

/*
 * Generates the RMI Skeleton source for the given remoteClass in the
 * given PrintStream.
 * version = V11 or V12 or VComp.
 * Since skeletons are not needed for V12, nothing will
 * be done if version == V12.
 */
public static void genSkel(int version,Class remoteClass,PrintStream out) throws IOException {
	new StubGenerator(version,remoteClass,out).genSkel();
}

/**
 * Constructs a new instance of this class which
 * will generate the proxies for <code>remoteClass</code>
 * according to <code>version</code> into
 * the specified stream <code>out</code>.
 *
 * @author		OTI
 * @version		initial
 */
protected StubGenerator(int version,Class remoteClass,PrintStream out) {
	if(version == V11) {
		v11 = true;
		v12 = vComp = false;
	} else if(version == V12) {
		v11 = vComp = false;
		v12 = true;
	} else {
		v11 = v12 = vComp = true;
	}
	this.remoteClass = remoteClass;
	this.out = out;
	findMethods();
}

/**
 * Writes the source for the stub in the output stream.
 *
 * @author		OTI
 * @version		initial
 */
protected void genStub () throws IOException {
	writeHeader();
	writeStubClassName();
	writeStubClassInit();
	writeStubConstructors();
	writeStubMethods();
	out.print("}");
}

/**
 * Writes the source for the skeleton to the output stream.
 *
 * @author		OTI
 * @version		initial
 */
protected void genSkel () {
	if(!v11) return;

	writeHeader();
	writeSkelClassName();
	writeSkelClassInit();
	writeSkelConstructors();
	out.println("public Operation[] getOperations() {return ops;}");
	out.println();
	writeSkelDispatch();
	out.print("}");
}

protected void writeHeader() {

	if (isRmiClass(remoteClass))
		out.println("/*[INCLUDE-IF RMI]*/");

	out.println("/" + "*");
	out.println(" * " + com.ibm.oti.rmi.util.Msg.getString("R0029"));
	out.println(" * " + com.ibm.oti.rmi.util.Msg.getString("R0030"));
	out.println(" * " + com.ibm.oti.rmi.util.Msg.getString("R0031"));
	out.println(" */");
	String pName = packageName();
	if (pName != null)
		out.println("package " + pName + ";");

	if (isRmiClass(remoteClass)) {
		out.println();
		out.println("/*");
		out.println(" * Licensed Materials - Property of IBM,");
		out.println(" * (c) Copyright IBM Corp 1998, 2001");
		out.println(" */");
		out.println();
	}

	out.println();
	out.println("import java.rmi.*;");
	out.println("import java.rmi.server.*;");
	out.println("import java.lang.reflect.*;");
	out.println("import java.io.*;");
	out.println();
}

protected void writeSkelClassName() {
	out.println(
		"public class " + className() +
		"_Skel implements Skeleton {");
	out.println();
}

protected void writeSkelClassInit() {
	out.println("private static final Operation ops[];");
	out.println();
	out.println("static {");
	writeOperations();
	out.println("}");
	out.println();
}

protected void writeSkelConstructors() {
	out.print("public ");
	out.println(className() + "_Skel() throws java.rmi.RemoteException {}");
	out.println();
}

protected void writeSkelDispatch() {
	out.print("public void dispatch(Remote obj, RemoteCall rc, ");
	out.println("int opnum, long hash) throws Exception {");
	out.println("\tif(hash != " + proxyHash + "L)");
	out.println("\t\tthrow new SkeletonMismatchException(\"" + className() + "\");");
	out.println();
	for(int i=0;i<methods.length;i++)
		writeSkelDispatchOp(methods[i],i);
	if (methods.length>0) {
		out.println("\t} else {");
		out.println("\t\tthrow new NoSuchObjectException("+externalMessageString("R0032", null)+
				"+\" '\" + opnum + \"' \"+"+externalMessageString("R0033", null)+");");
		out.println("\t}");
	}
	out.println("}");
}

protected void writeSkelDispatchOp(Method m,int opNum) {
	out.print("\t");
	if(opNum > 0)
		out.print("} else ");
	out.println("if(opnum == " + opNum + ") {");
	Class pTypes[] = m.getParameterTypes();
	for(int i=0;i<pTypes.length;i++) {
		out.println("\t\t" + getTypeName(pTypes[i]) + " arg" + i + ";");
	}
	if(pTypes.length > 0) {
		out.println("\t\ttry {");
		out.println("\t\t\tObjectInput ois = rc.getInputStream();");
		boolean catchClassNotFoundException = false;
		for(int i=0;i<pTypes.length;i++) {
			if(!pTypes[i].isPrimitive())
				catchClassNotFoundException = true;
			out.println("\t\t\targ" + i + " = (" + getTypeName(pTypes[i])
				+ ")ois.read" + stringWriteReadObject(pTypes[i]) + "();");
		}
		if(catchClassNotFoundException) {
			out.println("\t\t} catch (ClassNotFoundException ex) {");
			out.println("\t\t\tthrow new UnmarshalException("+externalMessageString("R0007", null)+",ex);");
		}
		out.println("\t\t} catch (IOException ex) {");
		out.println("\t\t\tthrow new UnmarshalException("+externalMessageString("R0007", null)+",ex);");
		out.println("\t\t} finally {");
		out.println("\t\t\trc.releaseInputStream();");
		out.println("\t\t}");
	}
	Class rType = m.getReturnType();
	out.print("\t\t");
	if(rType != void.class) {
		out.print(getTypeName(rType) + " result = ");
	}
	out.print("((" + className() + ")obj)." + m.getName() + "(");
	for(int i=0;i<pTypes.length;i++) {
		out.print("arg" + i);
		if(i + 1 <pTypes.length)
			out.print(", ");
	}
	out.println(");");

	out.println("\t\ttry {");
	if(rType != void.class) {
		out.println("\t\t\tObjectOutput oos = rc.getResultStream(true);");
		out.println("\t\t\toos.write" + stringWriteReadObject(rType) + "(result);");
	} else {
		out.println("\t\t\trc.getResultStream(true);");
	}
	out.println("\t\t} catch (IOException ex) {");
	out.println("\t\t\tthrow new UnmarshalException(" +
		externalMessageString("R0008", null)+",ex);");
	out.println("\t\t}");

}

protected void writeStubClassName() {
	String ints[] = interfaces();
	out.print(
		"public class " + className() +
		"_Stub extends RemoteStub implements ");
	String packageName = packageName();
	for(int i =0;i<ints.length;i++) {
		String name = ints[i];
		/* Required to work around batch compiler bug
		if (packageName != null && name.startsWith(packageName)) {
			String sub = name.substring(packageName.length() + 1);
			if (sub.indexOf('.') == -1)
				name = sub;
		} */
		out.print(name);
		if(i + 1 < ints.length)
			out.print(", ");
	}
	out.println(" {");
	out.println();
}

protected void writeStubClassInit() {
	if(vComp)
		out.println("private static boolean isJDK11;");

	out.println("private static Object ops[] = null;");

	if(v12)
		out.println("private static Class remoteClass = null;");

	out.println();
	out.println("static {");

	if(v12) {
		out.println("\ttry {");
		String pName = packageName();
		if(pName != null)
			out.println("\t\tremoteClass = Class.forName(\"" + pName + "." + className() + "\");");
		else
			out.println("\t\tremoteClass = Class.forName(\"" + className() + "\");");
	}
	if(vComp) {
		out.println("\t\tClass.forName(\"java.rmi.MarshalledObject\");");
		out.println("\t\tisJDK11 = false;");
	}
	if(v12)
		out.println("\t} catch (ClassNotFoundException ex) {");
	if(vComp)
		out.println("\t\tisJDK11 = true;");
	if(v12)
		out.println("\t}");
	if(vComp)
		out.println("\tif(isJDK11) {");
	if(v11)
		writeOperations();
	if(vComp)
		out.println("\t} else {");
	if(v12)
		writeMethods();
	if(vComp)
		out.println("\t}");
	out.println("}");
	out.println();
}

protected void writeStubConstructors() {
	out.println("public " + className() +
		"_Stub(RemoteRef ref) throws java.rmi.RemoteException {");
	out.println("\tsuper(ref);");
	out.println("}");
	out.println();
	out.println("public " + className() +
		"_Stub() throws java.rmi.RemoteException {");
	out.println("\tsuper();");
	out.println("}");
	out.println();
}

protected void writeStubMethods() throws IOException {
	for(int i=0;i<methods.length;i++) {
		writeStubMethodsName(methods[i]);
		if(vComp)
			out.println("\tif(isJDK11) {");
		if(v11)
			writeStubJDK11Method(methods[i],i);
		if(vComp)
			out.println("\t} else {");
		if(v12)
			writeStubJDK12Method(methods[i],i);
		if(vComp)
			out.println("\t}");
		out.println("}");
		out.println();
	}
}

protected void writeStubMethodsName(Method m) {
	out.print("public ");
	out.print(getTypeName(m.getReturnType()));
	out.print(" " + m.getName() + "(");
	Class p[] = m.getParameterTypes();
	for(int j=0;j<p.length;j++) {
		out.print(getTypeName(p[j]) + " p" + j);
		if(j+1<p.length)
			out.print(", ");
	}
	out.print(") throws ");
	Class exs[] = m.getExceptionTypes();
	for(int j=0;j<exs.length;j++) {
		out.print(exs[j].getName());
		if(j+1<exs.length)
			out.print(", ");
	}
	out.println("{");
}

protected void writeStubJDK11Method(Method m, int opIndex)  {
	out.print("\t\tRemoteCall rc = ref.newCall(this,(Operation[])ops, ");
	out.println(opIndex + ", " + proxyHash + "L);");
	Class p[] = m.getParameterTypes();
	if(p.length > 0) {
		out.println("\t\ttry {");
		out.println("\t\t\tObjectOutput oos = rc.getOutputStream();");
		for(int j=0;j<p.length;j++)
			out.println("\t\t\toos.write" + stringWriteReadObject(p[j]) + "(p" + j + ");");
		out.println("\t\t} catch (IOException ex) {");
		out.print("\t\t\tthrow new MarshalException(");
		out.println(externalMessageString("R0010", null)+",ex);");
		out.println("\t\t}");
	}
	out.println("\t\ttry {");
	out.println("\t\t\tref.invoke(rc);");
	out.println("\t\t} catch (RuntimeException ex) {");
	out.println("\t\t\tthrow ex;");

	Class exs[] = m.getExceptionTypes();
	select(exs);
	boolean incEx = false;
	for(int j=0;j<exs.length;j++) {
		if(exs[j] != null) {
			if(exs[j] == Exception.class) incEx = true;
			out.println("\t\t} catch (" + exs[j].getName() + " ex) {");
			out.println("\t\t\tthrow ex;");
		}
	}
	if(!incEx) {
		out.println("\t\t} catch (Exception ex) {");
		out.println("\t\t\tthrow new UnexpectedException(" + externalMessageString("R0038", new String[]{m.getName()}) + ",ex);");
	}
	out.println("\t\t}");

	Class rType = m.getReturnType();
	if(rType != void.class) {
		out.println("\t\t" + getTypeName(rType) + " result;");
		out.println("\t\ttry {");
		out.println("\t\t\tObjectInput ois = rc.getInputStream();");
		out.println("\t\t\tresult = (" + getTypeName(rType) + ")ois.read" + stringWriteReadObject(rType) + "();");
		out.println("\t\t} catch (RuntimeException ex) {");
		out.println("\t\t\tthrow ex;");
		out.println("\t\t} catch (Exception ex) {");
		out.println("\t\t\tthrow new UnmarshalException("+externalMessageString("R0012", null)+",ex);");
		out.println("\t\t} finally {");
		out.println("\t\t\tref.done(rc);");
		out.println("\t\t}");
		out.println("\t\treturn result;");
	}
}

protected void writeStubJDK12Method(Method m, int opIndex) throws IOException{
	out.println("\t\ttry {");
	out.print("\t\t\t");
	Class rType = m.getReturnType();
	if(rType != void.class) {
		if(rType.isPrimitive()) {
			out.print(wrapperName(rType) + " result = (" + wrapperName(rType) + ")");
		} else {
			out.print("return (" + getTypeName(rType) + ")");
		}
	}
	out.println("ref.invoke(");
	out.print("\t\t\t\tthis,(Method)ops[" + opIndex + "], new Object[]{");
	Class p[] = m.getParameterTypes();
	for(int j=0;j<p.length;j++) {
		if(p[j].isPrimitive()) {
			out.print("new " + wrapperName(p[j]) + "(p" + j + ")");
		} else {
			out.print("p" + j);
		}
		if(j+1<p.length)
			out.print(", ");

	}
	out.print("}, ");
	out.print(RMIUtil.hashFor(m));
	out.println("L);");

	if((rType != void.class) && (rType.isPrimitive())) {
		out.println("\t\t\t\treturn result." + getTypeName(rType) + "Value();");
	}

	Class exs[] = m.getExceptionTypes();
	select(exs);
	boolean incEx = false;
	for(int j=0;j<exs.length;j++) {
		if(exs[j] != null) {
			if(exs[j] == Exception.class) incEx = true;
			out.println("\t\t} catch (" + exs[j].getName() + " ex) {");
			out.println("\t\t\tthrow ex;");
		}
	}
	if(!incEx) {
		out.println("\t\t} catch (Exception ex) {");
		out.println("\t\t\tthrow new UnexpectedException(" + externalMessageString("R0038", new String[]{m.getName()}) + ",ex);");
	}
	out.println("\t\t}");
}

protected void writeOperations() {
	String ops[] = getOperations();
	out.println("\t\tops = new Operation[]{");
	for(int i =0;i<ops.length;i++) {
		out.print("\t\t\tnew Operation(\"" + ops[i] + "\")");
		if(i + 1 < ops.length)
			out.println(",");
	}
	out.println();
	out.println("\t\t};");
}

protected void writeMethods() {
	String[] mths = getMethodString();
	if (mths.length>0)
		out.println("\t\ttry {");
	out.println("\t\t\tops = new Method[]{");
	for(int i =0;i<mths.length;i++) {
		out.print("\t\t\t\tClass.forName(\""+interfaces[i].getName()+"\").getMethod(" + mths[i] + ")");
		if(i + 1 < mths.length)
			out.println(",");
	}
	out.println();
	out.println("\t\t\t};");
	if (mths.length>0) {
		out.println("\t\t} catch (NoSuchMethodException ex) {");
		out.println("\t\t\tthrow new RuntimeException("+externalMessageString("R0035", null)+");");
		out.println("\t\t} catch (ClassNotFoundException ex2) {");
		out.println("\t\t\tthrow new RuntimeException("+externalMessageString("R0036", null)+");");
		out.println("\t\t}");
	}
}

protected String externalMessageString(String messageKey, Object[] args) {
	if (isRmiClass(remoteClass)) {
		StringBuffer msg = new StringBuffer();
		msg.append("com.ibm.oti.rmi.util.Msg.getString(\"");
		msg.append(messageKey);
		msg.append("\"");
		if (args != null && args.length > 0) {
			for(int i = 0; i < args.length; i++) {
				msg.append("\"");
				msg.append(args[i].toString());
				msg.append("\"");
				if (i < args.length-1)
					msg.append(",");
			}
		}
		msg.append(")");
		return msg.toString();
	} else {
		if (args != null && args.length > 0)
			return "\""+com.ibm.oti.rmi.util.Msg.getString(messageKey, args)+"\"";
		else
			return "\""+com.ibm.oti.rmi.util.Msg.getString(messageKey)+"\"";
	}
}

/*
 * Answers the a string to build the
 * write/read message name. Ex readInt,
 * writeLong, etc
 */
protected String stringWriteReadObject(Class c) {
	if(c.isPrimitive()) {
		if(c == boolean.class) return "Boolean";
		if(c == byte.class) return "Byte";
		if(c == char.class) return "Char";
		if(c == short.class) return "Short";
		if(c == int.class) return "Int";
		if(c == long.class) return "Long";
		if(c == float.class) return "Float";
		if(c == double.class) return "Double";
		return null;
	}
	return "Object";
}

/*
 * Answers the wrapper class name for
 * a primitive type.
 */
protected String wrapperName(Class c) {
	if(c.isPrimitive()) {
		if(c == boolean.class) return "Boolean";
		if(c == byte.class) return "Byte";
		if(c == char.class) return "Character";
		if(c == short.class) return "Short";
		if(c == int.class) return "Integer";
		if(c == long.class) return "Long";
		if(c == float.class) return "Float";
		if(c == double.class) return "Double";
		return null;
	}
	return "Object";
}

/*
 * Computes and answers the hash for a proxy.
 */
protected void computeProxyHash(String[] ops) {
	//The spec does not say how this hash
	//should be computed but registry and
	//DGC must be compatible with SUN's hash.
	if(remoteClass.equals(com.ibm.oti.rmi.registry.RegistryImpl.class)) {
		proxyHash = 4905912898345647071L;
	} else if(remoteClass.equals(com.ibm.oti.rmi.dgc.DGCImpl.class)) {
		proxyHash = -669196253586618813L;
	} else {
		try {
			SHAOutputStream sha = new SHAOutputStream();
			DataOutputStream output = new DataOutputStream(sha);
			for(int i=0;i<ops.length;i++)
				output.writeUTF(ops[i]);
			byte[] h = sha.getHashAsBytes();
			proxyHash = RMIUtil.littleEndianLongAt(h,0);
		} catch (IOException ex) {}
	}
}

/*
 * Answers a String array with the receiever's operation strings.
 */
protected String[] getOperations() {
	Vector r = new Vector();
	for(int i=0;i<methods.length;i++) {
		r.add(operationString(methods[i]));
	}
	String[] rString = new String[r.size()];
	r.toArray(rString);
	computeProxyHash(rString);
	return rString;
}

/*
 * Answer a String array with the signature of the methods
 * that must be implemented by the stub.
 */
protected String[] getMethodString() {
	String r[] = new String[methods.length];
	for(int i=0;i<r.length;i++) {
		String m = "\"" + methods[i].getName() + "\", new Class[]{";
		Class params[] = methods[i].getParameterTypes();
		for(int j=0;j<params.length;j++) {
			m = m + getTypeName(params[j]) + ".class";
			if(j + 1 < params.length)
				m = m + ", ";
		}
		m = m + "}";
		r[i] = m;
	}
	return r;
}

/*
 * Answers a Method array with the methods
 * that must be implemented by the stub.
 */
protected void findMethods() {
	TreeMap meth = new TreeMap();
	Class ints[] = RMIUtil.getAllRemoteInterfaces(remoteClass);
	for(int i =0;i<ints.length;i++) {
		Method[] m = ints[i].getMethods();
		for(int j=0;j<m.length;j++) {
			String sig = operationString1(m[j]);
			if (!meth.containsKey(sig))
				meth.put(sig, new Object[]{m[j], ints[i]});
		}
	}
	methods = new Method[meth.size()];
	interfaces = new Class[meth.size()];
	int i=0;
	Iterator it = meth.values().iterator();
	while(it.hasNext()) {
		Object[] value = (Object[])it.next();
		methods[i] = (Method)value[0];
		interfaces[i] = (Class)value[1];
		i++;
	}
}

/*
 * Selects the super exceptions that must be
 * caught.
 */
protected void select(Class[] array) {
	for(int i=0;i<array.length;i++) {
		for(int j=0;j<array.length;j++) {
			if((array[i] != null) &&
				(array[j] != null) &&
					(isSuperclass(array[j],array[i]))) {
						array[i] = null;
						break;
			}
		}
	}
}

/*
 * Answers true if c1 is superClass of c2, otherwise
 * answer false.
 */
protected boolean isSuperclass(Class c1,Class c2) {
	boolean b = isSuperclass0(c1,c2);
	return b;
}

protected boolean isSuperclass0(Class c1,Class c2) {
	Class obj = Object.class;
	Class c = c2;
	do {
		c = c.getSuperclass();
		if(c.equals(c1)) return true;
	} while((c!=obj) && (c!=null));
	return false;
}

/*
 * Answers the operation string for a Method.
 * Ex: Answers java.lang.String foo(int, java.lang.String, double)
 * for String foo(int i,String s);
 * Ex: Answers java.lang.String foo(int, java.lang.String, double)[]
 * for String[] foo(int i,String s);
*/
protected String operationString (Method m) {
	return operationString0(m) + " " + operationString1(m);
}

/*
 * Answers the first part of the operation string.
 * Ex: Answers java.lang.String foo
 * for String foo(int i,String s);
 * Ex: Answers java.lang.String foo
 * for String[] foo(int i,String s);
*/
protected String operationString0 (Method m) {
	String r;
	int dim = 0;
	Class rType = m.getReturnType();
	String rName = rType.getName();
	if(rType.isArray()) {
		dim = rName.lastIndexOf('[') + 1;
		if(rName.charAt(dim) == 'L') {
			r = rName.substring(dim + 1,rName.length() - 1);
		} else {
			r = rName.substring(dim,rName.length());
		}
	} else
		r = getTypeName(rType);
	return r;
}

/*
 * Answers the second part of the operation string.
 * Ex: Answers (int, java.lang.String, double)
 * for String foo(int i,String s);
 * Ex: Answers (int, java.lang.String, double)[]
 * for String[] foo(int i,String s);
*/
protected String operationString1 (Method m) {
	String r = m.getName() + "(";
	Class[] pTypes = m.getParameterTypes();
	for(int i=0;i<pTypes.length;i++) {
		r = r + getTypeName(pTypes[i]);
		if(i + 1 < pTypes.length)
			r = r + ", ";
	}
	r = r + ")";
	if(m.getReturnType().isArray()) {
		int dim = m.getReturnType().getName().lastIndexOf('[') + 1;
		for(int i=0;i<dim;i++)
			r = r + "[]";
	}
	return r;
}

/*
 * Answers <code>c</code>'s qualified name.
 */
protected String getTypeName(Class c) {
	if(c.isPrimitive()) {
		if(c == boolean.class) return "boolean";
		if(c == byte.class) return "byte";
		if(c == char.class) return "char";
		if(c == short.class) return "short";
		if(c == int.class) return "int";
		if(c == long.class) return "long";
		if(c == float.class) return "float";
		if(c == double.class) return "double";
		if(c == void.class) return "void";
		return null;
	}
	if(!c.isArray())
		return c.getName();

	String tName = c.getName();
	int bIndex = tName.lastIndexOf('[');
	if(tName.charAt(bIndex + 1) == 'L') {
		tName = tName.substring(bIndex + 2,tName.length() - 1);
	} else {
		char type = tName.charAt(bIndex + 1);
		if(type == 'Z') tName = "boolean";
		if(type == 'B') tName = "byte";
		if(type == 'C') tName = "char";
		if(type == 'S') tName = "short";
		if(type == 'I') tName = "int";
		if(type == 'J') tName = "long";
		if(type == 'F') tName = "float";
		if(type == 'D') tName = "double";
		if(type == 'V') tName = "void";
	}
	for(int i=0;i<=bIndex;i++) {
		tName = tName + "[]";
	}
	return tName;
}

/*
 * Answers the <code>remoteClass</code>
 * package name.
 */
protected String packageName() {
	String name;
	int index;
	name = remoteClass.getName();
	if((index = name.lastIndexOf('.')) == -1) return null;
	return name.substring(0, index);
}

/*
 * Answers the <code>remoteClass</code>
 * simple name.
 */
protected String className() {
	String name;
	int index;
	name = remoteClass.getName();
	index = name.lastIndexOf('.');
	return name.substring(index + 1,name.length());
}

/*
 * Answers all remote interfaces implemented by
 * <code>remoteClass</code>.
 */
protected String[] interfaces() {
	Class ints[] = RMIUtil.getAllRemoteInterfaces(remoteClass);
	String r[] = new String[ints.length];
	for(int i =0;i<r.length;i++)
		r[i] = ints[i].getName();
	return r;
}

/*
 * Answers whether the <code>remoteClass</code> is a RMI implementation class.
 */
protected boolean isRmiClass(Class testClass) {
	for(int i = 0; i < rmiImplClasses.length; i++) {
		if (rmiImplClasses[i].equals(testClass))
			return true;
	}
	return false;
}

}
